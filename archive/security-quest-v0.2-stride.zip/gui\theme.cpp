#include "theme.h"

#include "platform.h"

#include <algorithm>
#include <cstdarg>
#include <cstdio>
#include <vector>

namespace sq::gui {

Fonts fonts;
float ui_scale = 1.0f;

namespace {

ImFont* load_family(const fs::path& dir, const char* main_file) {
    ImGuiIO& io = ImGui::GetIO();
    std::error_code ec;
    fs::path main = dir / main_file;
    if (!fs::exists(main, ec)) return nullptr;
    ImFont* font = io.Fonts->AddFontFromFileTTF(from_path(main).c_str(), 18.0f);
    if (!font) return nullptr;

    // Символы (✓ ★ •) и иконки MDL2 подмешиваются в тот же шрифт.
    for (const char* extra : {"seguisym.ttf", "segmdl2.ttf"}) {
        fs::path p = dir / extra;
        if (!fs::exists(p, ec)) continue;
        ImFontConfig cfg;
        cfg.MergeMode = true;
        if (std::string(extra) == "segmdl2.ttf") cfg.GlyphOffset = ImVec2(0, 3);
        io.Fonts->AddFontFromFileTTF(from_path(p).c_str(), 18.0f, &cfg);
    }
    return font;
}

}  // namespace

void load_fonts() {
    fs::path dir = to_path(getenv_u8("WINDIR")) / "Fonts";
    fonts.regular = load_family(dir, "segoeui.ttf");
    fonts.semibold = load_family(dir, "seguisb.ttf");
    if (!fonts.regular) fonts.regular = ImGui::GetIO().Fonts->AddFontDefault();
    if (!fonts.semibold) fonts.semibold = fonts.regular;
}

ImU32 alpha(ImU32 c, float a) {
    ImVec4 v = ImGui::ColorConvertU32ToFloat4(c);
    v.w *= a;
    return ImGui::ColorConvertFloat4ToU32(v);
}

ImVec4 vec(ImU32 c) {
    return ImGui::ColorConvertU32ToFloat4(c);
}

void setup_style(float dpi_scale) {
    ImGuiStyle& s = ImGui::GetStyle();
    s.WindowPadding = ImVec2(18, 16);
    s.FramePadding = ImVec2(10, 6);
    s.ItemSpacing = ImVec2(10, 8);
    s.ItemInnerSpacing = ImVec2(8, 6);
    s.CellPadding = ImVec2(8, 6);
    s.ScrollbarSize = 12;
    s.WindowRounding = 10;
    s.ChildRounding = 10;
    s.FrameRounding = 6;
    s.PopupRounding = 8;
    s.ScrollbarRounding = 6;
    s.GrabRounding = 6;
    s.TabRounding = 6;
    s.WindowBorderSize = 0;
    s.ChildBorderSize = 1;
    s.PopupBorderSize = 1;
    s.FrameBorderSize = 0;
    s.FontSizeBase = 16.0f;

    ImVec4* c = s.Colors;
    c[ImGuiCol_Text] = vec(col::text);
    c[ImGuiCol_TextDisabled] = vec(col::faint);
    c[ImGuiCol_WindowBg] = vec(col::bg);
    c[ImGuiCol_ChildBg] = vec(col::panel);
    c[ImGuiCol_PopupBg] = vec(IM_COL32(26, 33, 50, 252));
    c[ImGuiCol_Border] = vec(col::border);
    c[ImGuiCol_FrameBg] = vec(IM_COL32(16, 21, 34, 255));
    c[ImGuiCol_FrameBgHovered] = vec(IM_COL32(20, 27, 44, 255));
    c[ImGuiCol_FrameBgActive] = vec(IM_COL32(24, 32, 52, 255));
    c[ImGuiCol_TitleBg] = vec(col::sidebar);
    c[ImGuiCol_TitleBgActive] = vec(col::sidebar);
    c[ImGuiCol_ScrollbarBg] = vec(IM_COL32(0, 0, 0, 0));
    c[ImGuiCol_ScrollbarGrab] = vec(col::border);
    c[ImGuiCol_ScrollbarGrabHovered] = vec(col::faint);
    c[ImGuiCol_ScrollbarGrabActive] = vec(col::dim);
    c[ImGuiCol_CheckMark] = vec(col::gold);
    c[ImGuiCol_SliderGrab] = vec(col::gold);
    c[ImGuiCol_SliderGrabActive] = vec(col::gold_dark);
    c[ImGuiCol_Button] = vec(col::panel_hi);
    c[ImGuiCol_ButtonHovered] = vec(IM_COL32(44, 55, 82, 255));
    c[ImGuiCol_ButtonActive] = vec(IM_COL32(54, 67, 99, 255));
    c[ImGuiCol_Header] = vec(IM_COL32(40, 50, 76, 255));
    c[ImGuiCol_HeaderHovered] = vec(IM_COL32(44, 55, 82, 255));
    c[ImGuiCol_HeaderActive] = vec(IM_COL32(54, 67, 99, 255));
    c[ImGuiCol_Separator] = vec(col::border);
    c[ImGuiCol_TableHeaderBg] = vec(col::panel_hi);
    c[ImGuiCol_TableBorderStrong] = vec(col::border);
    c[ImGuiCol_TableBorderLight] = vec(IM_COL32(36, 45, 68, 255));
    c[ImGuiCol_TableRowBg] = vec(IM_COL32(0, 0, 0, 0));
    c[ImGuiCol_TableRowBgAlt] = vec(IM_COL32(255, 255, 255, 6));
    c[ImGuiCol_TextSelectedBg] = vec(alpha(col::gold, 0.35f));
    c[ImGuiCol_ModalWindowDimBg] = vec(IM_COL32(5, 8, 14, 170));
    c[ImGuiCol_NavCursor] = vec(col::gold);

    s.ScaleAllSizes(dpi_scale);
    s.FontScaleDpi = dpi_scale;
    ui_scale = dpi_scale;
}

void card_begin(const char* id, ImVec2 size, ImU32 bg) {
    ImGui::PushStyleColor(ImGuiCol_ChildBg, bg);
    ImGuiChildFlags flags = ImGuiChildFlags_Borders | ImGuiChildFlags_AlwaysUseWindowPadding;
    if (size.y == 0) flags |= ImGuiChildFlags_AutoResizeY;
    ImGui::BeginChild(id, size, flags, ImGuiWindowFlags_NoScrollbar);
}

void card_end() {
    ImGui::EndChild();
    ImGui::PopStyleColor();
}

void heading(const char* text, float size) {
    ImGui::PushFont(fonts.semibold, size);
    ImGui::TextUnformatted(text);
    ImGui::PopFont();
}

void subheading(const char* text) {
    ImGui::PushFont(fonts.semibold, 17.0f);
    ImGui::TextUnformatted(text);
    ImGui::PopFont();
}

void dim_text(const char* fmt, ...) {
    va_list args;
    va_start(args, fmt);
    ImGui::PushStyleColor(ImGuiCol_Text, col::dim);
    ImGui::TextV(fmt, args);
    ImGui::PopStyleColor();
    va_end(args);
}

void colored_text(ImU32 c, const char* text) {
    ImGui::PushStyleColor(ImGuiCol_Text, c);
    ImGui::TextUnformatted(text);
    ImGui::PopStyleColor();
}

void wrapped_dim(const std::string& text) {
    ImGui::PushStyleColor(ImGuiCol_Text, col::dim);
    ImGui::TextWrapped("%s", text.c_str());
    ImGui::PopStyleColor();
}

void bar(float fraction, ImVec2 size, ImU32 from, ImU32 to, ImU32 track) {
    if (size.x <= 0) size.x = ImGui::GetContentRegionAvail().x;
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    float r = size.y * 0.5f;
    dl->AddRectFilled(p, ImVec2(p.x + size.x, p.y + size.y), track, r);
    float w = size.x * (fraction < 0 ? 0 : fraction > 1 ? 1 : fraction);
    if (w > 1) {
        // Заливка цветом `to` и тонкий блик сверху цветом `from`.
        float fw = std::max(w, size.y);
        dl->AddRectFilled(p, ImVec2(p.x + fw, p.y + size.y), to, r);
        dl->AddRectFilled(ImVec2(p.x + r * 0.5f, p.y + size.y * 0.55f), ImVec2(p.x + fw - r * 0.5f, p.y + size.y), alpha(from, 0.55f), r);
    }
    ImGui::Dummy(size);
}

void pill(const char* text, ImU32 color, bool filled) {
    ImVec2 ts = ImGui::CalcTextSize(text);
    ImVec2 pad(8, 2);
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImVec2 size(ts.x + pad.x * 2, ts.y + pad.y * 2);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    dl->AddRectFilled(p, ImVec2(p.x + size.x, p.y + size.y), filled ? color : alpha(color, 0.16f), size.y * 0.5f);
    dl->AddText(ImVec2(p.x + pad.x, p.y + pad.y), filled ? col::bg : color, text);
    ImGui::Dummy(size);
}

bool accent_button(const char* label, ImVec2 size, ImU32 color) {
    ImGui::PushStyleColor(ImGuiCol_Button, color);
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, alpha(color, 0.85f));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, alpha(color, 0.7f));
    ImGui::PushStyleColor(ImGuiCol_Text, col::bg);
    ImGui::PushFont(fonts.semibold, 0.0f);
    bool clicked = ImGui::Button(label, size);
    ImGui::PopFont();
    ImGui::PopStyleColor(4);
    return clicked;
}

bool icon_button(const char* icon, const char* tip, ImU32 color) {
    ImGui::PushStyleColor(ImGuiCol_Button, IM_COL32(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_Text, color);
    bool clicked = ImGui::Button(icon);
    ImGui::PopStyleColor(2);
    if (tip) tooltip(tip);
    return clicked;
}

void tooltip(const char* text) {
    if (ImGui::IsItemHovered(ImGuiHoveredFlags_DelayShort | ImGuiHoveredFlags_AllowWhenDisabled)) {
        ImGui::BeginTooltip();
        ImGui::PushTextWrapPos(ImGui::GetFontSize() * 24);
        ImGui::TextUnformatted(text);
        ImGui::PopTextWrapPos();
        ImGui::EndTooltip();
    }
}

void tile(const char* big, const char* small, ImVec2 size, bool lit, ImU32 color, const char* tip) {
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImU32 fill = lit ? alpha(color, 0.18f) : IM_COL32(255, 255, 255, 6);
    ImU32 edge = lit ? alpha(color, 0.75f) : col::border;
    dl->AddRectFilled(p, ImVec2(p.x + size.x, p.y + size.y), fill, 8);
    dl->AddRect(p, ImVec2(p.x + size.x, p.y + size.y), edge, 8, lit ? 1.5f : 1.0f);

    // Подпись переносится по словам максимум на две строки, каждая по центру; лишнее — многоточие.
    float ss = ImGui::GetFontSize() * 0.8f;
    float max_w = size.x - px(10);
    auto width = [&](const std::string& s) { return fonts.regular->CalcTextSizeA(ss, FLT_MAX, 0, s.c_str()).x; };
    std::vector<std::string> lines;
    if (small) {
        std::string line, word;
        std::string text = small;
        text += ' ';
        for (char ch : text) {
            if (ch != ' ') {
                word += ch;
                continue;
            }
            if (word.empty()) continue;
            std::string candidate = line.empty() ? word : line + " " + word;
            if (width(candidate) <= max_w || line.empty()) line = candidate;
            else {
                lines.push_back(line);
                line = word;
            }
            word.clear();
        }
        if (!line.empty()) lines.push_back(line);
        if (lines.size() > 2) {
            lines.resize(2);
            lines[1] += "…";
        }
        for (auto& l : lines) {
            while (width(l) > max_w && l.size() > 4) {
                size_t cut = l.size() - (l.ends_with("…") ? 4 : 1);
                while (cut > 0 && (static_cast<unsigned char>(l[cut]) & 0xC0) == 0x80) --cut;
                l = l.substr(0, cut) + "…";
            }
        }
    }

    float big_size = ImGui::GetFontSize() * 1.25f;
    ImVec2 bs = fonts.semibold->CalcTextSizeA(big_size, FLT_MAX, 0, big);
    float line_h = ss + 1;
    float total = bs.y + (lines.empty() ? 0 : 2 + line_h * float(lines.size()));
    float y = p.y + (size.y - total) * 0.5f;
    dl->AddText(fonts.semibold, big_size, ImVec2(p.x + (size.x - bs.x) * 0.5f, y), lit ? color : col::faint, big);
    y += bs.y + 2;
    for (auto& l : lines) {
        dl->AddText(fonts.regular, ss, ImVec2(p.x + (size.x - width(l)) * 0.5f, y), lit ? col::text : col::faint, l.c_str());
        y += line_h;
    }
    ImGui::Dummy(size);
    if (tip) tooltip(tip);
}

}  // namespace sq::gui
