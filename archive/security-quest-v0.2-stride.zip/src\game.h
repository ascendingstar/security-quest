#pragma once

// Пересчёт состояния игры из журнала событий. Все правила начисления очков
// живут здесь, а веса берутся из config.ini, поэтому баланс можно менять задним числом.

#include "config.h"
#include "events.h"
#include "util.h"

#include <map>
#include <set>
#include <string>
#include <vector>

namespace sq {

struct Threat {
    std::string id, desc, stride;
    bool na = false;
    bool active = true;
    bool mitigated = false, tested = false, chained = false;
};

struct Point {
    std::string id, title;
    int stage = 0;  // 0 запланирована, 1 встроена, 2 покрыта тестами
};

struct Campaign {
    std::string code, title, doc;
    std::map<std::string, Threat> threats;
    std::map<std::string, Point> points;
    bool sealed = false;
    bool impl = false, integ = false;

    std::string stride_covered() const;
    int act() const;  // 1 Чертёж, 2 Кузница, 3 Экспансия
};

struct Quest {
    std::string branch, kind, campaign, started, tip;
    bool work = false, done = false;
};

struct Award {
    size_t event;
    int xp;
    std::string reason, skill;
};

struct SideTemplate {
    std::string id, title, skill;
    double xp = 0;
    int weekly_cap = 0;
    bool monthly = false;
    int open_day = 25, due_day = 5;
    double early_bonus = 0;
};

// Ежемесячный контракт, к которому относится дата: месяц отчёта и сдан ли он в срок.
struct ContractPeriod {
    Date month;  // день не используется
    Date due;
    bool on_time = false;
};

struct State {
    int total = 0;
    std::map<std::string, int> skills;
    std::map<std::string, int> weeks;  // понедельник недели -> XP
    std::vector<Award> awards;
    std::map<std::string, Campaign> campaigns;
    std::map<std::string, Quest> quests;
    std::map<int, int> bestiary;                                    // CWE -> сколько поймано
    std::map<std::string, std::map<std::string, int>> side_counts;  // неделя -> id -> раз
    std::map<std::string, std::set<std::string>> contracts_done;    // id -> месяцы YYYY-MM
    std::map<std::string, std::string> finding_lessons;             // F3 -> урок
    std::vector<std::string> warnings;
};

struct Level {
    int level, into, need;
};

Level level_of(int xp);
std::vector<SideTemplate> side_templates(const Config& cfg);
ContractPeriod contract_period(const SideTemplate& t, const Date& d);
std::string act_name(int act);
std::string stage_name(int stage);

State replay(const Config& cfg, const EventLog& log);

}  // namespace sq
