#include "game.h"

#include "cwe.h"

#include <cmath>
#include <cstdlib>

namespace sq {

std::string Campaign::stride_covered() const {
    const std::string letters = "STRIDE";
    std::string r;
    for (char c : letters)
        for (auto& [_, t] : threats)
            if (t.active && t.stride.find(c) != std::string::npos) {
                r += c;
                break;
            }
    return r;
}

int Campaign::act() const {
    bool embedded = false, forged = impl;
    for (auto& [_, p] : points) embedded |= p.stage > 0;
    for (auto& [_, t] : threats) forged |= t.mitigated;
    if (integ || embedded) return 3;
    return forged ? 2 : 1;
}

std::string act_name(int act) {
    switch (act) {
        case 1: return "Акт I «Чертёж»";
        case 2: return "Акт II «Кузница»";
        default: return "Акт III «Экспансия»";
    }
}

std::string stage_name(int stage) {
    switch (stage) {
        case 0: return "запланирована";
        case 1: return "встроена";
        default: return "покрыта тестами";
    }
}

Level level_of(int xp) {
    int level = 1, need = 100;
    while (xp >= need) {
        xp -= need;
        ++level;
        need = 100 + 50 * (level - 1);
    }
    return {level, xp, need};
}

std::vector<SideTemplate> side_templates(const Config& cfg) {
    std::vector<SideTemplate> out;
    for (auto& sec : cfg.ini.sections("side.")) {
        SideTemplate t;
        t.id = sec.substr(5);
        t.title = cfg.ini.get(sec, "title", t.id);
        t.skill = cfg.ini.get(sec, "skill", "Разное");
        t.xp = cfg.ini.num(sec, "xp", 10);
        t.weekly_cap = int(cfg.ini.num(sec, "weekly_cap", 0));
        t.monthly = cfg.ini.get(sec, "recur") == "monthly";
        t.open_day = int(cfg.ini.num(sec, "open_day", 25));
        t.due_day = int(cfg.ini.num(sec, "due_day", 5));
        t.early_bonus = cfg.ini.num(sec, "early_bonus", 0);
        out.push_back(t);
    }
    return out;
}

ContractPeriod contract_period(const SideTemplate& t, const Date& d) {
    ContractPeriod p;
    if (d.d >= t.open_day) {
        p.month = {d.y, d.m, 1};
        p.due = add_months(p.month, 1);
        p.on_time = true;
    } else {
        p.month = add_months({d.y, d.m, 1}, -1);
        p.due = {d.y, d.m, 1};
        p.on_time = d.d <= t.due_day;
    }
    p.due.d = t.due_day;
    return p;
}

namespace {

int parse_cwe(const std::string& s) {
    std::string digits = starts_with(upper_ascii(s), "CWE-") ? s.substr(4) : s;
    return std::atoi(digits.c_str());
}

// «AUTHZ/T-03» -> {"AUTHZ", "T-03"}
std::pair<std::string, std::string> split_target(const std::string& target) {
    auto slash = target.find('/');
    if (slash == std::string::npos) return {};
    return {upper_ascii(trim(target.substr(0, slash))), trim(target.substr(slash + 1))};
}

class Replayer {
public:
    Replayer(const Config& cfg, State& st) : cfg_(cfg), st_(st) {
        for (auto& t : side_templates(cfg)) templates_[t.id] = t;
        for (auto& sec : cfg.ini.sections("campaign.")) {
            auto& c = campaign(sec.substr(9));
            c.title = cfg.ini.get(sec, "title");
            c.doc = cfg.ini.get(sec, "doc");
        }
    }

    void apply(size_t index, const Event& e) {
        index_ = index;
        date_ = parse_date(e.time);
        const std::string& t = e.type;
        if (t == "side") side(e.get("id"), e.get("title"));
        else if (t == "finding") finding(e);
        else if (t == "lesson") lesson(e);
        else if (t == "threat.add" || t == "threat.update" || t == "threat.restore") threat(e);
        else if (t == "threat.drop") threat_drop(e);
        else if (t == "quest.start") quest_start(e);
        else if (t == "quest.work") quest_work(e);
        else if (t == "quest.done") quest_done(e);
        else if (t == "link") link(e);
        else if (t == "point.plan") point_plan(e);
    }

    void finish() {
        for (auto& [target, kinds] : pending_)
            for (auto& kind : kinds)
                st_.warnings.push_back("Трейлер " + kind + ": " + target + " ссылается на угрозу, которой нет в документе");
        for (auto& [id, info] : blind_spots_)
            if (!st_.finding_lessons.count(id))
                st_.warnings.push_back("Слепое пятно " + id + " (" + info + ") ждёт урока: sq lesson " + id + " \"…\"");
    }

private:
    Campaign& campaign(const std::string& code) {
        auto& c = st_.campaigns[code];
        c.code = code;
        return c;
    }

    void award(double xp, const std::string& reason, const std::string& skill) {
        int v = int(std::lround(xp));
        if (v <= 0) return;
        st_.total += v;
        st_.skills[skill] += v;
        st_.weeks[week_start(date_)] += v;
        st_.awards.push_back({index_, v, reason, skill});
    }

    double xp(const char* key, double def) const { return cfg_.xp(key, def); }

    // Побочный квест: недельный лимит или ежемесячный контракт.
    void side(const std::string& id, const std::string& custom_title) {
        auto it = templates_.find(id);
        if (it == templates_.end()) {
            int n = ++st_.side_counts[week_start(date_)]["adhoc"];
            int cap = int(xp("side_adhoc_cap", 5));
            award(xp("side_adhoc", 10) * diminish(n, cap), "Побочный квест: " + custom_title, "Разное");
            return;
        }
        const SideTemplate& t = it->second;
        if (t.monthly) {
            ContractPeriod p = contract_period(t, date_);
            auto& done = st_.contracts_done[t.id];
            std::string month = month_key(p.month);
            if (!done.insert(month).second) return;  // этот месяц уже закрыт
            std::string title = t.title + " (" + month_nominative(p.month.m) + ")";
            if (p.on_time) award(t.xp * (1 + t.early_bonus), title + ", в срок", t.skill);
            else award(t.xp, title, t.skill);
            return;
        }
        int n = ++st_.side_counts[week_start(date_)][t.id];
        award(t.xp * diminish(n, t.weekly_cap), t.title, t.skill);
    }

    static double diminish(int nth, int cap) {
        if (cap <= 0 || nth <= cap) return 1.0;
        return std::pow(0.5, nth - cap);
    }

    void finding(const Event& e) {
        int cwe = parse_cwe(e.get("cwe"));
        std::string sev = e.get("sev"), stage = e.get("stage"), id = e.get("id");
        int seen = st_.bestiary[cwe]++;

        double base = xp(("sev_" + sev).c_str(), 5);
        double mult = xp(("stage_" + stage).c_str(), 1.0);
        double novelty = seen == 0 ? xp("novelty", 1.5) : std::max(0.3, std::pow(xp("repeat_decay", 0.8), seen));
        std::string label = "CWE-" + std::to_string(cwe);
        if (auto* info = find_cwe(cwe)) label += " " + std::string(info->name);
        award(base * mult * novelty, (seen == 0 ? "Новый класс в бестиарии: " : "Находка: ") + label, cwe_skill(cwe));

        std::string lesson_text = e.get("lesson");
        if (!lesson_text.empty()) lesson_bonus(id, lesson_text);

        auto [code, threat_id] = split_target(e.get("threat"));
        if (!code.empty()) {
            auto& c = campaign(code);
            if (c.threats.count(threat_id)) award(xp("prophecy", 20), "Пророчество сбылось: " + code + "/" + threat_id, "Проектирование");
            else st_.warnings.push_back("Находка " + id + " ссылается на неизвестную угрозу " + code + "/" + threat_id);
        } else if (!e.get("campaign").empty() && (stage == "impl" || stage == "integ")) {
            blind_spots_[id] = label;
        }
    }

    void lesson(const Event& e) { lesson_bonus(e.get("ref"), e.get("text")); }

    void lesson_bonus(const std::string& finding_id, const std::string& text) {
        if (finding_id.empty() || text.empty() || st_.finding_lessons.count(finding_id)) return;
        st_.finding_lessons[finding_id] = text;
        award(xp("lesson", 10), "Урок извлечён: " + finding_id, "Проектирование");
    }

    void threat(const Event& e) {
        auto& c = campaign(e.get("campaign"));
        std::string id = e.get("id");
        bool fresh = !c.threats.count(id);
        Threat& t = c.threats[id];
        t.id = id;
        t.desc = e.get("desc");
        t.stride = e.get("stride");
        t.na = e.get("na") == "1";
        t.active = true;

        if (e.type == "threat.add" && fresh) {
            if (t.na) award(xp("threat_na", 3), "Угроза разобрана как неприменимая: " + c.code + "/" + id, "Проектирование");
            else award(xp("threat", 10), "Пророчество записано: " + c.code + "/" + id, "Проектирование");
        }
        if (!c.sealed && c.stride_covered().size() == 6) {
            c.sealed = true;
            award(xp("stride_seal", 100), "Чертёж скреплён печатью: " + c.code, "Проектирование");
        }

        // Трейлеры могли прийти раньше, чем угроза появилась в документе.
        std::string target = c.code + "/" + id;
        if (auto p = pending_.find(target); p != pending_.end()) {
            auto kinds = p->second;
            pending_.erase(p);
            for (auto& kind : kinds) threat_link(c, t, kind);
        }
    }

    void threat_drop(const Event& e) {
        auto& c = campaign(e.get("campaign"));
        if (auto it = c.threats.find(e.get("id")); it != c.threats.end()) it->second.active = false;
    }

    void threat_link(Campaign& c, Threat& t, const std::string& kind) {
        std::string target = c.code + "/" + t.id;
        if (kind == "threat" && !t.mitigated) {
            t.mitigated = true;
            award(xp("mitigation", 15), "Митигация в main: " + target, "Реализация");
        } else if (kind == "threat-test" && !t.tested) {
            t.tested = true;
            award(xp("threat_test", 15), "Тест угрозы в main: " + target, "Реализация");
        }
        if (t.mitigated && t.tested && !t.chained) {
            t.chained = true;
            award(xp("chain", 30), "Цепочка замкнута: " + target, "Реализация");
        }
    }

    void link(const Event& e) {
        std::string kind = e.get("kind");
        auto [code, id] = split_target(e.get("target"));
        if (code.empty() || id.empty()) return;
        auto& c = campaign(code);

        if (kind == "threat" || kind == "threat-test") {
            c.impl = true;
            auto it = c.threats.find(id);
            if (it == c.threats.end()) pending_[code + "/" + id].insert(kind);
            else threat_link(c, it->second, kind);
            return;
        }

        Point& p = c.points[id];
        p.id = id;
        c.integ = true;
        if (kind == "integration" && p.stage < 1) {
            p.stage = 1;
            award(xp("integration", 20), "Точка интеграции встроена: " + code + "/" + id, "Интеграция");
        } else if (kind == "integration-test" && p.stage < 2) {
            p.stage = 2;
            award(xp("integration_test", 30), "Точка интеграции покрыта тестами: " + code + "/" + id, "Интеграция");
        }
    }

    void point_plan(const Event& e) {
        auto& c = campaign(e.get("campaign"));
        Point& p = c.points[e.get("point")];
        p.id = e.get("point");
        if (!e.get("title").empty()) p.title = e.get("title");
    }

    void quest_start(const Event& e) {
        Quest& q = st_.quests[e.get("branch")];
        q.branch = e.get("branch");
        q.kind = e.get("kind");
        q.campaign = e.get("campaign");
        q.tip = e.get("tip");
        q.started = e.time.substr(0, 10);
        if (!q.campaign.empty()) {
            auto& c = campaign(q.campaign);
            if (q.kind == "impl") c.impl = true;
            if (q.kind == "integ") c.integ = true;
        }
    }

    void quest_work(const Event& e) {
        Quest& q = st_.quests[e.get("branch")];
        q.work = true;
        q.tip = e.get("tip");
    }

    void quest_done(const Event& e) {
        Quest& q = st_.quests[e.get("branch")];
        if (q.done) return;
        q.done = true;
        if (q.kind == "fix" && templates_.count("bugfix")) {
            side("bugfix", {});
            return;
        }
        static const std::map<std::string, std::pair<const char*, const char*>> rules = {
            {"impl", {"quest_impl", "Реализация"}},
            {"integ", {"quest_integ", "Интеграция"}},
            {"review", {"quest_review", "Охота"}},
        };
        auto r = rules.find(q.kind);
        const char* key = r != rules.end() ? r->second.first : "quest_other";
        const char* skill = r != rules.end() ? r->second.second : "Ремесло";
        award(xp(key, 15), "Квест выполнен: " + q.branch, skill);
    }

    const Config& cfg_;
    State& st_;
    std::map<std::string, SideTemplate> templates_;
    std::map<std::string, std::set<std::string>> pending_;  // цель -> виды трейлеров
    std::map<std::string, std::string> blind_spots_;        // F3 -> CWE
    size_t index_ = 0;
    Date date_;
};

}  // namespace

State replay(const Config& cfg, const EventLog& log) {
    State st;
    Replayer r(cfg, st);
    const auto& events = log.all();
    for (size_t i = 0; i < events.size(); ++i) r.apply(i, events[i]);
    r.finish();
    return st;
}

}  // namespace sq
