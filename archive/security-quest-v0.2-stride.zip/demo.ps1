﻿# Демо: прогоняет сценарий из tests\smoke.ps1 в каталоге demo и показывает, как выглядит игра.
# Ваши настоящие данные не затрагиваются. С ключом -Gui открывает окно на демо-данных.
param([switch]$Gui)
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8

$work = Join-Path $PSScriptRoot 'demo'
Write-Host 'Готовлю демо-данные: репозиторий, docx с угрозами, события...'
& (Join-Path $PSScriptRoot 'tests\smoke.ps1') -Work $work *> $null
if ($LASTEXITCODE) { throw 'Сценарий не прошёл, запустите tests\smoke.ps1, чтобы увидеть ошибку' }
$env:SQ_HOME = Join-Path $work 'данные игры'

if ($Gui) {
    Start-Process (Join-Path $PSScriptRoot 'build\sq-gui.exe')
    Write-Host 'Окно открыто на демо-данных. Закрыть совсем — правой кнопкой по значку в трее, «Выход».'
    return
}

$sq = Join-Path $PSScriptRoot 'build\sq.exe'
foreach ($cmd in @(@(), @('side'), @('threats'), @('log', '15'))) {
    Write-Host "`n> sq $($cmd -join ' ')" -ForegroundColor Cyan
    & $sq @cmd
}
Write-Host "`nДемо-данные: $work. Чтобы поработать с ними: `$env:SQ_HOME = '$env:SQ_HOME'"
