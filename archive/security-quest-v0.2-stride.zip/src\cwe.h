#pragma once

// Справочник для бестиария: классы CWE, которые чаще всего встречаются
// в C++ коде механизмов безопасности, и ветка навыков, которую они прокачивают.

#include <string>
#include <vector>

namespace sq {

struct CweInfo {
    int id;
    const char* name;
    const char* skill;
};

const std::vector<CweInfo>& cwe_catalog();
const CweInfo* find_cwe(int id);
std::string cwe_skill(int id);  // «Охота» для классов вне справочника

}  // namespace sq
