﻿# Рисует gui\app.ico: золотой щит с галочкой на тёмной плитке. Запускается один раз,
# результат лежит в репозитории, при сборке не нужен.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing

function New-Frame([int]$s) {
    $bmp = New-Object Drawing.Bitmap $s, $s, ([Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = 'AntiAlias'
    $g.Clear([Drawing.Color]::Transparent)

    $r = [single]($s * 0.22)
    $bg = New-Object Drawing.Drawing2D.GraphicsPath
    $bg.AddArc(0, 0, $r, $r, 180, 90); $bg.AddArc($s - $r - 1, 0, $r, $r, 270, 90)
    $bg.AddArc($s - $r - 1, $s - $r - 1, $r, $r, 0, 90); $bg.AddArc(0, $s - $r - 1, $r, $r, 90, 90); $bg.CloseFigure()
    $g.FillPath((New-Object Drawing.SolidBrush ([Drawing.Color]::FromArgb(255, 22, 28, 43))), $bg)

    $u = $s / 100.0
    $shield = New-Object Drawing.Drawing2D.GraphicsPath
    $pts = @(
        (New-Object Drawing.PointF (50*$u), (12*$u)), (New-Object Drawing.PointF (82*$u), (24*$u)),
        (New-Object Drawing.PointF (80*$u), (52*$u)), (New-Object Drawing.PointF (50*$u), (90*$u)),
        (New-Object Drawing.PointF (20*$u), (52*$u)), (New-Object Drawing.PointF (18*$u), (24*$u))
    )
    $shield.AddClosedCurve($pts, 0.25)
    $grad = New-Object Drawing.Drawing2D.LinearGradientBrush (New-Object Drawing.PointF 0, (12*$u)), (New-Object Drawing.PointF 0, (90*$u)), ([Drawing.Color]::FromArgb(255, 255, 210, 110)), ([Drawing.Color]::FromArgb(255, 222, 150, 40))
    $g.FillPath($grad, $shield)

    $pen = New-Object Drawing.Pen ([Drawing.Color]::FromArgb(255, 22, 28, 43)), ([single][Math]::Max(1.5, 9*$u))
    $pen.StartCap = 'Round'; $pen.EndCap = 'Round'; $pen.LineJoin = 'Round'
    $g.DrawLines($pen, [Drawing.PointF[]]@((New-Object Drawing.PointF (35*$u), (50*$u)), (New-Object Drawing.PointF (46*$u), (61*$u)), (New-Object Drawing.PointF (66*$u), (38*$u))))
    $g.Dispose()

    $ms = New-Object IO.MemoryStream
    $bmp.Save($ms, [Drawing.Imaging.ImageFormat]::Png)
    $bmp.Dispose()
    , $ms.ToArray()
}

$sizes = 16, 24, 32, 48, 64, 256
$frames = $sizes | ForEach-Object { , (New-Frame $_) }
$out = New-Object IO.MemoryStream
$w = New-Object IO.BinaryWriter $out
$w.Write([uint16]0); $w.Write([uint16]1); $w.Write([uint16]$sizes.Count)
$offset = 6 + 16 * $sizes.Count
for ($i = 0; $i -lt $sizes.Count; $i++) {
    $s = $sizes[$i]; $len = $frames[$i].Length
    $w.Write([byte]($s % 256)); $w.Write([byte]($s % 256)); $w.Write([byte]0); $w.Write([byte]0)
    $w.Write([uint16]1); $w.Write([uint16]32); $w.Write([uint32]$len); $w.Write([uint32]$offset)
    $offset += $len
}
foreach ($f in $frames) { $w.Write($f) }
$w.Flush()
[IO.File]::WriteAllBytes((Join-Path $PSScriptRoot '..\gui\app.ico'), $out.ToArray())
$png = Join-Path $PSScriptRoot '..\gui\app-256.png'
[IO.File]::WriteAllBytes($png, $frames[-1])
