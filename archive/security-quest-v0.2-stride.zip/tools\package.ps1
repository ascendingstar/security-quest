﻿# Собирает портативную версию: dist\SecurityQuest\ и zip-архив рядом.
# Папка data внутри включает портативный режим: все данные остаются рядом с программой.
$ErrorActionPreference = 'Stop'
$root = Resolve-Path (Join-Path $PSScriptRoot '..')
& (Join-Path $root 'build.ps1')
if ($LASTEXITCODE) { throw 'Сборка не прошла' }

$dist = Join-Path $root 'dist'
$app = Join-Path $dist 'SecurityQuest'
if (Test-Path $app) { Remove-Item -Recurse -Force $app }
New-Item -ItemType Directory -Force (Join-Path $app 'data') | Out-Null
Copy-Item (Join-Path $root 'build\sq-gui.exe') (Join-Path $app 'Security Quest.exe')
Copy-Item (Join-Path $root 'build\sq.exe') (Join-Path $app 'sq.exe')
@'
Security Quest — портативная версия

Security Quest.exe  — окно (двойной щелчок)
sq.exe              — то же из командной строки (sq help)
data\               — ваши данные: config.ini и events.log

Папку можно положить куда угодно, в том числе на флешку. Установка не нужна,
в реестр и профиль пользователя ничего не пишется. Нужна Windows 10 или новее.
Чтобы перенести прогресс, скопируйте папку data.
'@ | Set-Content -Path (Join-Path $app 'README.txt') -Encoding UTF8

$zip = Join-Path $dist 'SecurityQuest-portable.zip'
if (Test-Path $zip) { Remove-Item $zip }
Compress-Archive -Path $app -DestinationPath $zip
Get-ChildItem $app -Recurse | Select-Object FullName, Length
Get-Item $zip | Select-Object FullName, Length
