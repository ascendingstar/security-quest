﻿# Сквозная проверка: временный репозиторий, docx с таблицей угроз, все команды sq.
# Пути специально с кириллицей и пробелами.
param([string]$Work = (Join-Path $env:TEMP 'sq smoke'))
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem

$sq = (Resolve-Path (Join-Path $PSScriptRoot '..\build\sq.exe')).Path
if (Test-Path $Work) { Remove-Item -Recurse -Force $Work }
$data = Join-Path $Work 'данные игры'
$repo = Join-Path $Work 'рабочий репозиторий'
$docs = Join-Path $Work 'документы'
New-Item -ItemType Directory -Force $repo, $docs | Out-Null
$env:SQ_HOME = $data
$doc = Join-Path $docs 'Дизайн авторизации.docx'

$script:failures = 0
function Sq { $out = (& $sq @args 2>&1 | Out-String); if ($LASTEXITCODE) { throw "sq $args -> $LASTEXITCODE`n$out" }; Write-Host "> sq $args`n$out"; $out }
function Invoke-Git { & git.exe -C $repo -c user.name=Test -c user.email=test@example.invalid @args 2>&1 | Out-Null; if ($LASTEXITCODE) { throw "git $args" } }
function Expect([string]$Text, [string]$Needle) {
    if ($Text.Contains($Needle)) { Write-Host "  ok: $Needle" -ForegroundColor Green }
    else { Write-Host "  FAIL: нет «$Needle»" -ForegroundColor Red; $script:failures++ }
}
function Commit([string]$File, [string]$Message) {
    Add-Content -Path (Join-Path $repo $File) -Value (Get-Random)
    Invoke-Git add -A
    Invoke-Git commit -q -m $Message
}

function New-Docx([string]$Path, [object[]]$Rows) {
    $cells = foreach ($r in $Rows) {
        '<w:tr><w:trPr/>' + (($r | ForEach-Object {
            "<w:tc><w:tcPr/><w:p><w:r><w:t xml:space=`"preserve`">$([Security.SecurityElement]::Escape($_))</w:t></w:r></w:p></w:tc>"
        }) -join '') + '</w:tr>'
    }
    # Длинное повторяющееся вступление: deflate выберет динамические коды и обратные ссылки.
    $intro = ('<w:p><w:r><w:t>Механизм проверяет токены доступа и политику перед каждым вызовом.</w:t></w:r></w:p>' * 200)
    $xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>' +
        $intro + '<w:tbl><w:tblPr/>' + ($cells -join '') + '</w:tbl></w:body></w:document>'
    if (Test-Path $Path) { Remove-Item $Path }
    $zip = [IO.Compression.ZipFile]::Open($Path, 'Create')
    $types = $zip.CreateEntry('[Content_Types].xml')
    $w = New-Object IO.StreamWriter($types.Open()); $w.Write('<Types/>'); $w.Close()
    $entry = $zip.CreateEntry('word/document.xml', [IO.Compression.CompressionLevel]::Optimal)
    $w = New-Object IO.StreamWriter($entry.Open(), (New-Object Text.UTF8Encoding $false)); $w.Write($xml); $w.Close()
    $zip.Dispose()
}

$rows = @(
    @('ID', 'Угроза', 'STRIDE'),
    @('T-01', 'Подмена токена при повторном использовании', 'S'),
    @('T-02', 'Изменение политики в памяти процесса', 'Tampering'),
    @('T-03', 'Раскрытие ключа в дампах & логах', 'I, D'),
    @('T-04', 'Обход проверки через IPC', 'Повышение привилегий'),
    @('T-05', 'Отказ от авторства — неприменимо, аудит вне механизма', 'R')
)
New-Docx $doc $rows

# --- настройка ---------------------------------------------------------------
Invoke-Git init -q -b main
Commit 'core.cpp' 'Начальный коммит'
$out = Sq init --repo $repo
Expect $out 'Созданы настройки'
$out = Sq campaign add authz $doc Механизм авторизации
Expect $out 'Кампания AUTHZ добавлена'

# --- Акт I: угрозы из документа ------------------------------------------------
$out = Sq sync
Expect $out 'в документе 5 угроз; новых 5'
Expect $out 'Чертёж скреплён печатью: AUTHZ'
Expect $out 'Угроза разобрана как неприменимая: AUTHZ/T-05'

# --- Акт II: ветка реализации с трейлерами ---------------------------------------
Invoke-Git checkout -q -b impl/AUTHZ/token-cache
Commit 'cache.cpp' "Кэш токенов`n`nThreat: AUTHZ/T-01"
$out = Sq sync
Expect $out 'новых квестов 1, выполнено 0'
$out = Sq status
Expect $out 'impl/AUTHZ/token-cache'
Commit 'cache_test.cpp' "Тест повторного использования`n`nThreat-Test: AUTHZ/T-01, AUTHZ/T-09"
Invoke-Git checkout -q main
Invoke-Git merge -q --no-ff impl/AUTHZ/token-cache -m 'Merge token-cache'
$out = Sq sync
Expect $out 'Квест выполнен: impl/AUTHZ/token-cache'
Expect $out 'Цепочка замкнута: AUTHZ/T-01'

# Ветка без коммитов не считается квестом в работе.
Invoke-Git branch review/AUTHZ/empty
$out = Sq sync
Expect $out 'выполнено 0'

# --- fix-ветка как побочный квест ---------------------------------------------
Invoke-Git checkout -q -b fix/null-check
Commit 'core.cpp' 'Проверка на null'
Invoke-Git checkout -q main
Invoke-Git merge -q --no-ff fix/null-check -m 'Merge fix'
$out = Sq sync
Expect $out 'Исправить ошибку'

# --- Акт III: интеграция -----------------------------------------------------------
$out = Sq point add AUTHZ ipc IPC-шлюз
Expect $out 'запланирована'
Invoke-Git checkout -q -b integ/AUTHZ/ipc
Commit 'ipc.cpp' "Встроить проверку в IPC`n`nIntegration: AUTHZ/ipc"
Invoke-Git checkout -q main
Invoke-Git merge -q --no-ff integ/AUTHZ/ipc -m 'Merge ipc'
$out = Sq sync
Expect $out 'Точка интеграции встроена: AUTHZ/ipc'

# --- squash: ветка удалена, коммитов в main нет ------------------------------------
Invoke-Git checkout -q -b impl/AUTHZ/squashy
Commit 'squash.cpp' 'Часть 1'
$out = Sq sync
Invoke-Git checkout -q main
Invoke-Git merge -q --squash impl/AUTHZ/squashy
Invoke-Git commit -q -m 'Squash'
Invoke-Git branch -q -D impl/AUTHZ/squashy
$out = Sq sync
Expect $out 'удалена, но её коммитов нет в main'
$out = Sq done impl/AUTHZ/squashy
Expect $out 'Квест выполнен: impl/AUTHZ/squashy'

# --- повторная синхронизация ничего не дублирует -----------------------------------
$before = (Get-Content (Join-Path $data 'events.log')).Count
$out = Sq sync
$after = (Get-Content (Join-Path $data 'events.log')).Count
if ($before -eq $after) { Write-Host '  ok: повторный sync идемпотентен' -ForegroundColor Green }
else { Write-Host "  FAIL: повторный sync добавил $($after - $before) событий" -ForegroundColor Red; $script:failures++ }

# --- побочные квесты -------------------------------------------------------------
1..3 | ForEach-Object { $out = Sq side done explain рассказал про RAII-обёртки }
Expect $out '+15 XP'
$out = Sq side done explain ещё раз
Expect $out '+8 XP'
$out = Sq side done report
Expect $out 'Заполнить отчёты за месяц'
$out = Sq side done report
Expect $out 'Очков за это не начислено'
$out = Sq side done 'помог настроить CI'
Expect $out 'Побочный квест: помог настроить CI'
$out = Sq side
Expect $out '4/3 за неделю'

# --- находки и бестиарий ------------------------------------------------------------
$out = Sq find CWE-416 high --threat authz/t-01 UAF в кэше токенов
Expect $out 'Новый класс в бестиарии: CWE-416 Use-After-Free'
Expect $out 'Пророчество сбылось: AUTHZ/T-01'
$out = Sq find 416 medium
Expect $out 'Находка: CWE-416'
$out = Sq find CWE-190 high --campaign AUTHZ переполнение размера
Expect $out 'слепое пятно'
$out = Sq status
Expect $out 'Слепое пятно F3'
Expect $out 'T-09 ссылается на угрозу, которой нет'
$out = Sq lesson F3 проверять арифметику размеров в модели угроз
Expect $out 'Урок извлечён: F3'

# --- документ изменился --------------------------------------------------------------
$rows[2] = @('T-02', 'Изменение политики в памяти процесса', 'T, E')
$rows = $rows[0..2] + $rows[4..5]
New-Docx $doc $rows
$out = Sq sync
Expect $out 'новых 0, изменено 1, убрано 1'

# --- обзорные команды ---------------------------------------------------------------
$out = Sq status
Expect $out 'Акт III «Экспансия»'
$out = Sq threats
Expect $out 'Подмена токена'
$out = Sq bestiary
Expect $out '✓ CWE-416'
$out = Sq log 60
Expect $out 'трейлер threat-test'

if ($script:failures) { Write-Host "`nПровалено проверок: $script:failures" -ForegroundColor Red; exit 1 }
Write-Host "`nВсе проверки пройдены" -ForegroundColor Green
