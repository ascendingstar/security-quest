#include "app.h"

#include "cwe.h"
#include "theme.h"
#include "util.h"
#include "win.h"

#include "imgui_stdlib.h"

#include <algorithm>
#include <cmath>
#include <format>

namespace sq::gui {

namespace {

const char* const kStrideLetters = "STRIDE";
const char* const kStrideNames[6] = {"Подмена", "Изменение", "Отказ от авторства",
                                     "Раскрытие", "Отказ в обслуживании", "Повышение привилегий"};
const char* const kStages[4] = {"design", "impl", "integ", "patrol"};
const char* const kStageNames[4] = {"На бумаге (дизайн)", "В реализации", "При интеграции", "Ревью платформы"};
const char* const kSeverities[4] = {"low", "medium", "high", "critical"};
const ImU32 kSeverityColors[4] = {col::blue, col::gold, col::orange, col::red};

ImU32 skill_color(const std::string& skill) {
    static const std::map<std::string, ImU32> known = {
        {"Память", col::red},           {"Конкурентность", col::violet}, {"Криптография", col::blue},
        {"Доступ", col::orange},        {"Парсинг", col::teal},          {"Дизайн API", col::gold},
        {"Проектирование", col::gold},  {"Реализация", col::blue},       {"Интеграция", col::teal},
        {"Охота", col::red},            {"Наставничество", col::violet}, {"Командная работа", col::blue},
        {"Ремесло", col::orange},       {"Обучение", col::teal},
    };
    auto it = known.find(skill);
    return it != known.end() ? it->second : col::dim;
}

std::string truncate(const std::string& s, size_t max_chars) {
    // Обрезка по символам UTF-8, а не по байтам.
    size_t chars = 0, i = 0;
    for (; i < s.size(); ++i) {
        if ((static_cast<unsigned char>(s[i]) & 0xC0) != 0x80 && chars++ == max_chars) break;
    }
    return i < s.size() ? s.substr(0, i) + "…" : s;
}

std::string describe(const Event& e, const std::vector<SideTemplate>& templates) {
    const std::string& t = e.type;
    if (t == "side") {
        if (e.get("id") == "adhoc") return "Побочный квест: " + e.get("title");
        std::string title = e.get("id");
        for (auto& tpl : templates)
            if (tpl.id == title) title = tpl.title;
        return "Побочный квест: " + title + (e.get("note").empty() ? "" : " — " + e.get("note"));
    }
    if (t == "finding") {
        std::string stage = e.get("stage");
        for (int i = 0; i < 4; ++i)
            if (stage == kStages[i]) stage = kStageNames[i];
        return "Находка " + e.get("id") + ": CWE-" + e.get("cwe") + " (" + e.get("sev") + ", " + stage + ")" +
               (e.get("note").empty() ? "" : " — " + e.get("note"));
    }
    std::string target = e.get("campaign") + "/" + e.get("id");
    if (t == "lesson") return "Урок к " + e.get("ref") + ": " + e.get("text");
    if (t == "threat.add") return "Угроза записана: " + target;
    if (t == "threat.update") return "Угроза изменена: " + target;
    if (t == "threat.drop") return "Угроза убрана из документа: " + target;
    if (t == "threat.restore") return "Угроза возвращена: " + target;
    if (t == "quest.start") return "Новая ветка: " + e.get("branch");
    if (t == "quest.work") return "Работа в ветке: " + e.get("branch");
    if (t == "quest.done") return "Ветка влита: " + e.get("branch") + (e.get("how") == "manual" ? " (вручную)" : "");
    if (t == "link") return "Трейлер " + e.get("kind") + ": " + e.get("target") + " (" + e.get("sha") + ")";
    if (t == "point.plan") return "Точка интеграции: " + e.get("campaign") + "/" + e.get("point");
    return t;
}

// Дорожка из трёх актов кампании.
void act_track(int act) {
    static const char* names[3] = {"Чертёж", "Кузница", "Экспансия"};
    float w = ImGui::GetContentRegionAvail().x;
    float seg = (w - px(8) * 2) / 3;
    ImVec2 p = ImGui::GetCursorScreenPos();
    ImDrawList* dl = ImGui::GetWindowDrawList();
    for (int i = 0; i < 3; ++i) {
        ImU32 c = i + 1 < act ? col::teal : i + 1 == act ? col::gold : col::faint;
        float x = p.x + i * (seg + px(8));
        dl->AddRectFilled(ImVec2(x, p.y), ImVec2(x + seg, p.y + px(5)), c, px(3));
        std::string label = std::format("{} {}", i + 1 < act ? icon::check : "", names[i]);
        dl->AddText(ImVec2(x, p.y + px(9)), i + 1 <= act ? col::text : col::faint, trim(label).c_str());
    }
    ImGui::Dummy(ImVec2(w, px(9) + ImGui::GetFontSize() + px(4)));
}

void stride_tiles(const Campaign& c, float tile_w, float tile_h, bool names) {
    std::string covered = c.stride_covered();
    for (int i = 0; i < 6; ++i) {
        if (i) ImGui::SameLine(0, px(6));
        char letter[2] = {kStrideLetters[i], 0};
        bool lit = covered.find(kStrideLetters[i]) != std::string::npos;
        std::string tip = std::format("{} — {}", kStrideNames[i], lit ? "разобрано в модели угроз" : "в таблице угроз нет");
        tile(letter, names ? kStrideNames[i] : nullptr, ImVec2(tile_w, tile_h), lit, col::teal, tip.c_str());
    }
}

void section_title(const char* icon_glyph, const char* text, ImU32 color = col::gold) {
    ImGui::PushFont(fonts.semibold, 18.0f);
    colored_text(color, icon_glyph);
    ImGui::SameLine();
    ImGui::TextUnformatted(text);
    ImGui::PopFont();
}

bool copy_button(const std::string& text, const char* id) {
    ImGui::PushID(id);
    bool clicked = icon_button(icon::copy, ("Скопировать «" + text + "» для сообщения коммита").c_str());
    ImGui::PopID();
    if (clicked) ImGui::SetClipboardText(text.c_str());
    return clicked;
}

}  // namespace

// ---------------------------------------------------------------------------
// Первый запуск

void App::page_welcome() {
    ImGuiViewport* vp = ImGui::GetMainViewport();
    float w = std::min(px(620), vp->WorkSize.x - px(40));
    ImGui::SetCursorPos(ImVec2((vp->WorkSize.x - w) * 0.5f, std::max(px(40), vp->WorkSize.y * 0.14f)));
    card_begin("welcome", ImVec2(w, 0));
    ImGui::PushFont(fonts.semibold, 30.0f);
    colored_text(col::gold, icon::shield);
    ImGui::SameLine();
    ImGui::TextUnformatted("Security Quest");
    ImGui::PopFont();
    ImGui::Dummy(ImVec2(0, px(4)));
    ImGui::TextWrapped("Игра поверх работы над механизмами безопасности: дизайн-документы, ветки, интеграция, "
                       "находки при ревью и всё, что вокруг. Очки начисляются за снижение риска и рост навыка, "
                       "а не за количество.");
    ImGui::Dummy(ImVec2(0, px(10)));

    subheading("Рабочий репозиторий");
    wrapped_dim("Из него берутся ветки задач и трейлеры коммитов. Программа только читает git и ничего в репозитории "
                "не меняет. Можно указать позже.");
    ImGui::SetNextItemWidth(-px(110));
    ImGui::InputTextWithHint("##repo", "D:\\work\\platform", &welcome_repo_);
    ImGui::SameLine();
    if (ImGui::Button(std::format("{}  Обзор…", icon::folder).c_str(), ImVec2(-1, 0))) {
        std::string picked = pick_folder(hwnd_);
        if (!picked.empty()) welcome_repo_ = picked;
    }
    ImGui::Dummy(ImVec2(0, px(6)));

    std::error_code ec;
    bool portable = fs::equivalent(cfg_.home, exe_dir() / "data", ec);
    wrapped_dim("Данные: " + from_path(cfg_.home.lexically_normal()));
    wrapped_dim(portable ? "Портативный режим: всё хранится в папке data рядом с программой."
                         : "Чтобы сделать версию портативной, создайте папку data рядом с программой.");
    ImGui::Dummy(ImVec2(0, px(10)));

    if (accent_button("Начать", ImVec2(px(160), px(40)))) {
        auto r = init_config(cfg_, welcome_repo_, "");
        if (!r.ok) {
            toast("Не получилось", r.message, col::red);
        } else {
            load();
            toast("Готово", "Настройки созданы. Добавьте первую кампанию — механизм и его дизайн-документ.", col::teal);
            next_auto_sync_ = clock() + 1.0;
        }
    }
    card_end();
}

// ---------------------------------------------------------------------------
// Сводка

std::vector<Hint> App::hints() const {
    std::vector<Hint> out;
    auto add = [&](Hint::Kind k, const char* ic, ImU32 c, std::string text, std::string payload = {}, std::string button = {}) {
        out.push_back({k, ic, c, std::move(text), std::move(payload), std::move(button)});
    };

    if (cfg_.ini.get("repo", "path").empty())
        add(Hint::Kind::Settings, icon::settings, col::blue, "Укажите рабочий репозиторий, чтобы ветки и трейлеры попадали в игру.", {}, "Настройки");
    if (st_.campaigns.empty())
        add(Hint::Kind::AddCampaign, icon::shield, col::gold, "Добавьте первую кампанию: механизм и его дизайн-документ с таблицей угроз.", {}, "Добавить");

    Date now = today();
    for (auto& t : side_templates(cfg_)) {
        if (!t.monthly) continue;
        ContractPeriod p = contract_period(t, now);
        bool done = st_.contracts_done.count(t.id) && st_.contracts_done.at(t.id).count(month_key(p.month));
        if (done) continue;
        std::string text = p.on_time ? std::format("{} за {}: срок {} {}, в срок +{}%.", t.title, month_nominative(p.month.m), p.due.d,
                                                   month_genitive(p.due.m), int(t.early_bonus * 100))
                                     : std::format("{} за {}: срок прошёл, но закрыть ещё можно.", t.title, month_nominative(p.month.m));
        add(Hint::Kind::Side, icon::calendar, col::orange, text, t.id, "Сдано");
    }

    for (auto& e : log_->all()) {
        if (e.type != "finding") continue;
        std::string id = e.get("id");
        if (is_blind_spot(*log_, id) && !st_.finding_lessons.count(id))
            add(Hint::Kind::Lesson, icon::bulb, col::violet,
                std::format("Находка {} (CWE-{}) — слепое пятно модели угроз. Сформулируйте урок: +{} XP.", id, e.get("cwe"),
                            int(cfg_.xp("lesson", 10))),
                id, "Урок");
    }

    int threat_hints = 0;
    for (auto& [code, c] : st_.campaigns) {
        std::string missing;
        std::string covered = c.stride_covered();
        for (int i = 0; i < 6; ++i)
            if (covered.find(kStrideLetters[i]) == std::string::npos) missing += (missing.empty() ? "" : ", ") + std::string(kStrideNames[i]);
        if (!missing.empty() && !c.doc.empty())
            add(Hint::Kind::OpenDoc, icon::document, col::teal, std::format("В {} не разобраны: {}. Допишите таблицу угроз.", code, missing), c.doc,
                "Документ");
        for (auto& [id, t] : c.threats) {
            if (!t.active || t.na || threat_hints >= 3) continue;
            std::string target = code + "/" + id;
            if (!t.mitigated) {
                add(Hint::Kind::Copy, icon::code, col::blue, std::format("{} ждёт митигации: «{}»", target, truncate(t.desc, 60)), "Threat: " + target, "Трейлер");
                ++threat_hints;
            } else if (!t.tested) {
                add(Hint::Kind::Copy, icon::code, col::blue, std::format("{} митигирована, нужен тест", target), "Threat-Test: " + target, "Трейлер");
                ++threat_hints;
            }
        }
        for (auto& [id, p] : c.points) {
            std::string target = code + "/" + id;
            if (p.stage == 0) add(Hint::Kind::Copy, icon::code, col::teal, std::format("Точка {} ждёт встраивания", target), "Integration: " + target, "Трейлер");
            else if (p.stage == 1) add(Hint::Kind::Copy, icon::code, col::teal, std::format("Точка {} встроена, нужен тест", target), "Integration-Test: " + target, "Трейлер");
        }
    }

    {
        std::lock_guard lock(sync_mu_);
        for (auto& line : sync_report_)
            if (line.find("удалена") != std::string::npos || line.find("не удалось") != std::string::npos ||
                line.find("не найден") != std::string::npos || line.find("нет ветки") != std::string::npos ||
                line.find("не задан") != std::string::npos || line.find("дважды") != std::string::npos ||
                line.find("обрезан") != std::string::npos || line.find("zip") != std::string::npos)
                add(Hint::Kind::Info, icon::warning, col::orange, line);
    }
    for (auto& w : st_.warnings)
        if (!starts_with(w, "Слепое пятно")) add(Hint::Kind::Info, icon::warning, col::orange, w);

    if (out.size() > 8) out.resize(8);
    return out;
}

void App::run_hint(const Hint& h) {
    switch (h.kind) {
        case Hint::Kind::Copy:
            ImGui::SetClipboardText(h.payload.c_str());
            toast("Скопировано", "Вставьте в сообщение коммита отдельной строкой: " + h.payload, col::blue);
            break;
        case Hint::Kind::Side: act([&] { return record_side(cfg_, *log_, h.payload, ""); }); break;
        case Hint::Kind::Lesson:
            lesson_form_ = {true, h.payload, ""};
            break;
        case Hint::Kind::AddCampaign: campaign_form_ = {true, "", "", "", ""}; break;
        case Hint::Kind::Settings: page = Page::Settings; break;
        case Hint::Kind::OpenDoc: shell_open(h.payload); break;
        case Hint::Kind::Sync: request_sync(); break;
        case Hint::Kind::Info: break;
    }
}

void App::page_overview() {
    auto list = hints();
    if (!list.empty()) {
        card_begin("hints");
        section_title(icon::bulb, "Что дальше");
        ImGui::Dummy(ImVec2(0, px(2)));
        for (size_t i = 0; i < list.size(); ++i) {
            const Hint& h = list[i];
            ImGui::PushID(int(i));
            colored_text(h.color, h.icon);
            ImGui::SameLine(0, px(10));
            float button_w = h.button.empty() ? 0 : ImGui::CalcTextSize(h.button.c_str()).x + px(28);
            ImGui::PushTextWrapPos(ImGui::GetCursorPosX() + ImGui::GetContentRegionAvail().x - button_w - px(10));
            ImGui::TextWrapped("%s", h.text.c_str());
            ImGui::PopTextWrapPos();
            if (!h.button.empty()) {
                ImGui::SameLine(ImGui::GetCursorPosX() + ImGui::GetContentRegionAvail().x - button_w + px(8));
                if (ImGui::SmallButton(h.button.c_str())) run_hint(h);
                if (h.kind == Hint::Kind::Copy) tooltip(("Скопировать: " + h.payload).c_str());
            }
            ImGui::PopID();
        }
        card_end();
        ImGui::Dummy(ImVec2(0, px(4)));
    }

    if (!ImGui::BeginTable("overview", 2, ImGuiTableFlags_SizingStretchProp)) return;
    ImGui::TableSetupColumn("left", ImGuiTableColumnFlags_WidthStretch, 0.6f);
    ImGui::TableSetupColumn("right", ImGuiTableColumnFlags_WidthStretch, 0.4f);
    ImGui::TableNextRow();
    ImGui::TableNextColumn();

    for (auto& [code, c] : st_.campaigns) {
        card_begin(("camp" + code).c_str());
        ImGui::PushFont(fonts.semibold, 20.0f);
        ImGui::TextUnformatted(code.c_str());
        ImGui::PopFont();
        if (!c.title.empty()) {
            ImGui::SameLine();
            dim_text("%s", c.title.c_str());
        }
        ImGui::SameLine(ImGui::GetCursorPosX() + ImGui::GetContentRegionAvail().x - px(90));
        if (ImGui::SmallButton(("Открыть##" + code).c_str())) {
            selected_campaign_ = code;
            page = Page::Campaigns;
        }
        act_track(c.act());

        int threats = 0, chained = 0;
        for (auto& [_, t] : c.threats)
            if (t.active && !t.na) {
                ++threats;
                chained += t.chained;
            }
        ImGui::Text("Угрозы: цепочек замкнуто %d из %d", chained, threats);
        bar(threats ? float(chained) / threats : 0.0f, ImVec2(0, px(8)), col::teal, IM_COL32(120, 230, 180, 255));
        ImGui::Dummy(ImVec2(0, px(4)));
        stride_tiles(c, px(40), px(34), false);
        if (!c.points.empty()) {
            int embedded = 0, tested = 0;
            for (auto& [_, p] : c.points) {
                embedded += p.stage >= 1;
                tested += p.stage >= 2;
            }
            ImGui::SameLine(0, px(18));
            ImGui::BeginGroup();
            dim_text("Точки интеграции");
            ImGui::Text("%d из %zu встроено, %d с тестами", embedded, c.points.size(), tested);
            ImGui::EndGroup();
        }
        card_end();
        ImGui::Dummy(ImVec2(0, px(2)));
    }
    if (st_.campaigns.empty()) {
        card_begin("nocamp");
        section_title(icon::shield, "Кампаний пока нет");
        wrapped_dim("Кампания — это механизм безопасности: дизайн-документ с таблицей угроз, ветки реализации и точки интеграции.");
        if (accent_button("Добавить кампанию")) campaign_form_ = {true, "", "", "", ""};
        card_end();
    }

    std::vector<const Quest*> active;
    for (auto& [_, q] : st_.quests)
        if (!q.done && q.work) active.push_back(&q);
    card_begin("activeq");
    section_title(icon::code, "Ветки в работе", col::blue);
    if (active.empty()) wrapped_dim("Нет. Ветки вида impl/КОД/… появляются здесь после синхронизации.");
    for (auto* q : active) {
        pill(q->kind.c_str(), col::blue);
        ImGui::SameLine();
        ImGui::TextUnformatted(q->branch.c_str());
        ImGui::SameLine();
        dim_text("с %s", q->started.c_str());
    }
    card_end();

    ImGui::TableNextColumn();
    card_begin("skills");
    section_title(icon::star, "Навыки", col::violet);
    std::vector<std::pair<std::string, int>> skills(st_.skills.begin(), st_.skills.end());
    std::ranges::sort(skills, [](auto& a, auto& b) { return a.second > b.second; });
    int top = skills.empty() ? 1 : skills.front().second;
    if (skills.empty()) wrapped_dim("Навыки растут от находок, квестов и побочных дел.");
    for (size_t i = 0; i < skills.size() && i < 8; ++i) {
        ImGui::TextUnformatted(skills[i].first.c_str());
        std::string v = std::to_string(skills[i].second);
        ImGui::SameLine(ImGui::GetCursorPosX() + ImGui::GetContentRegionAvail().x - ImGui::CalcTextSize(v.c_str()).x);
        dim_text("%s", v.c_str());
        ImU32 c = skill_color(skills[i].first);
        bar(float(skills[i].second) / top, ImVec2(0, px(6)), alpha(c, 0.7f), c);
    }
    card_end();

    card_begin("awards");
    section_title(icon::history, "Последние награды");
    if (st_.awards.empty()) wrapped_dim("Здесь появятся очки за сделанное.");
    for (size_t n = 0, i = st_.awards.size(); i-- > 0 && n < 8; ++n) {
        const Award& a = st_.awards[i];
        ImGui::PushFont(fonts.semibold, 0.0f);
        colored_text(col::gold, std::format("+{}", a.xp).c_str());
        ImGui::PopFont();
        ImGui::SameLine(px(56));
        ImGui::PushTextWrapPos(0);
        ImGui::TextWrapped("%s", a.reason.c_str());
        ImGui::PopTextWrapPos();
    }
    card_end();
    ImGui::EndTable();
}

// ---------------------------------------------------------------------------
// Квесты

void App::page_quests() {
    heading("Побочные квесты");
    wrapped_dim("Работа вокруг основной. Сверх недельного лимита квест засчитывается, но приносит вдвое меньше.");
    ImGui::Dummy(ImVec2(0, px(4)));

    auto templates = side_templates(cfg_);
    Date now = today();
    std::string week = week_start(now);
    int columns = std::max(1, int(ImGui::GetContentRegionAvail().x / px(300)));
    if (ImGui::BeginTable("sides", columns, ImGuiTableFlags_SizingStretchSame)) {
        for (auto& t : templates) {
            ImGui::TableNextColumn();
            ImGui::PushID(t.id.c_str());
            card_begin("card");
            subheading(t.title.c_str());
            pill(std::format("{} XP", int(t.xp)).c_str(), col::gold);
            ImGui::SameLine();
            pill(t.skill.c_str(), skill_color(t.skill));

            bool done_month = false;
            if (t.monthly) {
                ContractPeriod p = contract_period(t, now);
                done_month = st_.contracts_done.count(t.id) && st_.contracts_done.at(t.id).count(month_key(p.month));
                if (done_month) colored_text(col::teal, std::format("{} {} сдан", icon::check, month_nominative(p.month.m)).c_str());
                else if (p.on_time) dim_text("%s: срок %d %s, в срок +%d%%", month_nominative(p.month.m).c_str(), p.due.d,
                                             month_genitive(p.due.m).c_str(), int(t.early_bonus * 100));
                else colored_text(col::orange, std::format("{}: срок прошёл, закрыть ещё можно", month_nominative(p.month.m)).c_str());
            } else {
                int n = st_.side_counts.count(week) && st_.side_counts.at(week).count(t.id) ? st_.side_counts.at(week).at(t.id) : 0;
                ImVec2 p = ImGui::GetCursorScreenPos();
                ImDrawList* dl = ImGui::GetWindowDrawList();
                float r = px(5), y = p.y + ImGui::GetFontSize() * 0.5f;
                int dots = std::max(t.weekly_cap, n);
                for (int i = 0; i < dots && i < 12; ++i) {
                    ImVec2 c(p.x + r + i * (r * 2 + px(5)), y);
                    if (i < n) dl->AddCircleFilled(c, r, i < t.weekly_cap ? col::gold : col::orange);
                    else dl->AddCircle(c, r, col::faint, 0, 1.5f);
                }
                ImGui::Dummy(ImVec2(std::min(dots, 12) * (r * 2 + px(5)), ImGui::GetFontSize()));
                ImGui::SameLine();
                dim_text("%d из %d на этой неделе", n, t.weekly_cap);
            }

            std::string& note = side_notes_[t.id];
            ImGui::SetNextItemWidth(-1);
            ImGui::InputTextWithHint("##note", "заметка, необязательно", &note);
            ImGui::BeginDisabled(done_month);
            if (accent_button(t.monthly ? "Сдано" : "Засчитать", ImVec2(-1, 0))) {
                act([&] { return record_side(cfg_, *log_, t.id, note); });
                note.clear();
            }
            ImGui::EndDisabled();
            card_end();
            ImGui::PopID();
        }
        ImGui::EndTable();
    }

    ImGui::Dummy(ImVec2(0, px(4)));
    card_begin("adhoc");
    subheading("Свой побочный квест");
    wrapped_dim(std::format("Что-то полезное без шаблона. {} XP, до {} раз в неделю полностью. Постоянные дела лучше "
                            "добавить шаблоном в config.ini.",
                            int(cfg_.xp("side_adhoc", 10)), int(cfg_.xp("side_adhoc_cap", 5))));
    ImGui::SetNextItemWidth(-px(140));
    bool enter = ImGui::InputTextWithHint("##adhoc", "Например: помог настроить CI", &adhoc_text_, ImGuiInputTextFlags_EnterReturnsTrue);
    ImGui::SameLine();
    if ((accent_button("Засчитать##adhoc", ImVec2(-1, 0)) || enter) && !trim(adhoc_text_).empty()) {
        act([&] { return record_side(cfg_, *log_, adhoc_text_, ""); });
        adhoc_text_.clear();
    }
    card_end();

    ImGui::Dummy(ImVec2(0, px(8)));
    heading("Ветки");
    wrapped_dim("Ветка с коммитами становится квестом, влитая в main — выполненным. Если ветка влита через squash, "
                "закройте её вручную.");
    std::vector<const Quest*> active, done;
    for (auto& [_, q] : st_.quests) {
        if (q.done) done.push_back(&q);
        else if (q.work) active.push_back(&q);
    }
    if (active.empty()) {
        dim_text("В работе ничего нет.");
    } else if (ImGui::BeginTable("branches", 4, ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersInnerH | ImGuiTableFlags_SizingStretchProp)) {
        ImGui::TableSetupColumn("Ветка", ImGuiTableColumnFlags_WidthStretch, 3.0f);
        ImGui::TableSetupColumn("Тип", ImGuiTableColumnFlags_WidthStretch, 1.0f);
        ImGui::TableSetupColumn("С", ImGuiTableColumnFlags_WidthStretch, 1.0f);
        ImGui::TableSetupColumn("", ImGuiTableColumnFlags_WidthFixed, px(170));
        ImGui::TableHeadersRow();
        for (auto* q : active) {
            ImGui::PushID(q->branch.c_str());
            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            ImGui::TextUnformatted(q->branch.c_str());
            ImGui::TableNextColumn();
            pill(q->kind.c_str(), col::blue);
            ImGui::TableNextColumn();
            dim_text("%s", q->started.c_str());
            ImGui::TableNextColumn();
            if (ImGui::SmallButton("Закрыть вручную")) {
                confirm_close_branch_ = q->branch;
                ImGui::OpenPopup("confirm_close");
            }
            if (ImGui::BeginPopup("confirm_close")) {
                ImGui::Text("Отметить %s выполненной?", confirm_close_branch_.c_str());
                dim_text("Нужно, если ветку влили через squash и программа этого не видит.");
                if (accent_button("Да, выполнена")) {
                    std::string branch = confirm_close_branch_;
                    act([&] { return close_quest(cfg_, *log_, branch); });
                    ImGui::CloseCurrentPopup();
                }
                ImGui::SameLine();
                if (ImGui::Button("Отмена")) ImGui::CloseCurrentPopup();
                ImGui::EndPopup();
            }
            ImGui::PopID();
        }
        ImGui::EndTable();
    }
    if (!done.empty() && ImGui::CollapsingHeader(std::format("Выполненные ветки ({})", done.size()).c_str())) {
        for (auto* q : done) {
            colored_text(col::teal, icon::check);
            ImGui::SameLine();
            ImGui::TextUnformatted(q->branch.c_str());
        }
    }
}

// ---------------------------------------------------------------------------
// Кампании

void App::page_campaigns() {
    ImGui::BeginChild("camplist", ImVec2(px(220), 0), ImGuiChildFlags_Borders | ImGuiChildFlags_AlwaysUseWindowPadding);
    subheading("Кампании");
    for (auto& [code, c] : st_.campaigns) {
        std::string label = c.title.empty() ? code : code + "\n" + truncate(c.title, 24);
        if (ImGui::Selectable((label + "##" + code).c_str(), selected_campaign_ == code, 0, ImVec2(0, ImGui::GetFontSize() * (c.title.empty() ? 1.4f : 2.6f))))
            selected_campaign_ = code;
    }
    ImGui::Dummy(ImVec2(0, px(6)));
    if (ImGui::Button(std::format("{}  Кампания", icon::add).c_str(), ImVec2(-1, 0))) campaign_form_ = {true, "", "", "", ""};
    ImGui::EndChild();
    ImGui::SameLine();

    ImGui::BeginChild("campdetail", ImVec2(0, 0), ImGuiChildFlags_AlwaysUseWindowPadding);
    ImGui::PushStyleColor(ImGuiCol_ChildBg, col::bg);
    auto it = st_.campaigns.find(selected_campaign_);
    if (it == st_.campaigns.end()) {
        heading("Кампаний пока нет");
        wrapped_dim("Добавьте механизм и его дизайн-документ. В документе нужна таблица угроз: первая колонка — ID "
                    "вида T-01, вторая — описание, третья — класс STRIDE (буквы S T R I D E или русские названия).");
        if (accent_button("Добавить кампанию")) campaign_form_ = {true, "", "", "", ""};
        ImGui::PopStyleColor();
        ImGui::EndChild();
        return;
    }
    const Campaign& c = it->second;

    ImGui::PushFont(fonts.semibold, 26.0f);
    ImGui::TextUnformatted(c.code.c_str());
    ImGui::PopFont();
    if (!c.title.empty()) {
        ImGui::SameLine();
        ImGui::SetCursorPosY(ImGui::GetCursorPosY() + px(6));
        dim_text("%s", c.title.c_str());
    }
    if (!c.doc.empty()) {
        if (ImGui::Button(std::format("{}  Открыть документ", icon::document).c_str())) shell_open(c.doc);
        tooltip(c.doc.c_str());
        ImGui::SameLine();
    }
    if (ImGui::Button(std::format("{}  Точка интеграции", icon::add).c_str())) {
        point_form_ = {true, 0, "", "", ""};
        int i = 0;
        for (auto& [code, _] : st_.campaigns) {
            if (code == c.code) point_form_.campaign = i;
            ++i;
        }
    }
    ImGui::SameLine();
    if (ImGui::Button(std::format("{}  Перечитать документ", icon::sync).c_str())) request_sync();
    ImGui::Dummy(ImVec2(0, px(4)));
    act_track(c.act());
    ImGui::Dummy(ImVec2(0, px(4)));

    section_title(icon::shield, "Сетка STRIDE", col::teal);
    float tw = (ImGui::GetContentRegionAvail().x - px(6) * 5) / 6;
    stride_tiles(c, tw, px(62), true);
    if (c.sealed) colored_text(col::teal, std::format("{} Чертёж скреплён печатью", icon::check).c_str());
    ImGui::Dummy(ImVec2(0, px(8)));

    section_title(icon::document, "Угрозы");
    wrapped_dim("Цепочка замыкается, когда в main есть коммит с трейлером Threat: и коммит с Threat-Test:. Кнопки копируют трейлер.");
    if (ImGui::BeginTable("threats", 6, ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersInnerH | ImGuiTableFlags_SizingStretchProp)) {
        ImGui::TableSetupColumn("ID", ImGuiTableColumnFlags_WidthFixed, px(56));
        ImGui::TableSetupColumn("Описание", ImGuiTableColumnFlags_WidthStretch, 4.0f);
        ImGui::TableSetupColumn("STRIDE", ImGuiTableColumnFlags_WidthFixed, px(70));
        ImGui::TableSetupColumn("Митигация", ImGuiTableColumnFlags_WidthFixed, px(110));
        ImGui::TableSetupColumn("Тест", ImGuiTableColumnFlags_WidthFixed, px(90));
        ImGui::TableSetupColumn("", ImGuiTableColumnFlags_WidthFixed, px(40));
        ImGui::TableHeadersRow();
        for (auto& [id, t] : c.threats) {
            if (!t.active) continue;
            std::string target = c.code + "/" + id;
            ImGui::PushID(id.c_str());
            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            ImGui::PushFont(fonts.semibold, 0.0f);
            ImGui::TextUnformatted(id.c_str());
            ImGui::PopFont();
            ImGui::TableNextColumn();
            if (t.na) ImGui::PushStyleColor(ImGuiCol_Text, col::faint);
            ImGui::TextWrapped("%s", t.desc.c_str());
            if (t.na) ImGui::PopStyleColor();
            ImGui::TableNextColumn();
            dim_text("%s", t.stride.empty() ? "—" : t.stride.c_str());
            if (t.na) {
                ImGui::TableNextColumn();
                dim_text("неприменимо");
                ImGui::TableNextColumn();
                ImGui::TableNextColumn();
            } else {
                ImGui::TableNextColumn();
                ImGui::AlignTextToFramePadding();
                if (t.mitigated) colored_text(col::teal, std::format("{} в main", icon::check).c_str());
                else {
                    dim_text("ждёт");
                    ImGui::SameLine();
                    copy_button("Threat: " + target, "m");
                }
                ImGui::TableNextColumn();
                ImGui::AlignTextToFramePadding();
                if (t.tested) colored_text(col::teal, std::format("{} есть", icon::check).c_str());
                else {
                    dim_text("ждёт");
                    ImGui::SameLine();
                    copy_button("Threat-Test: " + target, "t");
                }
                ImGui::TableNextColumn();
                if (t.chained) {
                    colored_text(col::gold, icon::star);
                    tooltip("Цепочка замкнута");
                }
            }
            ImGui::PopID();
        }
        ImGui::EndTable();
    }
    if (c.threats.empty()) wrapped_dim("Угроз пока нет. Проверьте, что в документе есть таблица с ID вида T-01, и нажмите «Перечитать документ».");

    ImGui::Dummy(ImVec2(0, px(8)));
    section_title(icon::flag, "Точки интеграции", col::blue);
    if (c.points.empty()) wrapped_dim("Места платформы, куда встраивается механизм. Запланируйте их кнопкой выше или трейлером Integration: КОД/точка.");
    if (!c.points.empty() && ImGui::BeginTable("points", 4, ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersInnerH | ImGuiTableFlags_SizingStretchProp)) {
        ImGui::TableSetupColumn("Точка", ImGuiTableColumnFlags_WidthStretch, 1.0f);
        ImGui::TableSetupColumn("Описание", ImGuiTableColumnFlags_WidthStretch, 2.0f);
        ImGui::TableSetupColumn("Стадия", ImGuiTableColumnFlags_WidthStretch, 2.0f);
        ImGui::TableSetupColumn("", ImGuiTableColumnFlags_WidthFixed, px(40));
        ImGui::TableHeadersRow();
        for (auto& [id, p] : c.points) {
            std::string target = c.code + "/" + id;
            ImGui::PushID(id.c_str());
            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            ImGui::TextUnformatted(id.c_str());
            ImGui::TableNextColumn();
            dim_text("%s", p.title.c_str());
            ImGui::TableNextColumn();
            static const char* stages[3] = {"запланирована", "встроена", "с тестами"};
            for (int s = 0; s < 3; ++s) {
                if (s) ImGui::SameLine(0, px(4));
                pill(stages[s], s <= p.stage ? (s == 2 ? col::teal : col::blue) : col::faint, s == p.stage);
            }
            ImGui::TableNextColumn();
            if (p.stage == 0) copy_button("Integration: " + target, "i");
            else if (p.stage == 1) copy_button("Integration-Test: " + target, "it");
            ImGui::PopID();
        }
        ImGui::EndTable();
    }
    ImGui::PopStyleColor();
    ImGui::EndChild();
}

// ---------------------------------------------------------------------------
// Бестиарий

void App::page_bestiary() {
    int caught_known = 0;
    for (auto& c : cwe_catalog()) caught_known += st_.bestiary.count(c.id) != 0;
    heading("Бестиарий");
    wrapped_dim(std::format("Поймано {} из {} классов справочника. Пустые клетки — то, чего вы ещё не встречали: "
                            "подсказка, где поискать.",
                            caught_known, cwe_catalog().size()));
    ImGui::Dummy(ImVec2(0, px(4)));

    std::vector<std::string> groups;
    for (auto& c : cwe_catalog())
        if (std::ranges::find(groups, c.skill) == groups.end()) groups.push_back(c.skill);

    ImVec2 tsize(px(150), px(74));
    for (auto& g : groups) {
        int total = 0, caught = 0;
        for (auto& c : cwe_catalog())
            if (c.skill == g) {
                ++total;
                caught += st_.bestiary.count(c.id) != 0;
            }
        ImU32 color = skill_color(g);
        ImGui::PushFont(fonts.semibold, 18.0f);
        colored_text(color, g.c_str());
        ImGui::PopFont();
        ImGui::SameLine();
        dim_text("%d / %d", caught, total);

        float avail = ImGui::GetContentRegionAvail().x;
        int per_row = std::max(1, int((avail + px(8)) / (tsize.x + px(8))));
        int i = 0;
        for (auto& c : cwe_catalog()) {
            if (c.skill != g) continue;
            if (i % per_row) ImGui::SameLine(0, px(8));
            int n = st_.bestiary.count(c.id) ? st_.bestiary.at(c.id) : 0;
            std::string big = std::format("CWE-{}", c.id);
            std::string tip = n ? std::format("{} — поймано {} раз", c.name, n) : std::format("{} — ещё не встречалось", c.name);
            tile(big.c_str(), c.name, tsize, n > 0, color, tip.c_str());
            ++i;
        }
        ImGui::Dummy(ImVec2(0, px(8)));
    }

    std::vector<std::pair<int, int>> other;
    for (auto& [id, n] : st_.bestiary)
        if (!find_cwe(id)) other.push_back({id, n});
    if (!other.empty()) {
        subheading("Вне справочника");
        for (auto& [id, n] : other) {
            pill(std::format("CWE-{} ×{}", id, n).c_str(), col::red);
            ImGui::SameLine();
        }
        ImGui::NewLine();
    }
}

// ---------------------------------------------------------------------------
// Журнал

void App::page_journal() {
    heading("Журнал");
    wrapped_dim("Все события и очки за них. Очки пересчитываются из журнала, поэтому изменённые веса в config.ini "
                "применяются и к прошлому.");
    ImGui::SetNextItemWidth(px(320));
    ImGui::InputTextWithHint("##filter", "Поиск по журналу", &journal_filter_);

    auto templates = side_templates(cfg_);
    std::map<size_t, std::pair<int, std::string>> awards;
    for (auto& a : st_.awards) {
        auto& slot = awards[a.event];
        slot.first += a.xp;
        slot.second += (slot.second.empty() ? "" : "; ") + a.reason;
    }
    std::vector<size_t> rows;
    const auto& all = log_->all();
    std::string filter = journal_filter_;
    for (size_t i = all.size(); i-- > 0;) {
        if (!filter.empty()) {
            std::string hay = describe(all[i], templates) + " " + (awards.count(i) ? awards[i].second : "");
            if (hay.find(filter) == std::string::npos) continue;
        }
        rows.push_back(i);
    }

    if (ImGui::BeginTable("journal", 4,
                          ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersInnerH | ImGuiTableFlags_ScrollY | ImGuiTableFlags_SizingStretchProp,
                          ImVec2(0, ImGui::GetContentRegionAvail().y))) {
        ImGui::TableSetupScrollFreeze(0, 1);
        ImGui::TableSetupColumn("Когда", ImGuiTableColumnFlags_WidthFixed, px(130));
        ImGui::TableSetupColumn("XP", ImGuiTableColumnFlags_WidthFixed, px(50));
        ImGui::TableSetupColumn("Событие", ImGuiTableColumnFlags_WidthStretch, 3.0f);
        ImGui::TableSetupColumn("За что", ImGuiTableColumnFlags_WidthStretch, 2.0f);
        ImGui::TableHeadersRow();
        ImGuiListClipper clipper;
        clipper.Begin(int(rows.size()));
        while (clipper.Step()) {
            for (int r = clipper.DisplayStart; r < clipper.DisplayEnd; ++r) {
                size_t i = rows[size_t(r)];
                const Event& e = all[i];
                ImGui::TableNextRow();
                ImGui::TableNextColumn();
                std::string when = e.time.size() >= 16 ? e.time.substr(0, 10) + " " + e.time.substr(11, 5) : e.time;
                dim_text("%s", when.c_str());
                ImGui::TableNextColumn();
                if (awards.count(i)) colored_text(col::gold, std::format("+{}", awards[i].first).c_str());
                ImGui::TableNextColumn();
                ImGui::TextUnformatted(describe(e, templates).c_str());
                ImGui::TableNextColumn();
                if (awards.count(i)) dim_text("%s", awards[i].second.c_str());
            }
        }
        ImGui::EndTable();
    }
}

// ---------------------------------------------------------------------------
// Настройки

void App::page_settings() {
    heading("Настройки");
    ImGui::Dummy(ImVec2(0, px(4)));

    card_begin("repo");
    section_title(icon::code, "Репозиторий", col::blue);
    wrapped_dim("Программа только читает git: ветки и трейлеры коммитов в основной ветке.");
    ImGui::SetNextItemWidth(-px(110));
    ImGui::InputTextWithHint("##repo", "D:\\work\\platform", &settings_repo_);
    ImGui::SameLine();
    if (ImGui::Button(std::format("{}  Обзор…", icon::folder).c_str(), ImVec2(-1, 0))) {
        std::string picked = pick_folder(hwnd_);
        if (!picked.empty()) settings_repo_ = picked;
    }
    ImGui::SetNextItemWidth(px(200));
    ImGui::InputTextWithHint("Основная ветка", "main", &settings_main_);
    if (accent_button("Сохранить##repo")) {
        auto r = init_config(cfg_, trim(settings_repo_), trim(settings_main_));
        if (r.ok) {
            toast("Сохранено", "Репозиторий обновлён, запускаю синхронизацию", col::teal);
            request_sync();
        } else {
            toast("Не получилось", r.message, col::red);
        }
    }
    card_end();

    card_begin("sync");
    section_title(icon::sync, "Синхронизация", col::teal);
    ImGui::SetNextItemWidth(px(260));
    ImGui::SliderInt("##minutes", &settings_sync_minutes_, 0, 60, settings_sync_minutes_ ? "каждые %d мин" : "только вручную");
    ImGui::SameLine();
    if (ImGui::Button("Сохранить##sync")) {
        set_ini_value(cfg_.config_file(), "gui", "sync_minutes", std::to_string(settings_sync_minutes_));
        reload_config(cfg_);
        next_auto_sync_ = clock() + settings_sync_minutes_ * 60.0;
        toast("Сохранено", settings_sync_minutes_ ? std::format("Синхронизация каждые {} мин", settings_sync_minutes_) : "Синхронизация только вручную", col::teal);
    }
    dim_text("Последняя синхронизация: %s", last_sync_label_.c_str());
    {
        std::lock_guard lock(sync_mu_);
        for (auto& line : sync_report_) dim_text("  %s", line.c_str());
    }
    card_end();

    card_begin("window");
    section_title(icon::settings, "Окно", col::dim);
    bool to_tray = close_to_tray();
    if (ImGui::Checkbox("Закрытие окна сворачивает в трей", &to_tray)) {
        set_ini_value(cfg_.config_file(), "gui", "close_to_tray", to_tray ? "1" : "0");
        reload_config(cfg_);
    }
    wrapped_dim("В трее программа продолжает синхронизацию и показывает уведомления о наградах. Выйти — через меню значка в трее.");
    card_end();

    card_begin("data");
    section_title(icon::folder, "Данные", col::gold);
    ImGui::TextWrapped("%s", from_path(cfg_.home).c_str());
    wrapped_dim("config.ini — веса очков, шаблоны побочных квестов, кампании. events.log — журнал событий; в нём "
                "описания угроз и находок, никуда его не копируйте.");
    if (ImGui::Button(std::format("{}  Открыть папку", icon::folder).c_str())) shell_open(from_path(cfg_.home));
    ImGui::SameLine();
    if (ImGui::Button(std::format("{}  Открыть config.ini", icon::edit).c_str())) shell_open(from_path(cfg_.config_file()));
    ImGui::SameLine();
    if (ImGui::Button(std::format("{}  Перечитать настройки", icon::sync).c_str())) {
        load();
        toast("Готово", "Настройки и журнал перечитаны", col::teal);
    }
    card_end();

    card_begin("cheatsheet");
    section_title(icon::info, "Шпаргалка", col::violet);
    dim_text("Ветки задач");
    ImGui::BulletText("impl/КОД/описание — реализация механизма");
    ImGui::BulletText("integ/КОД/описание — встраивание в платформу");
    ImGui::BulletText("fix/описание — исправление ошибки (побочный квест)");
    ImGui::BulletText("review/КОД/описание — ревью");
    ImGui::Dummy(ImVec2(0, px(4)));
    dim_text("Трейлеры в сообщении коммита (отдельными строками в конце)");
    for (const char* t : {"Threat: AUTHZ/T-03", "Threat-Test: AUTHZ/T-03", "Integration: AUTHZ/ipc", "Integration-Test: AUTHZ/ipc"}) {
        ImGui::BulletText("%s", t);
        ImGui::SameLine();
        copy_button(t, t);
    }
    card_end();
}

bool App::close_to_tray() const {
    return cfg_.ini.num("gui", "close_to_tray", 1) != 0;
}

// ---------------------------------------------------------------------------
// Диалоги

int App::estimate_finding_xp() const {
    std::string sev = kSeverities[finding_.severity];
    std::string stage = kStages[finding_.stage];
    int cwe = 0;
    if (finding_.cwe_index >= 0) cwe = cwe_catalog()[size_t(finding_.cwe_index)].id;
    else cwe = std::atoi(finding_.cwe_text.c_str());
    int seen = st_.bestiary.count(cwe) ? st_.bestiary.at(cwe) : 0;
    double novelty = seen == 0 ? cfg_.xp("novelty", 1.5) : std::max(0.3, std::pow(cfg_.xp("repeat_decay", 0.8), seen));
    double xp = cfg_.xp(("sev_" + sev).c_str(), 5) * cfg_.xp(("stage_" + stage).c_str(), 1.0) * novelty;
    if (finding_.threat > 0) xp += cfg_.xp("prophecy", 20);
    else if (finding_.campaign > 0 && (finding_.stage == 1 || finding_.stage == 2) && !trim(finding_.lesson).empty())
        xp += cfg_.xp("lesson", 10);
    return int(std::lround(xp));
}

void App::dialog_finding() {
    const char* id = "Записать находку";
    if (finding_.open) {
        ImGui::OpenPopup(id);
        finding_.open = false;
    }
    ImGui::SetNextWindowSize(ImVec2(px(620), 0));
    ImGui::SetNextWindowPos(ImGui::GetMainViewport()->GetCenter(), ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
    if (!ImGui::BeginPopupModal(id, nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings)) return;

    std::vector<std::string> codes = {"— нет, ревью платформы —"};
    for (auto& [code, _] : st_.campaigns) codes.push_back(code);
    finding_.campaign = std::min(finding_.campaign, int(codes.size()) - 1);

    // CWE: поиск по справочнику или свой номер.
    subheading("Класс уязвимости");
    std::string preview = finding_.cwe_index >= 0
                              ? std::format("CWE-{}  {}", cwe_catalog()[size_t(finding_.cwe_index)].id, cwe_catalog()[size_t(finding_.cwe_index)].name)
                              : (finding_.cwe_text.empty() ? std::string("Выберите из справочника…") : "CWE-" + finding_.cwe_text);
    ImGui::SetNextItemWidth(px(400));
    if (ImGui::BeginCombo("##cwe", preview.c_str(), ImGuiComboFlags_HeightLarge)) {
        if (ImGui::IsWindowAppearing()) ImGui::SetKeyboardFocusHere();
        ImGui::SetNextItemWidth(-1);
        ImGui::InputTextWithHint("##cwefilter", "поиск: номер или название", &finding_.filter);
        for (size_t i = 0; i < cwe_catalog().size(); ++i) {
            auto& c = cwe_catalog()[i];
            std::string label = std::format("CWE-{}  {}", c.id, c.name);
            if (!finding_.filter.empty() && label.find(finding_.filter) == std::string::npos) continue;
            bool caught = st_.bestiary.count(c.id) != 0;
            if (ImGui::Selectable((label + (caught ? "" : "   ★ новый") + "##" + std::to_string(c.id)).c_str(), finding_.cwe_index == int(i))) {
                finding_.cwe_index = int(i);
                finding_.cwe_text.clear();
            }
        }
        ImGui::EndCombo();
    }
    ImGui::SameLine();
    ImGui::SetNextItemWidth(-1);
    if (ImGui::InputTextWithHint("##cwenum", "или номер", &finding_.cwe_text, ImGuiInputTextFlags_CharsDecimal) && !finding_.cwe_text.empty())
        finding_.cwe_index = -1;

    ImGui::Dummy(ImVec2(0, px(4)));
    subheading("Серьёзность");
    for (int i = 0; i < 4; ++i) {
        if (i) ImGui::SameLine();
        bool on = finding_.severity == i;
        ImGui::PushStyleColor(ImGuiCol_Button, on ? kSeverityColors[i] : col::panel_hi);
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, on ? kSeverityColors[i] : alpha(kSeverityColors[i], 0.35f));
        ImGui::PushStyleColor(ImGuiCol_Text, on ? col::bg : col::text);
        if (ImGui::Button(kSeverities[i], ImVec2(px(100), 0))) finding_.severity = i;
        ImGui::PopStyleColor(3);
    }

    ImGui::Dummy(ImVec2(0, px(4)));
    subheading("Где найдено");
    ImGui::SetNextItemWidth(px(260));
    int prev_campaign = finding_.campaign;
    std::vector<const char*> code_ptrs;
    for (auto& c : codes) code_ptrs.push_back(c.c_str());
    ImGui::Combo("Кампания", &finding_.campaign, code_ptrs.data(), int(code_ptrs.size()));
    if (prev_campaign != finding_.campaign) {
        finding_.threat = 0;
        if (finding_.campaign > 0 && finding_.stage == 3) finding_.stage = 1;
        if (finding_.campaign == 0) finding_.stage = 3;
    }
    for (int i = 0; i < 4; ++i) {
        if (i) ImGui::SameLine();
        ImGui::RadioButton(kStageNames[i], &finding_.stage, i);
    }
    dim_text("Чем раньше найдено, тем выше множитель: дизайн ×%.1f, реализация ×%.1f.", cfg_.xp("stage_design", 2.0), cfg_.xp("stage_impl", 1.5));

    if (finding_.campaign > 0) {
        const Campaign& c = st_.campaigns.at(codes[size_t(finding_.campaign)]);
        std::vector<std::string> threat_labels = {"— этой угрозы не было в модели —"};
        std::vector<std::string> threat_ids = {""};
        for (auto& [tid, t] : c.threats)
            if (t.active && !t.na) {
                threat_labels.push_back(tid + "  " + truncate(t.desc, 50));
                threat_ids.push_back(tid);
            }
        finding_.threat = std::min(finding_.threat, int(threat_labels.size()) - 1);
        std::vector<const char*> ptrs;
        for (auto& l : threat_labels) ptrs.push_back(l.c_str());
        ImGui::SetNextItemWidth(-px(80));
        ImGui::Combo("Угроза", &finding_.threat, ptrs.data(), int(ptrs.size()));
        if (finding_.threat > 0) colored_text(col::teal, "Пророчество сбылось: угроза была предсказана в документе.");
        else if (finding_.stage == 1 || finding_.stage == 2) {
            colored_text(col::violet, "Слепое пятно модели угроз. Сформулируйте урок — что учитывать в следующих документах:");
            ImGui::SetNextItemWidth(-1);
            ImGui::InputTextWithHint("##lesson", "Например: проверять арифметику размеров буферов", &finding_.lesson);
        }
    }

    ImGui::Dummy(ImVec2(0, px(4)));
    subheading("Описание");
    ImGui::SetNextItemWidth(-1);
    ImGui::InputTextWithHint("##note", "Коротко, для себя: где и что", &finding_.note);

    ImGui::Dummy(ImVec2(0, px(8)));
    bool has_cwe = finding_.cwe_index >= 0 || std::atoi(finding_.cwe_text.c_str()) > 0;
    ImGui::BeginDisabled(!has_cwe);
    if (accent_button("Записать", ImVec2(px(160), px(36)))) {
        FindingInput in;
        in.cwe = finding_.cwe_index >= 0 ? std::to_string(cwe_catalog()[size_t(finding_.cwe_index)].id) : finding_.cwe_text;
        in.severity = kSeverities[finding_.severity];
        in.stage = kStages[finding_.stage];
        if (finding_.campaign > 0) {
            in.campaign = codes[size_t(finding_.campaign)];
            if (finding_.threat > 0) {
                const Campaign& c = st_.campaigns.at(in.campaign);
                int k = 0;
                for (auto& [tid, t] : c.threats)
                    if (t.active && !t.na && ++k == finding_.threat) in.threat = in.campaign + "/" + tid;
            }
        }
        in.lesson = finding_.lesson;
        in.note = finding_.note;
        act([&] {
            auto r = record_finding(*log_, in);
            if (r.ok) r.message.clear();
            return r;
        });
        finding_ = {};
        ImGui::CloseCurrentPopup();
    }
    ImGui::EndDisabled();
    ImGui::SameLine();
    if (ImGui::Button("Отмена", ImVec2(px(110), px(36))) || ImGui::IsKeyPressed(ImGuiKey_Escape)) {
        finding_ = {};
        ImGui::CloseCurrentPopup();
    }
    if (has_cwe) {
        ImGui::SameLine(0, px(20));
        ImGui::SetCursorPosY(ImGui::GetCursorPosY() + px(4));
        ImGui::PushFont(fonts.semibold, 20.0f);
        colored_text(col::gold, std::format("≈ +{} XP", estimate_finding_xp()).c_str());
        ImGui::PopFont();
    }
    ImGui::EndPopup();
}

void App::dialog_campaign() {
    const char* id = "Новая кампания";
    if (campaign_form_.open) {
        ImGui::OpenPopup(id);
        campaign_form_.open = false;
    }
    ImGui::SetNextWindowSize(ImVec2(px(600), 0));
    ImGui::SetNextWindowPos(ImGui::GetMainViewport()->GetCenter(), ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
    if (!ImGui::BeginPopupModal(id, nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings)) return;

    wrapped_dim("Кампания — механизм безопасности. Код используется в ветках (impl/AUTHZ/…) и трейлерах (Threat: AUTHZ/T-01).");
    ImGui::SetNextItemWidth(px(160));
    ImGui::InputTextWithHint("Код", "AUTHZ", &campaign_form_.code, ImGuiInputTextFlags_CharsUppercase | ImGuiInputTextFlags_CharsNoBlank);
    ImGui::SetNextItemWidth(-px(90));
    ImGui::InputTextWithHint("Название", "Механизм авторизации", &campaign_form_.title);
    ImGui::SetNextItemWidth(-px(110));
    ImGui::InputTextWithHint("##doc", "Дизайн-документ .docx", &campaign_form_.doc);
    ImGui::SameLine();
    if (ImGui::Button(std::format("{}  Обзор…", icon::folder).c_str(), ImVec2(-1, 0))) {
        std::string picked = pick_docx(hwnd_);
        if (!picked.empty()) campaign_form_.doc = picked;
    }
    card_begin("format", ImVec2(0, 0), col::panel_hi);
    ImGui::TextUnformatted("Что нужно в документе");
    wrapped_dim("Таблица угроз: первая колонка — ID вида T-01, вторая — описание, третья — класс STRIDE "
                "(буквы S T R I D E, английские или русские названия). Строка со словом «неприменимо» тоже "
                "засчитывается. Документ только читается.");
    card_end();
    if (!campaign_form_.error.empty()) colored_text(col::red, campaign_form_.error.c_str());

    if (accent_button("Добавить", ImVec2(px(140), px(34)))) {
        std::string code = upper_ascii(trim(campaign_form_.code));
        size_t first = log_->all().size();
        int total = st_.total;
        ActionResult r = add_campaign(cfg_, campaign_form_.code, campaign_form_.doc, campaign_form_.title);
        if (!r.ok) {
            campaign_form_.error = r.message;
        } else {
            after_change(first, total);
            selected_campaign_ = code;
            if (!r.message.empty()) toast("Внимание", r.message, col::orange);
            toast("Кампания добавлена", "Читаю таблицу угроз…", col::teal);
            request_sync();
            campaign_form_ = {};
            ImGui::CloseCurrentPopup();
        }
    }
    ImGui::SameLine();
    if (ImGui::Button("Отмена", ImVec2(px(110), px(34))) || ImGui::IsKeyPressed(ImGuiKey_Escape)) {
        campaign_form_ = {};
        ImGui::CloseCurrentPopup();
    }
    ImGui::EndPopup();
}

void App::dialog_point() {
    const char* id = "Точка интеграции";
    if (point_form_.open) {
        ImGui::OpenPopup(id);
        point_form_.open = false;
    }
    ImGui::SetNextWindowSize(ImVec2(px(520), 0));
    ImGui::SetNextWindowPos(ImGui::GetMainViewport()->GetCenter(), ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
    if (!ImGui::BeginPopupModal(id, nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings)) return;

    std::vector<std::string> codes;
    for (auto& [code, _] : st_.campaigns) codes.push_back(code);
    std::vector<const char*> ptrs;
    for (auto& c : codes) ptrs.push_back(c.c_str());
    wrapped_dim("Место платформы, куда встраивается механизм. Дальше её продвигают трейлеры Integration: и Integration-Test:.");
    ImGui::SetNextItemWidth(px(200));
    ImGui::Combo("Кампания", &point_form_.campaign, ptrs.data(), int(ptrs.size()));
    ImGui::SetNextItemWidth(px(200));
    ImGui::InputTextWithHint("Имя", "ipc", &point_form_.name, ImGuiInputTextFlags_CharsNoBlank);
    ImGui::SetNextItemWidth(-px(90));
    ImGui::InputTextWithHint("Описание", "IPC-шлюз", &point_form_.title);
    if (!point_form_.error.empty()) colored_text(col::red, point_form_.error.c_str());

    if (accent_button("Запланировать", ImVec2(px(170), px(34))) && !codes.empty()) {
        std::string code = codes[size_t(std::clamp(point_form_.campaign, 0, int(codes.size()) - 1))];
        size_t first = log_->all().size();
        int total = st_.total;
        ActionResult r = guard_busy() ? ActionResult::fail("Идёт синхронизация") : plan_point(*log_, code, point_form_.name, point_form_.title);
        if (!r.ok) {
            point_form_.error = r.message;
        } else {
            after_change(first, total);
            toast("Точка запланирована", "Трейлер для коммита: Integration: " + code + "/" + trim(point_form_.name), col::blue);
            point_form_ = {};
            ImGui::CloseCurrentPopup();
        }
    }
    ImGui::SameLine();
    if (ImGui::Button("Отмена", ImVec2(px(110), px(34))) || ImGui::IsKeyPressed(ImGuiKey_Escape)) {
        point_form_ = {};
        ImGui::CloseCurrentPopup();
    }
    ImGui::EndPopup();
}

void App::dialog_lesson() {
    const char* id = "Урок к находке";
    if (lesson_form_.open) {
        ImGui::OpenPopup(id);
        lesson_form_.open = false;
    }
    ImGui::SetNextWindowSize(ImVec2(px(520), 0));
    ImGui::SetNextWindowPos(ImGui::GetMainViewport()->GetCenter(), ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
    if (!ImGui::BeginPopupModal(id, nullptr, ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings)) return;

    for (auto& e : log_->all())
        if (e.type == "finding" && e.get("id") == lesson_form_.id) {
            ImGui::Text("%s: CWE-%s, %s", lesson_form_.id.c_str(), e.get("cwe").c_str(), e.get("sev").c_str());
            if (!e.get("note").empty()) wrapped_dim(e.get("note"));
        }
    wrapped_dim("Этой угрозы не было в модели. Что учитывать в следующих дизайн-документах?");
    ImGui::SetNextItemWidth(-1);
    if (ImGui::IsWindowAppearing()) ImGui::SetKeyboardFocusHere();
    ImGui::InputTextWithHint("##lesson", "Например: проверять арифметику размеров буферов", &lesson_form_.text);
    if (accent_button("Сохранить", ImVec2(px(140), px(34))) && !trim(lesson_form_.text).empty()) {
        std::string fid = lesson_form_.id, text = lesson_form_.text;
        act([&] { return record_lesson(*log_, fid, text); });
        lesson_form_ = {};
        ImGui::CloseCurrentPopup();
    }
    ImGui::SameLine();
    if (ImGui::Button("Отмена", ImVec2(px(110), px(34))) || ImGui::IsKeyPressed(ImGuiKey_Escape)) {
        lesson_form_ = {};
        ImGui::CloseCurrentPopup();
    }
    ImGui::EndPopup();
}

}  // namespace sq::gui
