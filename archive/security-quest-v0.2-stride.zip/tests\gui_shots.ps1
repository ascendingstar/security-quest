﻿# Снимки всех страниц окна на демо-данных (см. demo.ps1) для визуальной проверки.
param(
    [Parameter(Mandatory)] [string]$Out,
    [string]$Data = (Join-Path $PSScriptRoot '..\demo\данные игры'),
    [string]$Size = '1280x820'
)
$ErrorActionPreference = 'Stop'
$gui = (Resolve-Path (Join-Path $PSScriptRoot '..\build\sq-gui.exe')).Path
New-Item -ItemType Directory -Force $Out | Out-Null
$env:SQ_HOME = $Data

$shots = @(
    @('overview', @()), @('quests', @()), @('campaigns', @()), @('bestiary', @()),
    @('journal', @()), @('settings', @()), @('finding', @('--dialog', 'finding')),
    @('campaign-dialog', @('--page', 'campaigns', '--dialog', 'campaign')),
    @('game', @('--page', 'game')),
    @('game-camp', @('--dialog', 'select:camp:AUTHZ/T-02')),
    @('game-town', @('--dialog', 'town')),
    @('game-chronicle', @('--dialog', 'chronicle')),
    @('game-battle', @('--dialog', 'battle:lair:impl/AUTHZ/token-cache@4.6')),
    @('game-battle-end', @('--dialog', 'battle:monster:F3@60'))
)
foreach ($s in $shots) {
    $name = $s[0]
    $args = @('--screenshot', "`"$Out\$name.png`"", '--size', $Size) + $s[1]
    if ($s[1].Count -eq 0) { $args += @('--page', $name) }
    $p = Start-Process $gui -ArgumentList $args -PassThru -Wait
    "{0,-16} exit {1}" -f $name, $p.ExitCode
}

# Первый запуск: пустой каталог данных.
$empty = Join-Path $Out 'empty-data'
if (Test-Path $empty) { Remove-Item -Recurse -Force $empty }
$env:SQ_HOME = $empty
$p = Start-Process $gui -ArgumentList @('--screenshot', "`"$Out\welcome.png`"", '--size', $Size) -PassThru -Wait
"{0,-16} exit {1}" -f 'welcome', $p.ExitCode
