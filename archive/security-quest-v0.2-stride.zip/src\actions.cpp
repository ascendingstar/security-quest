#include "actions.h"

#include "game.h"
#include "util.h"

#include <algorithm>
#include <cstdlib>
#include <fstream>
#include <regex>
#include <set>

namespace sq {

ActionResult init_config(Config& cfg, const std::string& repo, const std::string& main_branch) {
    std::error_code ec;
    fs::create_directories(cfg.home, ec);
    if (!fs::exists(cfg.config_file(), ec)) {
        std::ofstream out(cfg.config_file(), std::ios::binary);
        out << kDefaultConfig;
        if (!out) return ActionResult::fail("Не удалось создать " + from_path(cfg.config_file()));
    }
    if (!repo.empty()) {
        fs::path path = fs::absolute(to_path(repo), ec);
        if (!fs::is_directory(path, ec)) return ActionResult::fail("Каталог " + repo + " не найден");
        set_ini_value(cfg.config_file(), "repo", "path", from_path(path));
    }
    if (!main_branch.empty()) set_ini_value(cfg.config_file(), "repo", "main", main_branch);
    reload_config(cfg);
    return {};
}

bool reload_config(Config& cfg) {
    return cfg.ini.load(cfg.config_file());
}

ActionResult record_side(const Config& cfg, EventLog& log, const std::string& id_or_text, const std::string& note) {
    std::string what = trim(id_or_text);
    if (what.empty()) return ActionResult::fail("Опишите, что сделано");
    auto templates = side_templates(cfg);
    bool known = std::ranges::any_of(templates, [&](auto& t) { return t.id == what; });

    Event e;
    e.type = "side";
    if (known) {
        e.set("id", what);
        if (!trim(note).empty()) e.set("note", trim(note));
    } else {
        e.set("id", "adhoc").set("title", what);
    }
    if (!log.append(std::move(e))) return ActionResult::fail("Не удалось записать событие");
    return {};
}

ActionResult record_finding(EventLog& log, FindingInput in) {
    static const std::set<std::string> severities = {"low", "medium", "high", "critical"};
    static const std::set<std::string> stages = {"design", "impl", "integ", "patrol"};

    std::string cwe_arg = upper_ascii(trim(in.cwe));
    int cwe = std::atoi((starts_with(cwe_arg, "CWE-") ? cwe_arg.substr(4) : cwe_arg).c_str());
    if (cwe <= 0) return ActionResult::fail("Укажите номер CWE, например CWE-416");
    if (!severities.count(in.severity)) return ActionResult::fail("Severity: low, medium, high или critical");

    std::string campaign = upper_ascii(trim(in.campaign));
    std::string threat = trim(in.threat);
    if (!threat.empty()) {
        static const std::regex re(R"(^[A-Za-z0-9_]+/[Tt]-\d+$)");
        if (!std::regex_match(threat, re)) return ActionResult::fail("Угроза указывается как КОД/T-NN, например AUTHZ/T-03");
        auto slash = threat.find('/');
        campaign = upper_ascii(threat.substr(0, slash));
        threat = campaign + "/" + upper_ascii(threat.substr(slash + 1));
    }
    std::string stage = in.stage.empty() ? (campaign.empty() ? "patrol" : "impl") : in.stage;
    if (!stages.count(stage)) return ActionResult::fail("Этап: design, impl, integ или patrol");

    int findings = 0;
    for (auto& e : log.all()) findings += e.type == "finding";
    std::string id = "F" + std::to_string(findings + 1);

    Event e;
    e.type = "finding";
    e.set("id", id).set("cwe", std::to_string(cwe)).set("sev", in.severity).set("stage", stage);
    if (!campaign.empty()) e.set("campaign", campaign);
    if (!threat.empty()) e.set("threat", threat);
    if (!trim(in.lesson).empty()) e.set("lesson", trim(in.lesson));
    if (!trim(in.note).empty()) e.set("note", trim(in.note));
    if (!log.append(std::move(e))) return ActionResult::fail("Не удалось записать событие");
    return {true, id};
}

bool is_blind_spot(const EventLog& log, const std::string& finding_id) {
    for (auto& e : log.all()) {
        if (e.type != "finding" || e.get("id") != finding_id) continue;
        std::string stage = e.get("stage");
        return !e.get("campaign").empty() && e.get("threat").empty() && e.get("lesson").empty() &&
               (stage == "impl" || stage == "integ");
    }
    return false;
}

ActionResult record_lesson(EventLog& log, const std::string& finding_id, const std::string& text) {
    std::string ref = upper_ascii(trim(finding_id));
    if (trim(text).empty()) return ActionResult::fail("Сформулируйте урок");
    bool exists = std::ranges::any_of(log.all(), [&](auto& e) { return e.type == "finding" && e.get("id") == ref; });
    if (!exists) return ActionResult::fail("Находка " + ref + " не найдена");
    Event e;
    e.type = "lesson";
    e.set("ref", ref).set("text", trim(text));
    if (!log.append(std::move(e))) return ActionResult::fail("Не удалось записать событие");
    return {};
}

ActionResult add_campaign(Config& cfg, const std::string& code_arg, const std::string& doc_arg, const std::string& title) {
    std::string code = upper_ascii(trim(code_arg));
    static const std::regex re(R"(^[A-Z0-9_]+$)");
    if (!std::regex_match(code, re)) return ActionResult::fail("Код кампании: латинские буквы, цифры и _, например AUTHZ");
    if (cfg.ini.has("campaign." + code)) return ActionResult::fail("Кампания " + code + " уже есть");
    if (trim(doc_arg).empty()) return ActionResult::fail("Укажите дизайн-документ (.docx)");

    std::error_code ec;
    fs::path doc = fs::absolute(to_path(trim(doc_arg)), ec);
    std::string section = "\n[campaign." + code + "]\n";
    if (!trim(title).empty()) section += "title = " + trim(title) + "\n";
    section += "doc = " + from_path(doc) + "\n";
    if (!append_text(cfg.config_file(), section)) return ActionResult::fail("Не удалось дописать " + from_path(cfg.config_file()));
    reload_config(cfg);

    ActionResult r;
    if (!fs::is_regular_file(doc, ec)) r.message = "Файл " + from_path(doc) + " пока не найден";
    return r;
}

ActionResult plan_point(EventLog& log, const std::string& code_arg, const std::string& point_arg, const std::string& title) {
    std::string code = upper_ascii(trim(code_arg)), point = trim(point_arg);
    if (code.empty() || point.empty()) return ActionResult::fail("Укажите кампанию и имя точки");
    if (point.find_first_of(" /,") != std::string::npos)
        return ActionResult::fail("Имя точки без пробелов, запятых и /, например ipc");
    std::string key = "point:" + code + "/" + point;
    if (log.has_key(key)) return ActionResult::fail("Точка " + code + "/" + point + " уже запланирована");
    Event e;
    e.type = "point.plan";
    e.set("key", key).set("campaign", code).set("point", point);
    if (!trim(title).empty()) e.set("title", trim(title));
    if (!log.append(std::move(e))) return ActionResult::fail("Не удалось записать событие");
    return {};
}

ActionResult close_quest(const Config& cfg, EventLog& log, const std::string& branch) {
    State st = replay(cfg, log);
    auto it = st.quests.find(branch);
    if (it == st.quests.end()) return ActionResult::fail("Квест " + branch + " не найден. Ветки попадают в игру при синхронизации.");
    if (it->second.done) return ActionResult::fail("Квест " + branch + " уже выполнен");
    Event e;
    e.type = "quest.done";
    e.set("key", "done:" + branch).set("branch", branch).set("how", "manual");
    if (!log.append(std::move(e))) return ActionResult::fail("Не удалось записать событие");
    return {};
}

}  // namespace sq
