#include "app.h"

#include "sync.h"
#include "theme.h"
#include "util.h"

#include <algorithm>
#include <format>

namespace sq::gui {

App::App(HWND hwnd) : hwnd_(hwnd) {
    cfg_.home = data_home();
    load();
    next_auto_sync_ = 2.0;  // первая синхронизация вскоре после запуска
}

App::~App() {
    if (worker_.joinable()) worker_.join();
}

// ---------------------------------------------------------------------------
// Данные

void App::load() {
    configured_ = reload_config(cfg_);
    log_ = std::make_unique<EventLog>(cfg_.events_file());
    log_->load();
    game_log_ = std::make_unique<EventLog>(cfg_.home / "game.log");
    game_log_->load();
    std::error_code ec;
    log_mtime_ = fs::last_write_time(cfg_.events_file(), ec);
    settings_repo_ = cfg_.ini.get("repo", "path");
    settings_main_ = cfg_.ini.get("repo", "main", "main");
    settings_sync_minutes_ = int(cfg_.ini.num("gui", "sync_minutes", 10));
    refresh_state();
}

void App::refresh_state() {
    st_ = replay(cfg_, *log_);
    world_ = quest::build_world(cfg_, st_, *log_, *game_log_);
    if (selected_campaign_.empty() || !st_.campaigns.count(selected_campaign_))
        selected_campaign_ = st_.campaigns.empty() ? "" : st_.campaigns.begin()->first;
}

double App::clock() const {
    return std::chrono::duration<double>(std::chrono::steady_clock::now() - started_).count();
}

void App::open_dialog(const std::string& name) {
    if (name == "finding") finding_.open = true;
    if (name == "campaign") campaign_form_.open = true;
    if (name == "point") point_form_.open = true;
    if (name == "town" || name == "chronicle") {
        page = Page::Game;
        game_tab_ = name == "town" ? 1 : 2;
    }
    if (starts_with(name, "select:")) {
        page = Page::Game;
        selected_node_ = name.substr(7);
    }
    // battle:<узел>@<ход> — бой без записи в журнал, остановленный на нужном ходе; для снимков.
    if (starts_with(name, "battle:")) {
        auto atpos = name.find('@');
        std::string id = name.substr(7, atpos == std::string::npos ? std::string::npos : atpos - 7);
        float progress = atpos == std::string::npos ? 0.6f : std::strtof(name.c_str() + atpos + 1, nullptr);
        if (const quest::Node* n = world_.node(id)) {
            quest::Army army = world_.army;
            for (int s = 0; s < quest::kSchools; ++s) army.scrolls[size_t(s)] += 1;
            page = Page::Game;
            battle_ = {true, quest::simulate(army, n->enemy, 42), n->enemy.name, n->enemy.reward, false, progress, 0.0001f};
        }
    }
}

int App::level() const {
    return level_of(st_.total).level;
}

std::string App::tray_tip() const {
    Level lv = level_of(st_.total);
    return std::format("Security Quest · уровень {} · {}/{} XP", lv.level, lv.into, lv.need);
}

void App::after_change(size_t first_event, int total_before) {
    refresh_state();
    std::error_code ec;
    log_mtime_ = fs::last_write_time(cfg_.events_file(), ec);

    std::vector<const Award*> fresh;
    for (auto& a : st_.awards)
        if (a.event >= first_event) fresh.push_back(&a);

    int gained = 0;
    for (size_t i = 0; i < fresh.size(); ++i) {
        gained += fresh[i]->xp;
        if (i < 4) toast(std::format("+{} XP", fresh[i]->xp), fresh[i]->reason, col::gold);
    }
    if (fresh.size() > 4) toast(std::format("и ещё {} наград", fresh.size() - 4), "Подробности в журнале", col::dim);

    int before = level_of(total_before).level, after = level_of(st_.total).level;
    if (after > before) toast(std::format("Уровень {}!", after), "Так держать", col::teal);

    if (!window_visible && notify && gained > 0) {
        std::string text = fresh.front()->reason;
        if (fresh.size() > 1) text += std::format(" и ещё {}", fresh.size() - 1);
        notify(after > before ? std::format("Уровень {}! +{} XP", after, gained) : std::format("+{} XP", gained), text);
    }
}

bool App::guard_busy() {
    if (!syncing_) return false;
    toast("Подождите", "Идёт синхронизация, запись будет доступна через пару секунд", col::orange);
    return true;
}

void App::act(const std::function<ActionResult()>& action) {
    if (guard_busy()) return;
    size_t first = log_->all().size();
    int total = st_.total;
    ActionResult r = action();
    if (!r.ok) {
        toast("Не получилось", r.message, col::red);
        return;
    }
    if (!r.message.empty()) toast("Готово", r.message, col::blue);
    after_change(first, total);
}

// ---------------------------------------------------------------------------
// Синхронизация и таймеры

void App::request_sync() {
    if (!configured_ || syncing_) return;
    if (worker_.joinable()) worker_.join();
    syncing_ = true;
    sync_finished_ = false;
    sync_first_event_ = log_->all().size();
    sync_total_before_ = st_.total;

    // Поток работает со своей копией настроек и журнала, интерфейс в это время запись не делает.
    worker_ = std::thread([this, cfg = cfg_] {
        EventLog log(cfg.events_file());
        log.load();
        std::vector<std::string> report;
        sync_documents(cfg, log, report);
        sync_git(cfg, log, report);
        {
            std::lock_guard lock(sync_mu_);
            sync_report_ = std::move(report);
        }
        sync_finished_ = true;
    });
}

void App::tick() {
    double now = clock();
    if (sync_finished_) {
        worker_.join();
        sync_finished_ = false;
        syncing_ = false;
        log_->load();
        after_change(sync_first_event_, sync_total_before_);
        last_sync_label_ = now_iso().substr(11, 5);
    }

    if (configured_ && !syncing_) {
        int minutes = int(cfg_.ini.num("gui", "sync_minutes", 10));
        if (minutes > 0 && now >= next_auto_sync_) {
            next_auto_sync_ = now + minutes * 60.0;
            request_sync();
        }
    }

    // Журнал могли дописать из консоли (sq side done …): подхватываем и показываем награды.
    if (configured_ && !syncing_ && now >= next_file_check_) {
        next_file_check_ = now + 1.0;
        std::error_code ec;
        auto mtime = fs::last_write_time(cfg_.events_file(), ec);
        if (!ec && mtime != log_mtime_) {
            size_t first = log_->all().size();
            int total = st_.total;
            log_->load();
            after_change(first, total);
        }
    }

    // Набеги разыгрываются сами, по одному, пока окно открыто или висит в трее.
    if (configured_ && !syncing_ && !battle_.active && !world_.raids.empty() && now >= next_raid_) {
        next_raid_ = now + 8.0;
        run_raid();
    }

    toasts_.erase(std::remove_if(toasts_.begin(), toasts_.end(), [&](const Toast& t) { return now - t.born > 6.0; }),
                  toasts_.end());
}

bool App::busy() const {
    // Карта похода живая (туман, свечение логов), поэтому на ней кадры нужны постоянно.
    return syncing_ || !toasts_.empty() || battle_.active || (page == Page::Game && window_visible);
}

int App::frame_cap_ms() const {
    // Бою нужна плавность, а дрейфу тумана на карте хватает 30 кадров в секунду.
    return battle_.active || !toasts_.empty() ? 0 : 33;
}

void App::toast(std::string title, std::string text, ImU32 color) {
    toasts_.push_back({std::move(title), std::move(text), color, clock()});
    if (toasts_.size() > 6) toasts_.erase(toasts_.begin());
}

// ---------------------------------------------------------------------------
// Каркас окна

void App::frame() {
    ImGuiViewport* vp = ImGui::GetMainViewport();
    ImGui::SetNextWindowPos(vp->WorkPos);
    ImGui::SetNextWindowSize(vp->WorkSize);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::Begin("root", nullptr,
                 ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings |
                     ImGuiWindowFlags_NoBringToFrontOnFocus);
    ImGui::PopStyleVar();

    if (!configured_) {
        page_welcome();
    } else {
        draw_sidebar();
        ImGui::SameLine(0, 0);
        ImGui::PushStyleColor(ImGuiCol_ChildBg, col::bg);
        ImGui::BeginChild("main", ImVec2(0, 0), ImGuiChildFlags_AlwaysUseWindowPadding);
        draw_header();
        ImGui::Dummy(ImVec2(0, px(4)));
        ImGui::BeginChild("page", ImVec2(0, 0));
        switch (page) {
            case Page::Overview: page_overview(); break;
            case Page::Game: page_game(); break;
            case Page::Quests: page_quests(); break;
            case Page::Campaigns: page_campaigns(); break;
            case Page::Bestiary: page_bestiary(); break;
            case Page::Journal: page_journal(); break;
            case Page::Settings: page_settings(); break;
        }
        ImGui::EndChild();
        ImGui::EndChild();
        ImGui::PopStyleColor();

        dialog_finding();
        dialog_campaign();
        dialog_point();
        dialog_lesson();
    }
    ImGui::End();
    draw_toasts();
}

void App::draw_sidebar() {
    ImGui::PushStyleColor(ImGuiCol_ChildBg, col::sidebar);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(px(14), px(18)));
    ImGui::BeginChild("sidebar", ImVec2(px(216), 0), ImGuiChildFlags_AlwaysUseWindowPadding);

    ImGui::PushFont(fonts.semibold, 22.0f);
    colored_text(col::gold, icon::shield);
    ImGui::SameLine();
    ImGui::TextUnformatted("Security Quest");
    ImGui::PopFont();
    ImGui::Dummy(ImVec2(0, px(14)));

    struct Item {
        Page page;
        const char* icon;
        const char* label;
    };
    static const Item items[] = {
        {Page::Overview, icon::home, "Сводка"},       {Page::Game, icon::game, "Поход"},
        {Page::Quests, icon::flag, "Квесты"},
        {Page::Campaigns, icon::shield, "Кампании"}, {Page::Bestiary, icon::bug, "Бестиарий"},
        {Page::Journal, icon::history, "Журнал"},     {Page::Settings, icon::settings, "Настройки"},
    };
    ImDrawList* dl = ImGui::GetWindowDrawList();
    float w = ImGui::GetContentRegionAvail().x;
    for (auto& it : items) {
        bool active = page == it.page;
        ImVec2 p = ImGui::GetCursorScreenPos();
        ImGui::PushID(it.label);
        if (ImGui::InvisibleButton("nav", ImVec2(w, px(38)))) page = it.page;
        bool hovered = ImGui::IsItemHovered();
        ImGui::PopID();
        if (active || hovered)
            dl->AddRectFilled(p, ImVec2(p.x + w, p.y + px(38)), active ? col::panel_hi : alpha(col::panel_hi, 0.5f), px(8));
        if (active) dl->AddRectFilled(ImVec2(p.x, p.y + px(9)), ImVec2(p.x + px(3), p.y + px(29)), col::gold, px(2));
        float fs = ImGui::GetFontSize();
        float ty = p.y + (px(38) - fs) * 0.5f;
        dl->AddText(ImVec2(p.x + px(14), ty), active ? col::gold : col::dim, it.icon);
        dl->AddText(ImVec2(p.x + px(44), ty), active ? col::text : col::dim, it.label);
        ImGui::Dummy(ImVec2(0, px(2)));
    }

    // Внизу — где лежат данные: это важно для портативной версии.
    float bottom = ImGui::GetWindowHeight() - px(64);
    if (ImGui::GetCursorPosY() < bottom) ImGui::SetCursorPosY(bottom);
    std::error_code ec;
    bool portable = fs::equivalent(cfg_.home, exe_dir() / "data", ec);
    dim_text("%s", portable ? "Портативный режим" : "Данные в профиле");
    tooltip(from_path(cfg_.home).c_str());
    dim_text("версия 0.2");

    ImGui::EndChild();
    ImGui::PopStyleVar();
    ImGui::PopStyleColor();
}

void App::draw_header() {
    Level lv = level_of(st_.total);
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 p = ImGui::GetCursorScreenPos();
    float right = ImGui::GetCursorPosX() + ImGui::GetContentRegionAvail().x;
    float r = px(26);
    float y = ImGui::GetCursorPosY() + r - ImGui::GetFrameHeight() * 0.5f;

    // Значок уровня.
    ImVec2 c(p.x + r, p.y + r);
    dl->AddCircleFilled(c, r, col::gold_dark);
    dl->AddCircleFilled(c, r - px(3), col::gold);
    std::string num = std::to_string(lv.level);
    float nsz = 26.0f * ui_scale;
    ImVec2 ts = fonts.semibold->CalcTextSizeA(nsz, FLT_MAX, 0, num.c_str());
    dl->AddText(fonts.semibold, nsz, ImVec2(c.x - ts.x * 0.5f, c.y - ts.y * 0.5f), col::bg, num.c_str());
    ImGui::Dummy(ImVec2(r * 2, r * 2));

    ImGui::SameLine(0, px(14));
    ImGui::BeginGroup();
    ImGui::PushFont(fonts.semibold, 18.0f);
    ImGui::Text("Уровень %d", lv.level);
    ImGui::PopFont();
    bar(float(lv.into) / float(lv.need), ImVec2(px(300), px(10)), col::gold_dark, col::gold);
    dim_text("%d / %d XP до уровня %d  ·  всего %d", lv.into, lv.need, lv.level + 1, st_.total);
    ImGui::EndGroup();

    // Справа: неделя, синхронизация, главная кнопка.
    int week = st_.weeks.count(week_start(today())) ? st_.weeks.at(week_start(today())) : 0;
    std::string week_text = std::format("+{} XP за неделю", week);
    const char* sync_label = syncing_ ? "Синхронизация…" : "Синхронизировать";
    std::string sync_btn = std::format("{}  {}", icon::sync, sync_label);
    std::string find_btn = std::format("{}  Находка", icon::add);
    float sp = ImGui::GetStyle().ItemSpacing.x;
    float fp = ImGui::GetStyle().FramePadding.x * 2;
    float wweek = ImGui::CalcTextSize(week_text.c_str()).x + px(16);
    float wsync = ImGui::CalcTextSize(sync_btn.c_str()).x + fp;
    float wfind = ImGui::CalcTextSize(find_btn.c_str()).x + fp + px(8);

    ImGui::SameLine();
    ImGui::SetCursorPos(ImVec2(right - wfind - wsync - wweek - sp * 2, y + px(3)));
    pill(week_text.c_str(), col::teal);
    ImGui::SameLine();
    ImGui::SetCursorPosY(y);
    ImGui::BeginDisabled(syncing_.load());
    if (ImGui::Button(sync_btn.c_str())) request_sync();
    ImGui::EndDisabled();
    tooltip(("Прочитать дизайн-документы и git. Последний раз: " + last_sync_label_).c_str());
    ImGui::SameLine();
    ImGui::SetCursorPosY(y);
    if (accent_button(find_btn.c_str(), ImVec2(wfind, 0))) finding_.open = true;
    tooltip("Записать найденную уязвимость");

    ImGui::SetCursorScreenPos(ImVec2(p.x, p.y + r * 2 + px(10)));
    ImGui::Separator();
}

void App::draw_toasts() {
    if (toasts_.empty()) return;
    ImGuiViewport* vp = ImGui::GetMainViewport();
    double now = clock();
    float y = vp->WorkPos.y + px(86);
    for (size_t i = 0; i < toasts_.size(); ++i) {
        const Toast& t = toasts_[i];
        double age = now - t.born;
        float a = float(std::min({1.0, age * 4.0, (6.0 - age) * 2.0}));
        ImGui::SetNextWindowPos(ImVec2(vp->WorkPos.x + vp->WorkSize.x - px(20), y), ImGuiCond_Always, ImVec2(1, 0));
        ImGui::SetNextWindowBgAlpha(0.96f * a);
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, a);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(px(14), px(10)));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 1.0f);
        ImGui::PushStyleColor(ImGuiCol_WindowBg, col::panel_hi);
        ImGui::PushStyleColor(ImGuiCol_Border, alpha(t.color, 0.6f));
        std::string id = std::format("##toast{}", i);
        ImGui::Begin(id.c_str(), nullptr,
                     ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings |
                         ImGuiWindowFlags_NoFocusOnAppearing | ImGuiWindowFlags_NoNav | ImGuiWindowFlags_NoInputs);
        ImGui::PushTextWrapPos(px(340));
        ImGui::PushFont(fonts.semibold, 18.0f);
        colored_text(t.color, t.title.c_str());
        ImGui::PopFont();
        ImGui::TextWrapped("%s", t.text.c_str());
        ImGui::PopTextWrapPos();
        y += ImGui::GetWindowHeight() + px(8);
        ImGui::End();
        ImGui::PopStyleColor(2);
        ImGui::PopStyleVar(3);
    }
}

}  // namespace sq::gui
