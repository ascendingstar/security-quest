#include "config.h"

#include "util.h"

#include <fstream>
#include <sstream>

namespace sq {

fs::path data_home() {
    std::string explicit_home = getenv_u8("SQ_HOME");
    if (!explicit_home.empty()) return to_path(explicit_home);
    // Портативный режим: папка data рядом с exe, например на флешке.
    std::error_code ec;
    fs::path portable = exe_dir() / "data";
    if (fs::is_directory(portable, ec)) return portable;
    return to_path(getenv_u8("LOCALAPPDATA")) / "SecurityQuest";
}

const char* const kDefaultConfig = R"(; Security Quest — настройки. Файл в UTF-8.
; Очки пересчитываются из журнала событий при каждом запуске,
; поэтому значения в [xp] и [side.*] можно менять задним числом.

[repo]
; Путь к рабочему репозиторию и имя основной ветки.
path =
main = main
; Ветки задач: <тип>/<КОД механизма>/<описание>, например impl/AUTHZ/token-cache.
; Типы: impl — реализация, integ — интеграция, fix — исправление ошибки, review — ревью.
; Путь к git.exe, если он не в PATH:
; git = C:\Program Files\Git\cmd\git.exe

; Кампании (механизмы) добавляются командой: sq campaign add <КОД> <путь к docx> [название]

[gui]
; Как часто окно само синхронизируется с git и документами, в минутах. 0 — только вручную.
sync_minutes = 10

[xp]
threat = 10
threat_na = 3
stride_seal = 100
mitigation = 15
threat_test = 15
chain = 30
integration = 20
integration_test = 30
quest_impl = 30
quest_integ = 40
quest_review = 25
quest_other = 15
sev_low = 5
sev_medium = 15
sev_high = 30
sev_critical = 60
; Чем раньше найдено, тем дешевле исправление: дизайн ценится выше всего.
stage_design = 2.0
stage_impl = 1.5
stage_integ = 1.25
stage_patrol = 1.0
novelty = 1.5
repeat_decay = 0.8
prophecy = 20
lesson = 10
side_adhoc = 10
side_adhoc_cap = 5

; Побочные квесты. id — имя секции после «side.».
; weekly_cap — сколько раз за неделю засчитывается полностью; дальше каждый раз вдвое меньше.
; recur = monthly — ежемесячный контракт: открывается open_day числа, срок — due_day
; следующего месяца, за сдачу в срок бонус early_bonus (0.5 = +50%). Просрочка не штрафуется.

[side.explain]
title = Объяснить что-то коллеге
xp = 15
skill = Наставничество
weekly_cap = 3

[side.discussion]
title = Помочь на обсуждении
xp = 10
skill = Командная работа
weekly_cap = 5

[side.bugfix]
title = Исправить ошибку
xp = 20
skill = Ремесло
weekly_cap = 5
; Ветки fix/* засчитываются как этот квест автоматически.

[side.learn]
title = Разобрать чужую CVE
xp = 20
skill = Обучение
weekly_cap = 3

[side.report]
title = Заполнить отчёты за месяц
xp = 40
skill = Рутина
recur = monthly
open_day = 25
due_day = 5
early_bonus = 0.5
)";

namespace {

bool read_file(const fs::path& file, std::string& out) {
    std::ifstream in(file, std::ios::binary);
    if (!in) return false;
    std::stringstream ss;
    ss << in.rdbuf();
    out = ss.str();
    return true;
}

}  // namespace

bool set_ini_value(const fs::path& file, const std::string& section, const std::string& key,
                   const std::string& value) {
    std::string text;
    if (!read_file(file, text)) return false;
    auto lines = split(text, '\n');
    std::string entry = key + " = " + value;

    auto save = [&] {
        std::string joined;
        for (size_t j = 0; j < lines.size(); ++j) joined += lines[j] + (j + 1 < lines.size() ? "\n" : "");
        std::ofstream out(file, std::ios::binary | std::ios::trunc);
        out << joined;
        return bool(out);
    };

    bool in_section = false;
    size_t header = std::string::npos;
    for (size_t i = 0; i < lines.size(); ++i) {
        std::string line = trim(lines[i]);
        if (!line.empty() && line.front() == '[' && line.back() == ']') {
            if (in_section) break;
            in_section = trim(line.substr(1, line.size() - 2)) == section;
            if (in_section) header = i;
            continue;
        }
        if (!in_section || line.empty() || line[0] == ';' || line[0] == '#') continue;
        auto eq = line.find('=');
        if (eq != std::string::npos && trim(line.substr(0, eq)) == key) {
            lines[i] = entry;
            return save();
        }
    }

    if (header != std::string::npos) {
        lines.insert(lines.begin() + std::ptrdiff_t(header) + 1, entry);
        return save();
    }
    return append_text(file, "\n[" + section + "]\n" + entry + "\n");
}

bool append_text(const fs::path& file, const std::string& text) {
    std::ofstream out(file, std::ios::binary | std::ios::app);
    out << text;
    return bool(out);
}

}  // namespace sq
