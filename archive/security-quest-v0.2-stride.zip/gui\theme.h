#pragma once

// Внешний вид: палитра, шрифты, иконки и небольшие виджеты поверх ImGui.

#include "imgui.h"

#include <string>

namespace sq::gui {

namespace col {
constexpr ImU32 bg = IM_COL32(14, 18, 29, 255);
constexpr ImU32 sidebar = IM_COL32(18, 23, 36, 255);
constexpr ImU32 panel = IM_COL32(24, 30, 46, 255);
constexpr ImU32 panel_hi = IM_COL32(33, 41, 62, 255);
constexpr ImU32 border = IM_COL32(44, 54, 80, 255);
constexpr ImU32 text = IM_COL32(228, 232, 241, 255);
constexpr ImU32 dim = IM_COL32(146, 156, 178, 255);
constexpr ImU32 faint = IM_COL32(86, 96, 120, 255);
constexpr ImU32 gold = IM_COL32(244, 186, 78, 255);
constexpr ImU32 gold_dark = IM_COL32(214, 136, 40, 255);
constexpr ImU32 teal = IM_COL32(64, 206, 146, 255);
constexpr ImU32 blue = IM_COL32(96, 160, 255, 255);
constexpr ImU32 violet = IM_COL32(164, 126, 255, 255);
constexpr ImU32 red = IM_COL32(240, 96, 96, 255);
constexpr ImU32 orange = IM_COL32(246, 152, 72, 255);
}  // namespace col

// Иконки Segoe MDL2 Assets (есть в Windows 10 и новее), подмешаны в основной шрифт.
namespace icon {
constexpr const char* home = "";
constexpr const char* flag = "";
constexpr const char* shield = "";
constexpr const char* bug = "";
constexpr const char* history = "";
constexpr const char* settings = "";
constexpr const char* sync = "";
constexpr const char* add = "";
constexpr const char* check = "";
constexpr const char* copy = "";
constexpr const char* folder = "";
constexpr const char* warning = "";
constexpr const char* bulb = "";
constexpr const char* document = "";
constexpr const char* code = "";
constexpr const char* people = "";
constexpr const char* calendar = "";
constexpr const char* star = "";
constexpr const char* edit = "";
constexpr const char* info = "";
constexpr const char* close = "";
constexpr const char* game = "";
constexpr const char* lock = "";
constexpr const char* play = "";
constexpr const char* map = "";
constexpr const char* town = "";
constexpr const char* book = "";
}  // namespace icon

// Масштаб интерфейса по DPI монитора: все размеры в пикселях проходят через px().
extern float ui_scale;
inline float px(float v) { return v * ui_scale; }

struct Fonts {
    ImFont* regular = nullptr;
    ImFont* semibold = nullptr;
};
extern Fonts fonts;

void load_fonts();
void setup_style(float dpi_scale);

ImU32 alpha(ImU32 c, float a);
ImVec4 vec(ImU32 c);

// Карточка с фоном панели; высота подстраивается под содержимое, если size.y == 0.
void card_begin(const char* id, ImVec2 size = ImVec2(0, 0), ImU32 bg = col::panel);
void card_end();

void heading(const char* text, float size = 22.0f);
void subheading(const char* text);
void dim_text(const char* fmt, ...) IM_FMTARGS(1);
void colored_text(ImU32 c, const char* text);
void wrapped_dim(const std::string& text);

void bar(float fraction, ImVec2 size, ImU32 from, ImU32 to, ImU32 track = col::panel_hi);
void pill(const char* text, ImU32 color, bool filled = false);
bool accent_button(const char* label, ImVec2 size = ImVec2(0, 0), ImU32 color = col::gold);
bool icon_button(const char* icon, const char* tooltip, ImU32 color = col::dim);
void tooltip(const char* text);

// Квадратная плитка с подписью (STRIDE, бестиарий).
void tile(const char* big, const char* small, ImVec2 size, bool lit, ImU32 color, const char* tip = nullptr);

}  // namespace sq::gui
