#pragma once

// Действия пользователя, общие для консоли и окна: проверка ввода и запись событий.
// Награды за записанное событие потом берутся из replay() по индексу события.

#include "config.h"
#include "events.h"

#include <string>

namespace sq {

struct ActionResult {
    bool ok = true;
    std::string message;  // при ошибке — что не так, при успехе — необязательная подсказка

    static ActionResult fail(std::string m) { return {false, std::move(m)}; }
};

// Создаёт config.ini, если его нет, и при необходимости меняет репозиторий и основную ветку.
ActionResult init_config(Config& cfg, const std::string& repo, const std::string& main_branch);
bool reload_config(Config& cfg);

// id шаблона из [side.*] или произвольный текст для разового квеста.
ActionResult record_side(const Config& cfg, EventLog& log, const std::string& id_or_text, const std::string& note);

struct FindingInput {
    std::string cwe;       // «CWE-416» или «416»
    std::string severity;  // low | medium | high | critical
    std::string stage;     // design | impl | integ | patrol; пусто — по умолчанию
    std::string campaign;
    std::string threat;    // КОД/T-NN
    std::string lesson;
    std::string note;
};

// При успехе message — идентификатор находки (F1, F2…).
ActionResult record_finding(EventLog& log, FindingInput in);
bool is_blind_spot(const EventLog& log, const std::string& finding_id);
ActionResult record_lesson(EventLog& log, const std::string& finding_id, const std::string& text);

ActionResult add_campaign(Config& cfg, const std::string& code, const std::string& doc, const std::string& title);
ActionResult plan_point(EventLog& log, const std::string& code, const std::string& point, const std::string& title);
ActionResult close_quest(const Config& cfg, EventLog& log, const std::string& branch);

}  // namespace sq
