#include "docx.h"

#include "util.h"

#include <array>
#include <cstdint>
#include <fstream>
#include <regex>
#include <sstream>
#include <stdexcept>

namespace sq {

namespace {

// ---------------------------------------------------------------------------
// ZIP + DEFLATE (RFC 1951). Своя реализация, чтобы не тянуть зависимости:
// docx — это zip, а из него нужен ровно один файл.

constexpr size_t kMaxXmlSize = 256u << 20;

class BitReader {
public:
    BitReader(const uint8_t* data, size_t size) : p_(data), n_(size) {}

    uint32_t bits(int count) {
        uint32_t v = buf_;
        while (cnt_ < count) {
            if (pos_ >= n_) throw std::runtime_error("неожиданный конец сжатых данных");
            v |= uint32_t(p_[pos_++]) << cnt_;
            cnt_ += 8;
        }
        buf_ = count == 32 ? 0 : v >> count;
        cnt_ -= count;
        return count == 32 ? v : v & ((1u << count) - 1);
    }

    void align() {
        buf_ = 0;
        cnt_ = 0;
    }

    uint8_t byte() {
        if (pos_ >= n_) throw std::runtime_error("неожиданный конец сжатых данных");
        return p_[pos_++];
    }

private:
    const uint8_t* p_;
    size_t n_, pos_ = 0;
    uint32_t buf_ = 0;
    int cnt_ = 0;
};

struct Huffman {
    std::array<uint16_t, 16> counts{};
    std::array<uint16_t, 320> symbols{};
};

void build(Huffman& h, const uint8_t* lengths, int n) {
    h.counts.fill(0);
    for (int i = 0; i < n; ++i) h.counts[lengths[i]]++;
    h.counts[0] = 0;
    std::array<uint16_t, 16> offs{};
    for (int len = 1; len < 15; ++len) offs[len + 1] = uint16_t(offs[len] + h.counts[len]);
    for (int i = 0; i < n; ++i)
        if (lengths[i]) h.symbols[offs[lengths[i]]++] = uint16_t(i);
}

// Канонический код Хаффмана декодируется побитово, как в zlib/contrib/puff.
int decode(BitReader& br, const Huffman& h) {
    int code = 0, first = 0, index = 0;
    for (int len = 1; len < 16; ++len) {
        code |= int(br.bits(1));
        int count = h.counts[len];
        if (code - count < first) return h.symbols[size_t(index + (code - first))];
        index += count;
        first += count;
        first <<= 1;
        code <<= 1;
    }
    throw std::runtime_error("повреждённый код Хаффмана");
}

constexpr uint16_t kLenBase[29] = {3,  4,  5,  6,  7,  8,  9,  10, 11,  13,  15,  17,  19,  23, 27,
                                   31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258};
constexpr uint8_t kLenExtra[29] = {0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2,
                                   2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0};
constexpr uint16_t kDistBase[30] = {1,   2,   3,   4,   5,   7,    9,    13,   17,   25,   33,   49,   65,    97,    129,
                                    193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577};
constexpr uint8_t kDistExtra[30] = {0, 0, 0, 0, 1, 1, 2, 2,  3,  3,  4,  4,  5,  5,  6,
                                    6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13};

void inflate_block(BitReader& br, std::string& out, const Huffman& lit, const Huffman& dist, size_t limit) {
    while (true) {
        int sym = decode(br, lit);
        if (sym < 256) {
            out += char(sym);
        } else if (sym == 256) {
            return;
        } else {
            sym -= 257;
            if (sym >= 29) throw std::runtime_error("неверная длина");
            size_t len = kLenBase[sym] + br.bits(kLenExtra[sym]);
            int ds = decode(br, dist);
            if (ds >= 30) throw std::runtime_error("неверное расстояние");
            size_t d = kDistBase[ds] + br.bits(kDistExtra[ds]);
            if (d > out.size()) throw std::runtime_error("ссылка за начало данных");
            for (size_t i = 0; i < len; ++i) out += out[out.size() - d];
        }
        if (out.size() > limit) throw std::runtime_error("распакованные данные слишком велики");
    }
}

std::string inflate(const uint8_t* data, size_t size, size_t limit) {
    BitReader br(data, size);
    std::string out;
    bool last = false;
    while (!last) {
        last = br.bits(1);
        uint32_t type = br.bits(2);
        if (type == 0) {
            br.align();
            uint16_t len = uint16_t(br.byte() | (br.byte() << 8));
            uint16_t nlen = uint16_t(br.byte() | (br.byte() << 8));
            if (len != uint16_t(~nlen)) throw std::runtime_error("повреждённый несжатый блок");
            for (uint16_t i = 0; i < len; ++i) out += char(br.byte());
            if (out.size() > limit) throw std::runtime_error("распакованные данные слишком велики");
        } else if (type == 1) {
            static const auto fixed = [] {
                std::array<uint8_t, 288> l{};
                for (int i = 0; i < 288; ++i) l[size_t(i)] = i < 144 ? 8 : i < 256 ? 9 : i < 280 ? 7 : 8;
                std::array<uint8_t, 30> d{};
                d.fill(5);
                std::pair<Huffman, Huffman> h;
                build(h.first, l.data(), 288);
                build(h.second, d.data(), 30);
                return h;
            }();
            inflate_block(br, out, fixed.first, fixed.second, limit);
        } else if (type == 2) {
            int hlit = int(br.bits(5)) + 257, hdist = int(br.bits(5)) + 1, hclen = int(br.bits(4)) + 4;
            static constexpr uint8_t order[19] = {16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15};
            std::array<uint8_t, 19> cl{};
            for (int i = 0; i < hclen; ++i) cl[order[i]] = uint8_t(br.bits(3));
            Huffman clh;
            build(clh, cl.data(), 19);

            std::array<uint8_t, 320> lengths{};
            for (int i = 0; i < hlit + hdist;) {
                int sym = decode(br, clh);
                if (sym < 16) {
                    lengths[size_t(i++)] = uint8_t(sym);
                    continue;
                }
                uint8_t value = 0;
                int repeat = 0;
                if (sym == 16) {
                    if (i == 0) throw std::runtime_error("повтор без предыдущей длины");
                    value = lengths[size_t(i - 1)];
                    repeat = 3 + int(br.bits(2));
                } else if (sym == 17) {
                    repeat = 3 + int(br.bits(3));
                } else {
                    repeat = 11 + int(br.bits(7));
                }
                if (i + repeat > hlit + hdist) throw std::runtime_error("слишком много длин кодов");
                while (repeat--) lengths[size_t(i++)] = value;
            }
            Huffman lit, dist;
            build(lit, lengths.data(), hlit);
            build(dist, lengths.data() + hlit, hdist);
            inflate_block(br, out, lit, dist, limit);
        } else {
            throw std::runtime_error("неизвестный тип блока");
        }
    }
    return out;
}

uint32_t le16(const std::string& s, size_t at) {
    if (at + 2 > s.size()) throw std::runtime_error("файл обрезан");
    return uint8_t(s[at]) | uint32_t(uint8_t(s[at + 1])) << 8;
}

uint32_t le32(const std::string& s, size_t at) {
    return le16(s, at) | le16(s, at + 2) << 16;
}

std::string zip_extract(const std::string& zip, const std::string& wanted) {
    if (zip.size() < 22) throw std::runtime_error("это не zip-архив");
    size_t eocd = std::string::npos;
    size_t stop = zip.size() > 22 + 65535 ? zip.size() - 22 - 65535 : 0;
    for (size_t i = zip.size() - 22 + 1; i-- > stop;)
        if (le32(zip, i) == 0x06054b50) {
            eocd = i;
            break;
        }
    if (eocd == std::string::npos) throw std::runtime_error("это не zip-архив (нет оглавления)");

    uint32_t entries = le16(zip, eocd + 10);
    size_t p = le32(zip, eocd + 16);
    for (uint32_t e = 0; e < entries; ++e) {
        if (le32(zip, p) != 0x02014b50) throw std::runtime_error("повреждённое оглавление zip");
        uint32_t method = le16(zip, p + 10);
        uint32_t csize = le32(zip, p + 20), usize = le32(zip, p + 24);
        uint32_t nlen = le16(zip, p + 28), xlen = le16(zip, p + 30), clen = le16(zip, p + 32);
        uint32_t local = le32(zip, p + 42);
        if (p + 46 + nlen > zip.size()) throw std::runtime_error("повреждённое оглавление zip");
        std::string name = zip.substr(p + 46, nlen);
        p += 46 + nlen + xlen + clen;
        if (name != wanted) continue;

        if (le32(zip, local) != 0x04034b50) throw std::runtime_error("повреждённый заголовок файла в zip");
        size_t data = local + 30 + le16(zip, local + 26) + le16(zip, local + 28);
        if (data + csize > zip.size()) throw std::runtime_error("файл в zip обрезан");
        if (usize > kMaxXmlSize) throw std::runtime_error("документ слишком велик");
        auto* bytes = reinterpret_cast<const uint8_t*>(zip.data()) + data;
        if (method == 0) return std::string(reinterpret_cast<const char*>(bytes), csize);
        if (method == 8) return inflate(bytes, csize, usize);
        throw std::runtime_error("неподдерживаемый метод сжатия в zip");
    }
    throw std::runtime_error("в документе нет " + wanted);
}

// ---------------------------------------------------------------------------
// WordprocessingML: таблицы w:tbl / строки w:tr / ячейки w:tc / текст w:t.

void append_entity_decoded(std::string& out, std::string_view s) {
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] != '&') {
            out += s[i];
            continue;
        }
        auto semi = s.find(';', i);
        if (semi == std::string_view::npos) {
            out += s[i];
            continue;
        }
        std::string_view ent = s.substr(i + 1, semi - i - 1);
        if (ent == "amp") out += '&';
        else if (ent == "lt") out += '<';
        else if (ent == "gt") out += '>';
        else if (ent == "quot") out += '"';
        else if (ent == "apos") out += '\'';
        else if (!ent.empty() && ent[0] == '#') {
            unsigned long cp = ent.size() > 1 && (ent[1] == 'x' || ent[1] == 'X')
                                   ? std::strtoul(std::string(ent.substr(2)).c_str(), nullptr, 16)
                                   : std::strtoul(std::string(ent.substr(1)).c_str(), nullptr, 10);
            if (cp < 0x80) out += char(cp);
            else if (cp < 0x800) out += {char(0xC0 | (cp >> 6)), char(0x80 | (cp & 0x3F))};
            else if (cp < 0x10000) out += {char(0xE0 | (cp >> 12)), char(0x80 | ((cp >> 6) & 0x3F)), char(0x80 | (cp & 0x3F))};
            else out += {char(0xF0 | (cp >> 18)), char(0x80 | ((cp >> 12) & 0x3F)), char(0x80 | ((cp >> 6) & 0x3F)), char(0x80 | (cp & 0x3F))};
        } else {
            out += s.substr(i, semi - i + 1);
        }
        i = semi;
    }
}

bool contains_any(const std::string& s, std::initializer_list<const char*> needles) {
    for (auto* n : needles)
        if (s.find(n) != std::string::npos) return true;
    return false;
}

}  // namespace

std::string parse_stride(const std::string& cell) {
    bool has[6] = {};
    const std::string letters = "STRIDE";

    // Отдельные латинские буквы и английские названия.
    std::string token;
    auto flush = [&] {
        std::string t = upper_ascii(token);
        token.clear();
        if (t.size() == 1 && letters.find(t[0]) != std::string::npos) has[letters.find(t[0])] = true;
        else if (t == "SPOOFING") has[0] = true;
        else if (t == "TAMPERING") has[1] = true;
        else if (t == "REPUDIATION") has[2] = true;
        else if (t == "INFORMATION" || t == "DISCLOSURE") has[3] = true;
        else if (t == "DENIAL" || t == "DOS") has[4] = true;
        else if (t == "ELEVATION") has[5] = true;
    };
    for (char c : cell) {
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) token += c;
        else flush();
    }
    flush();

    // Русские названия: ищем по основе слова без первой буквы, чтобы не зависеть от регистра.
    if (contains_any(cell, {"одмен", "одделк"})) has[0] = true;
    if (contains_any(cell, {"зменени", "одификац", "скажени"})) has[1] = true;
    if (contains_any(cell, {"вторств", "трицани"})) has[2] = true;
    if (contains_any(cell, {"аскрыти", "течк"})) has[3] = true;
    if (contains_any(cell, {"бслуживани"})) has[4] = true;
    if (contains_any(cell, {"овышени", "ривилеги"})) has[5] = true;

    std::string r;
    for (int i = 0; i < 6; ++i)
        if (has[i]) r += letters[size_t(i)];
    return r;
}

std::vector<ThreatRow> parse_threat_tables(const std::string& xml) {
    std::vector<ThreatRow> rows;
    std::vector<std::string> cells;
    bool in_row = false, in_cell = false;
    static const std::regex id_re(R"(^[Tt]-\d+$)");

    size_t i = 0;
    while ((i = xml.find('<', i)) != std::string::npos) {
        size_t end = xml.find('>', i);
        if (end == std::string::npos) break;
        std::string_view tag(xml.data() + i + 1, end - i - 1);
        bool closing = !tag.empty() && tag[0] == '/';
        bool self_closing = !tag.empty() && tag.back() == '/';
        if (closing) tag.remove_prefix(1);
        std::string_view name = tag.substr(0, tag.find_first_of(" /"));
        i = end + 1;

        if (name == "w:tr") {
            if (!closing) {
                in_row = true;
                cells.clear();
            } else if (in_row) {
                in_row = false;
                if (cells.empty()) continue;
                std::string id = trim(cells[0]);
                if (!std::regex_match(id, id_re)) continue;
                ThreatRow row;
                row.id = upper_ascii(id);
                row.desc = cells.size() > 1 ? trim(cells[1]) : "";
                row.stride = cells.size() > 2 ? parse_stride(cells[2]) : "";
                std::string all;
                for (size_t c = 1; c < cells.size(); ++c) all += cells[c] + " ";
                row.na = contains_any(all, {"неприменимо", "Неприменимо", "НЕПРИМЕНИМО", "N/A", "n/a"});
                rows.push_back(std::move(row));
            }
        } else if (name == "w:tc" && in_row) {
            if (!closing) {
                in_cell = true;
                cells.emplace_back();
            } else {
                in_cell = false;
            }
        } else if (in_cell && !closing) {
            if (name == "w:t" && !self_closing) {
                size_t text_end = xml.find('<', i);
                if (text_end == std::string::npos) break;
                append_entity_decoded(cells.back(), std::string_view(xml).substr(i, text_end - i));
                i = text_end;
            } else if (name == "w:tab" || name == "w:br") {
                cells.back() += ' ';
            }
        } else if (in_cell && closing && name == "w:p") {
            cells.back() += ' ';
        }
    }
    return rows;
}

std::optional<std::vector<ThreatRow>> read_threats(const fs::path& docx, std::string& err) {
    std::ifstream in(docx, std::ios::binary);
    if (!in) {
        err = "не удалось открыть " + from_path(docx);
        return std::nullopt;
    }
    std::stringstream ss;
    ss << in.rdbuf();
    try {
        return parse_threat_tables(zip_extract(ss.str(), "word/document.xml"));
    } catch (const std::exception& e) {
        err = from_path(docx) + ": " + e.what();
        return std::nullopt;
    }
}

}  // namespace sq
