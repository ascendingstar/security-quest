// Вкладка «Поход»: карта с туманом, город, летопись и анимация боёв.
// Вся графика — векторная, рисуется через ImDrawList: ни текстур, ни видеопамяти почти не нужно.

#include "app.h"

#include "theme.h"
#include "util.h"

#include "imgui_stdlib.h"

#include <algorithm>
#include <cmath>
#include <format>
#include <numbers>

namespace sq::gui {

using namespace quest;

namespace {

constexpr float kPi = std::numbers::pi_v<float>;
constexpr float kActionTime = 0.8f;  // секунды на один ход при скорости ×1

const ImU32 kFactionColors[kFactions] = {IM_COL32(176, 118, 245, 255), IM_COL32(242, 142, 64, 255), IM_COL32(158, 160, 176, 255),
                                         IM_COL32(86, 156, 242, 255),  IM_COL32(226, 76, 76, 255),   IM_COL32(236, 192, 72, 255)};
const ImU32 kSchoolColors[kSchools] = {IM_COL32(150, 230, 210, 255), IM_COL32(160, 140, 255, 255), IM_COL32(244, 204, 96, 255),
                                       IM_COL32(244, 156, 96, 255),  IM_COL32(130, 214, 120, 255), IM_COL32(206, 222, 255, 255)};
const ImU32 kRegionColors[8] = {IM_COL32(48, 62, 46, 255), IM_COL32(58, 52, 42, 255), IM_COL32(42, 54, 64, 255), IM_COL32(60, 48, 56, 255),
                                IM_COL32(46, 60, 58, 255), IM_COL32(60, 58, 42, 255), IM_COL32(50, 46, 64, 255), IM_COL32(52, 56, 44, 255)};
constexpr ImU32 kGround = IM_COL32(24, 30, 27, 255);
constexpr ImU32 kFog = IM_COL32(58, 64, 82, 255);
constexpr ImU32 kOurs = IM_COL32(52, 92, 168, 255);

ImU32 faction_color(int f) {
    return f >= 0 ? kFactionColors[f] : IM_COL32(190, 120, 200, 255);
}

ImU32 mix(ImU32 a, ImU32 b, float t) {
    ImVec4 x = ImGui::ColorConvertU32ToFloat4(a), y = ImGui::ColorConvertU32ToFloat4(b);
    return ImGui::ColorConvertFloat4ToU32(ImVec4(x.x + (y.x - x.x) * t, x.y + (y.y - x.y) * t, x.z + (y.z - x.z) * t, x.w + (y.w - x.w) * t));
}

float ease(float t) {
    t = std::clamp(t, 0.0f, 1.0f);
    return t * t * (3 - 2 * t);
}

ImVec2 add(ImVec2 a, ImVec2 b) { return ImVec2(a.x + b.x, a.y + b.y); }
ImVec2 lerp(ImVec2 a, ImVec2 b, float t) { return ImVec2(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t); }
ImVec2 at(ImVec2 c, float r, float x, float y) { return ImVec2(c.x + x * r, c.y + y * r); }

uint32_t hash(std::string_view s) {
    uint32_t h = 2166136261u;
    for (unsigned char c : s) h = (h ^ c) * 16777619u;
    return h;
}

void poly(ImDrawList* dl, ImVec2 c, float r, std::initializer_list<ImVec2> pts, ImU32 fill, ImU32 edge = 0, float thick = 1.5f) {
    std::vector<ImVec2> p;
    for (auto& v : pts) p.push_back(at(c, r, v.x, v.y));
    dl->AddConcavePolyFilled(p.data(), int(p.size()), fill);
    if (edge) dl->AddPolyline(p.data(), int(p.size()), edge, thick, ImDrawFlags_Closed);
}

void text_center(ImDrawList* dl, ImFont* font, float size, ImVec2 c, ImU32 col, const char* text) {
    ImVec2 ts = font->CalcTextSizeA(size, FLT_MAX, 0, text);
    dl->AddText(font, size, ImVec2(c.x - ts.x * 0.5f, c.y - ts.y * 0.5f), col, text);
}

void draw_coin(ImDrawList* dl, ImVec2 c, float r) {
    dl->AddCircleFilled(c, r, col::gold_dark);
    dl->AddCircleFilled(c, r * 0.82f, col::gold);
    dl->AddCircle(c, r * 0.55f, col::gold_dark, 0, 1.5f);
}

// Мягкое облако тумана из нескольких полупрозрачных кругов, медленно дрейфующих.
void draw_fog(ImDrawList* dl, ImVec2 c, float radius, uint32_t seed, float time, float density = 1.0f) {
    for (int i = 0; i < 12; ++i) {
        uint32_t h = seed * 2654435761u + uint32_t(i) * 40503u;
        float a = float(h % 628) / 100.0f;
        float d = (i == 0 ? 0.0f : 0.25f + float((h >> 9) % 50) / 100.0f) * radius;
        ImVec2 p(c.x + std::cos(a) * d + std::sin(time * 0.23f + i) * radius * 0.07f, c.y + std::sin(a) * d + std::cos(time * 0.19f + i * 1.7f) * radius * 0.06f);
        float b = radius * (0.32f + float((h >> 17) % 20) / 100.0f);
        dl->AddCircleFilled(p, b * 1.35f, alpha(kFog, 0.10f * density));
        dl->AddCircleFilled(p, b, alpha(kFog, 0.20f * density));
        dl->AddCircleFilled(p, b * 0.65f, alpha(kFog, 0.30f * density));
    }
}

// --- Узлы карты -------------------------------------------------------------

void draw_castle(ImDrawList* dl, ImVec2 c, float s) {
    ImU32 stone = IM_COL32(176, 168, 150, 255), dark = IM_COL32(96, 88, 76, 255);
    dl->AddRectFilled(at(c, s, -1.0f, -0.2f), at(c, s, 1.0f, 0.8f), stone, 2);
    for (float x : {-1.0f, 0.55f}) dl->AddRectFilled(at(c, s, x, -0.75f), at(c, s, x + 0.45f, 0.8f), stone, 1);
    dl->AddRectFilled(at(c, s, -0.25f, -1.0f), at(c, s, 0.25f, 0.8f), stone, 1);
    for (float x : {-1.0f, -0.25f, 0.55f})
        for (int k = 0; k < 2; ++k) {
            float top = x == -0.25f ? -1.0f : -0.75f;
            dl->AddRectFilled(at(c, s, x + k * 0.27f, top - 0.18f), at(c, s, x + k * 0.27f + 0.17f, top), stone);
        }
    dl->AddRectFilled(at(c, s, -0.2f, 0.3f), at(c, s, 0.2f, 0.8f), dark, 4, ImDrawFlags_RoundTop);
    dl->AddLine(at(c, s, 0, -1.2f), at(c, s, 0, -1.75f), dark, 1.5f);
    poly(dl, c, s, {{0, -1.75f}, {0.6f, -1.6f}, {0, -1.45f}}, col::gold);
}

void draw_tent(ImDrawList* dl, ImVec2 c, float s, ImU32 color, bool cleared) {
    ImU32 body = cleared ? IM_COL32(90, 90, 96, 255) : color;
    poly(dl, c, s, {{0, -1.0f}, {1.0f, 0.7f}, {-1.0f, 0.7f}}, body, mix(body, IM_COL32(0, 0, 0, 255), 0.45f));
    poly(dl, c, s, {{0, -0.2f}, {0.35f, 0.7f}, {-0.35f, 0.7f}}, mix(body, IM_COL32(0, 0, 0, 255), 0.55f));
    dl->AddLine(at(c, s, 0, -1.0f), at(c, s, 0, -1.55f), IM_COL32(60, 50, 40, 255), 1.5f);
    if (!cleared) poly(dl, c, s, {{0, -1.55f}, {0.55f, -1.42f}, {0, -1.28f}}, color);
}

void draw_tower(ImDrawList* dl, ImVec2 c, float s, int stage) {
    ImU32 stone = stage == 0 ? IM_COL32(110, 110, 120, 120) : stage == 1 ? IM_COL32(150, 160, 180, 255) : IM_COL32(190, 196, 214, 255);
    if (stage == 0) {
        dl->AddRect(at(c, s, -0.5f, -0.9f), at(c, s, 0.5f, 0.8f), stone, 1.0f, 1.5f);
        return;
    }
    dl->AddRectFilled(at(c, s, -0.5f, -0.9f), at(c, s, 0.5f, 0.8f), stone, 1);
    for (int k = 0; k < 3; ++k) dl->AddRectFilled(at(c, s, -0.5f + k * 0.38f, -1.15f), at(c, s, -0.26f + k * 0.38f, -0.9f), stone);
    dl->AddRectFilled(at(c, s, -0.15f, -0.4f), at(c, s, 0.15f, -0.05f), IM_COL32(40, 40, 50, 255));
    if (stage >= 2) dl->AddRectFilled(at(c, s, -0.5f, -0.95f), at(c, s, 0.5f, -0.85f), col::gold);
}

void draw_lair(ImDrawList* dl, ImVec2 c, float s, bool sealed, bool cleared, float time) {
    ImU32 rock = cleared ? IM_COL32(80, 80, 86, 255) : IM_COL32(92, 80, 70, 255);
    if (!sealed && !cleared) {
        float pulse = 0.5f + 0.5f * std::sin(time * 3.0f);
        dl->AddCircleFilled(c, s * (1.6f + 0.25f * pulse), alpha(col::red, 0.10f + 0.12f * pulse));
    }
    poly(dl, c, s, {{-1.2f, 0.7f}, {-0.8f, -0.4f}, {-0.2f, -0.95f}, {0.5f, -0.8f}, {1.1f, -0.1f}, {1.25f, 0.7f}}, rock, mix(rock, IM_COL32(0, 0, 0, 255), 0.5f));
    dl->PathArcTo(at(c, s, 0, 0.7f), s * 0.62f, kPi, 2 * kPi, 16);
    dl->PathFillConvex(IM_COL32(12, 10, 10, 255));
    if (!cleared) {
        ImU32 eye = sealed ? IM_COL32(150, 60, 60, 255) : IM_COL32(255, 80, 60, 255);
        dl->AddCircleFilled(at(c, s, -0.18f, 0.38f), s * 0.09f, eye);
        dl->AddCircleFilled(at(c, s, 0.18f, 0.38f), s * 0.09f, eye);
    }
    if (sealed) {
        dl->AddCircle(c, s * 1.35f, IM_COL32(150, 150, 170, 200), 0, 2.0f);
        for (int k = 0; k < 6; ++k) {
            float a = k * kPi / 3 + 0.3f;
            dl->AddCircle(ImVec2(c.x + std::cos(a) * s * 1.35f, c.y + std::sin(a) * s * 1.35f), s * 0.16f, IM_COL32(170, 170, 190, 230), 8, 1.5f);
        }
    }
}

void draw_monster(ImDrawList* dl, ImVec2 c, float s, bool cleared, float time) {
    ImU32 body = cleared ? IM_COL32(86, 80, 90, 255) : IM_COL32(150, 70, 160, 255);
    float bob = cleared ? 0 : std::sin(time * 2.2f + c.x * 0.01f) * s * 0.08f;
    c.y += bob;
    dl->AddCircleFilled(c, s * 0.75f, body);
    for (int k = -1; k <= 1; ++k) dl->AddCircleFilled(at(c, s, k * 0.45f, -0.75f), s * 0.22f, body);
    if (cleared) {
        dl->AddLine(at(c, s, -0.4f, -0.4f), at(c, s, 0.4f, 0.4f), IM_COL32(30, 30, 30, 255), 2);
        dl->AddLine(at(c, s, 0.4f, -0.4f), at(c, s, -0.4f, 0.4f), IM_COL32(30, 30, 30, 255), 2);
    } else {
        dl->AddCircleFilled(at(c, s, -0.25f, -0.05f), s * 0.12f, IM_COL32(255, 230, 120, 255));
        dl->AddCircleFilled(at(c, s, 0.25f, -0.05f), s * 0.12f, IM_COL32(255, 230, 120, 255));
    }
}

// --- Отряды в бою -----------------------------------------------------------

void draw_unit(ImDrawList* dl, ImVec2 c, float r, const Stack& s, int side, int faction_index, float a, float flash) {
    ImU32 base = side == 0 ? kOurs : mix(faction_color(faction_index), IM_COL32(20, 20, 24, 255), 0.35f);
    if (s.icon == "boss") base = mix(faction_color(faction_index), IM_COL32(30, 10, 10, 255), 0.25f);
    base = alpha(mix(base, IM_COL32(255, 255, 255, 255), flash * 0.6f), a);
    ImU32 rim = alpha(side == 0 ? IM_COL32(140, 180, 255, 255) : faction_color(faction_index), a);
    ImU32 ink = alpha(IM_COL32(240, 236, 226, 255), a);

    if (side == 0) {
        dl->AddCircleFilled(c, r, base);
        dl->AddCircle(c, r, rim, 0, 2.0f);
    } else {
        std::vector<ImVec2> star;
        for (int k = 0; k < 24; ++k) {
            float ang = k * kPi / 12, rr = (k % 2 ? 0.86f : 1.0f) * r;
            star.push_back(ImVec2(c.x + std::cos(ang) * rr, c.y + std::sin(ang) * rr));
        }
        dl->AddConcavePolyFilled(star.data(), int(star.size()), base);
        dl->AddPolyline(star.data(), int(star.size()), rim, 2.0f, ImDrawFlags_Closed);
    }

    float g = r * 0.75f;
    const std::string& i = s.icon;
    if (i == "guard") {
        poly(dl, c, g, {{-0.45f, -0.5f}, {0.45f, -0.5f}, {0.45f, 0.05f}, {0, 0.6f}, {-0.45f, 0.05f}}, alpha(IM_COL32(200, 206, 220, 255), a), ink);
        dl->AddLine(at(c, g, 0, -0.45f), at(c, g, 0, 0.45f), alpha(kOurs, a), 2);
    } else if (i == "archer") {
        dl->AddBezierQuadratic(at(c, g, -0.15f, -0.65f), at(c, g, 0.6f, 0), at(c, g, -0.15f, 0.65f), ink, 2.5f);
        dl->AddLine(at(c, g, -0.15f, -0.65f), at(c, g, -0.15f, 0.65f), ink, 1.0f);
        dl->AddLine(at(c, g, -0.55f, 0), at(c, g, 0.55f, 0), ink, 1.5f);
        poly(dl, c, g, {{0.65f, 0}, {0.42f, -0.12f}, {0.42f, 0.12f}}, ink);
    } else if (i == "knight") {
        dl->AddLine(at(c, g, 0, -0.7f), at(c, g, 0, 0.4f), ink, 3.5f);
        dl->AddLine(at(c, g, -0.35f, 0.25f), at(c, g, 0.35f, 0.25f), ink, 3.0f);
        dl->AddCircleFilled(at(c, g, 0, 0.6f), g * 0.13f, ink);
    } else if (i == "mage") {
        poly(dl, c, g, {{0, -0.7f}, {0.17f, -0.17f}, {0.7f, 0}, {0.17f, 0.17f}, {0, 0.7f}, {-0.17f, 0.17f}, {-0.7f, 0}, {-0.17f, -0.17f}}, alpha(IM_COL32(190, 220, 255, 255), a));
    } else if (i == "griffin") {
        poly(dl, c, g, {{0, 0.1f}, {-0.75f, -0.5f}, {-0.3f, 0.35f}}, ink);
        poly(dl, c, g, {{0, 0.1f}, {0.75f, -0.5f}, {0.3f, 0.35f}}, ink);
        dl->AddCircleFilled(at(c, g, 0, -0.2f), g * 0.2f, alpha(col::gold, a));
    } else if (i == "beast") {
        for (int k = -1; k <= 1; ++k) dl->AddLine(at(c, g, -0.35f + k * 0.3f, -0.5f), at(c, g, 0.05f + k * 0.3f, 0.5f), ink, 2.5f);
    } else if (i == "boss") {
        poly(dl, c, g, {{-0.5f, -0.05f}, {-0.5f, -0.55f}, {-0.25f, -0.3f}, {0, -0.7f}, {0.25f, -0.3f}, {0.5f, -0.55f}, {0.5f, -0.05f}}, alpha(col::gold, a));
        dl->AddCircleFilled(at(c, g, -0.22f, 0.3f), g * 0.12f, alpha(IM_COL32(255, 70, 50, 255), a));
        dl->AddCircleFilled(at(c, g, 0.22f, 0.3f), g * 0.12f, alpha(IM_COL32(255, 70, 50, 255), a));
    } else {
        text_center(dl, fonts.semibold, r * 0.95f, c, ink, i.c_str());
    }
}


}  // namespace

// ---------------------------------------------------------------------------

void App::game_act(const std::function<std::string()>& action, const std::string& done) {
    if (guard_busy()) return;
    std::string err = action();
    if (!err.empty()) {
        toast("Не получилось", err, col::red);
        return;
    }
    refresh_state();
    if (!done.empty()) toast("Готово", done, col::teal);
}

void App::watch_battle(BattleResult result, std::string title, int reward, bool raid) {
    float speed = battle_.speed;
    battle_ = {true, result, title, reward, raid, -1.2f, speed};
    replays_.insert(replays_.begin(), {std::move(result), std::move(title), reward, raid});
    if (replays_.size() > 6) replays_.pop_back();
}

void App::run_raid() {
    const Raid raid = world_.raids.front();
    BattleResult r = defend(world_, *game_log_, raid);
    refresh_state();
    std::string title = raid.enemy.name;
    replays_.insert(replays_.begin(), {r, title, 0, true});
    if (replays_.size() > 6) replays_.pop_back();
    toast(r.won ? "Набег отбит" : "Набег прорвался", std::format("{} — земли {}. Бой можно посмотреть во вкладке «Поход».", title, raid.region),
          r.won ? col::teal : col::red);
    if (!window_visible && notify) notify(r.won ? "Набег отбит" : "Набег прорвался", title + " — земли " + raid.region);
}

void App::page_game() {
    if (battle_.active) {
        game_battle();
        return;
    }
    if (!world_.started) {
        game_intro();
        return;
    }

    // Верхняя полоса: казна, сила армии, вкладки, повторы боёв.
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 p = ImGui::GetCursorScreenPos();
    float h = ImGui::GetFrameHeight();
    draw_coin(dl, ImVec2(p.x + h * 0.5f, p.y + h * 0.5f), h * 0.42f);
    ImGui::Dummy(ImVec2(h, h));
    ImGui::SameLine();
    ImGui::AlignTextToFramePadding();
    ImGui::PushFont(fonts.semibold, 18.0f);
    colored_text(col::gold, std::to_string(world_.gold).c_str());
    ImGui::PopFont();
    tooltip("Золото приносят побочные квесты (×3 к их очкам), победы и отбитые набеги.");
    ImGui::SameLine(0, px(24));
    ImGui::AlignTextToFramePadding();
    dim_text("Сила армии %d  ·  боссов повержено %d", power_of(world_.army.stacks), world_.bosses_defeated);

    static const char* tabs[3] = {"Карта", "Город", "Летопись"};
    const char* tab_icons[3] = {icon::map, icon::town, icon::book};
    float tabs_w = 0;
    for (int i = 0; i < 3; ++i) tabs_w += ImGui::CalcTextSize(std::format("{}  {}", tab_icons[i], tabs[i]).c_str()).x + ImGui::GetStyle().FramePadding.x * 2 + ImGui::GetStyle().ItemSpacing.x;
    float replay_w = replays_.empty() ? 0 : px(150);
    ImGui::SameLine(ImGui::GetCursorPosX() + ImGui::GetContentRegionAvail().x - tabs_w - replay_w);
    for (int i = 0; i < 3; ++i) {
        bool on = game_tab_ == i;
        ImGui::PushStyleColor(ImGuiCol_Button, on ? alpha(col::gold, 0.25f) : col::panel_hi);
        ImGui::PushStyleColor(ImGuiCol_Text, on ? col::gold : col::text);
        if (ImGui::Button(std::format("{}  {}", tab_icons[i], tabs[i]).c_str())) {
            game_tab_ = i;
            if (i == 2) chronicle_scroll_ = true;
        }
        ImGui::PopStyleColor(2);
        ImGui::SameLine();
    }
    if (!replays_.empty()) {
        ImGui::SetNextItemWidth(replay_w - px(8));
        if (ImGui::BeginCombo("##replays", "Повторы боёв")) {
            for (size_t i = 0; i < replays_.size(); ++i) {
                auto& r = replays_[i];
                if (ImGui::Selectable(std::format("{} {}##r{}", r.result.won ? "★" : "✗", r.title, i).c_str())) {
                    Replay copy = r;
                    float speed = battle_.speed;
                    battle_ = {true, copy.result, copy.title, copy.reward, copy.raid, -1.2f, speed};
                }
            }
            ImGui::EndCombo();
        }
    } else {
        ImGui::NewLine();
    }
    ImGui::Dummy(ImVec2(0, px(2)));

    switch (game_tab_) {
        case 0: {
            float panel_w = px(340);
            ImGui::BeginChild("mapview", ImVec2(ImGui::GetContentRegionAvail().x - panel_w - px(10), 0), ImGuiChildFlags_Borders,
                              ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
            game_map();
            ImGui::EndChild();
            ImGui::SameLine();
            ImGui::BeginChild("mappanel", ImVec2(0, 0), ImGuiChildFlags_Borders | ImGuiChildFlags_AlwaysUseWindowPadding);
            game_panel();
            ImGui::EndChild();
            break;
        }
        case 1: game_town(); break;
        default: game_chronicle(); break;
    }
}

void App::game_intro() {
    float w = std::min(px(760), ImGui::GetContentRegionAvail().x);
    ImGui::SetCursorPosX((ImGui::GetContentRegionAvail().x - w) * 0.5f + ImGui::GetCursorPosX());
    card_begin("intro", ImVec2(w, 0));
    ImGui::PushFont(fonts.semibold, 28.0f);
    colored_text(col::gold, std::format("{}  Поход", icon::game).c_str());
    ImGui::PopFont();
    ImGui::TextWrapped("Королевство платформы живёт спокойно, но на его рубежах собираются шесть враждебных фракций. "
                       "Каждая угроза из ваших дизайн-документов — их лагерь, каждая ветка — логово босса, каждая находка — "
                       "выслеженный монстр.");
    ImGui::Dummy(ImVec2(0, px(6)));
    subheading("Как работа превращается в поход");
    struct Row {
        const char* work;
        const char* game;
    };
    static const Row rows[] = {
        {"Угроза STRIDE в документе", "Лагерь фракции: Подменыши, Искажатели, Отрекшиеся, Соглядатаи, Осаждающие, Узурпаторы"},
        {"Митигация угрозы (Threat:) и её тест", "Броня против фракции. Без неё лагеря и боссы этой фракции неприступны"},
        {"Пойманный класс CWE", "Школа магии. Защищённых чарами боссов без нужной школы не одолеть"},
        {"Побочные квесты", "Золото: найм войск, обучение элиты, свитки в гильдии магов"},
        {"Ветка задачи", "Логово босса. Чары спадают, когда задача сдана (ветка влита в main)"},
        {"Находка", "Монстр, которого можно добить ради добычи"},
        {"Неразобранные классы STRIDE", "Туман неизведанного на землях кампании"},
        {"Угроза без митигации", "Еженедельные набеги. Отбиваются армией и крепостями (точками интеграции)"},
    };
    if (ImGui::BeginTable("mapping", 2, ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersInnerH | ImGuiTableFlags_SizingStretchProp)) {
        ImGui::TableSetupColumn("work", ImGuiTableColumnFlags_WidthStretch, 1.0f);
        ImGui::TableSetupColumn("game", ImGuiTableColumnFlags_WidthStretch, 1.6f);
        for (auto& r : rows) {
            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            dim_text("%s", r.work);
            ImGui::TableNextColumn();
            ImGui::TextWrapped("%s", r.game);
        }
        ImGui::EndTable();
    }
    ImGui::Dummy(ImVec2(0, px(4)));
    wrapped_dim("Поражения стоят только игровых ресурсов: войск и золота. Очки и уровни за работу не сгорают никогда.");
    ImGui::Dummy(ImVec2(0, px(8)));
    if (accent_button("Выступить в поход", ImVec2(px(220), px(42))))
        game_act([&] { return start_game(*game_log_); }, std::format("В казне {} золота. Загляните в город и наймите войска.", world_.gold));
    card_end();
}

void App::game_map() {
    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 p0 = ImGui::GetCursorScreenPos();
    ImVec2 size = ImGui::GetContentRegionAvail();
    float time = float(clock());

    // Масштаб «по размеру» считается один раз; дальше колесо мыши и перетаскивание.
    if (map_zoom_ <= 0) {
        float minx = 0, maxx = 0, miny = 0, maxy = 0;
        for (auto& r : world_.regions) {
            minx = std::min(minx, r.x - r.radius);
            maxx = std::max(maxx, r.x + r.radius);
            miny = std::min(miny, r.y - r.radius);
            maxy = std::max(maxy, r.y + r.radius);
        }
        map_zoom_ = std::min(size.x / (maxx - minx + 80), size.y / (maxy - miny + 80));
        map_pan_ = ImVec2((minx + maxx) * 0.5f, (miny + maxy) * 0.5f);
    }
    ImVec2 center(p0.x + size.x * 0.5f, p0.y + size.y * 0.5f);
    auto S = [&](float x, float y) { return ImVec2(center.x + (x - map_pan_.x) * map_zoom_, center.y + (y - map_pan_.y) * map_zoom_); };

    ImGui::InvisibleButton("canvas", size, ImGuiButtonFlags_MouseButtonLeft);
    bool hovered = ImGui::IsItemHovered();
    bool released = ImGui::IsItemDeactivated();
    static bool dragged = false;
    if (ImGui::IsItemActivated()) dragged = false;
    if (ImGui::IsItemActive() && ImGui::IsMouseDragging(ImGuiMouseButton_Left, 3.0f)) {
        ImVec2 d = ImGui::GetIO().MouseDelta;
        map_pan_.x -= d.x / map_zoom_;
        map_pan_.y -= d.y / map_zoom_;
        dragged = true;
    }
    if (hovered && ImGui::GetIO().MouseWheel != 0) {
        ImVec2 m = ImGui::GetIO().MousePos;
        float wx = (m.x - center.x) / map_zoom_ + map_pan_.x, wy = (m.y - center.y) / map_zoom_ + map_pan_.y;
        map_zoom_ = std::clamp(map_zoom_ * std::pow(1.15f, ImGui::GetIO().MouseWheel), 0.2f, 3.0f);
        map_pan_.x = wx - (m.x - center.x) / map_zoom_;
        map_pan_.y = wy - (m.y - center.y) / map_zoom_;
    }

    dl->PushClipRect(p0, add(p0, size), true);
    dl->AddRectFilled(p0, add(p0, size), kGround);
    // Лёгкая «бумажная» сетка, чтобы карта не выглядела пустой.
    for (int i = -20; i <= 20; ++i) {
        ImVec2 a = S(i * 100.0f, -2000), b = S(i * 100.0f, 2000);
        dl->AddLine(a, b, IM_COL32(255, 255, 255, 5));
        a = S(-2000, i * 100.0f), b = S(2000, i * 100.0f);
        dl->AddLine(a, b, IM_COL32(255, 255, 255, 5));
    }

    // Дороги из столицы.
    for (auto& r : world_.regions) {
        if (r.id == "capital") continue;
        ImVec2 a = S(0, 0), b = S(r.x, r.y);
        int dashes = int(std::hypot(b.x - a.x, b.y - a.y) / 12);
        for (int k = 0; k < dashes; k += 2)
            dl->AddLine(lerp(a, b, float(k) / dashes), lerp(a, b, float(k + 1) / dashes), r.explored ? IM_COL32(120, 104, 74, 200) : IM_COL32(80, 76, 66, 120), 3 * map_zoom_);
    }

    // Земли.
    for (auto& r : world_.regions) {
        if (r.id == "capital") continue;
        std::vector<ImVec2> blob;
        for (int k = 0; k < 48; ++k) {
            float a = k * 2 * kPi / 48;
            float rr = r.radius * (1 + 0.06f * std::sin(a * 3 + r.color_seed) + 0.04f * std::sin(a * 7 + r.color_seed * 2));
            blob.push_back(S(r.x + std::cos(a) * rr, r.y + std::sin(a) * rr));
        }
        ImU32 fill = r.explored ? kRegionColors[r.color_seed % 8] : IM_COL32(38, 41, 50, 255);
        dl->AddConcavePolyFilled(blob.data(), int(blob.size()), fill);
        dl->AddPolyline(blob.data(), int(blob.size()), mix(fill, IM_COL32(0, 0, 0, 255), 0.4f), 2.0f, ImDrawFlags_Closed);
        if (r.campaign && r.explored)
            for (int f = 0; f < kFactions; ++f) {
                if (!r.sectors[size_t(f)]) continue;
                float a = (60.0f * f - 90.0f) * kPi / 180.0f;
                ImVec2 c = S(r.x + std::cos(a) * 125, r.y + std::sin(a) * 125);
                dl->AddCircleFilled(c, 46 * map_zoom_, alpha(faction_color(f), 0.07f));
                char letter[2] = {faction(f).letter, 0};
                text_center(dl, fonts.semibold, std::max(10.0f, 22 * map_zoom_), ImVec2(c.x, c.y - 44 * map_zoom_), alpha(faction_color(f), 0.45f), letter);
            }
    }

    // Узлы.
    float s = std::clamp(12.0f * map_zoom_ * 1.4f, 7.0f, 22.0f);
    const Node* hover_node = nullptr;
    ImVec2 mouse = ImGui::GetIO().MousePos;
    for (auto& n : world_.nodes) {
        ImVec2 c = S(n.x, n.y);
        bool sel = n.id == selected_node_;
        if (sel) dl->AddCircle(c, s * 1.9f, col::gold, 0, 2.0f);
        switch (n.kind) {
            case Node::Capital: draw_castle(dl, c, s * 1.5f); break;
            case Node::Camp: draw_tent(dl, c, s, faction_color(n.sector), n.cleared); break;
            case Node::Fort: draw_tower(dl, c, s, n.stage); break;
            case Node::Lair: draw_lair(dl, c, s, n.sealed, n.cleared, time); break;
            case Node::Monster: draw_monster(dl, c, s * 0.9f, n.cleared, time); break;
        }
        if (n.kind == Node::Camp && !n.cleared && !battle_blocker(world_.army, n.enemy).empty())
            dl->AddText(fonts.regular, s * 0.9f, ImVec2(c.x + s * 0.7f, c.y - s * 1.3f), col::dim, icon::lock);
        if (hovered && std::hypot(mouse.x - c.x, mouse.y - c.y) < s * 1.4f) hover_node = &n;
    }

    // Туман неизведанного: целые неразведанные земли и неразобранные секторы STRIDE.
    for (auto& r : world_.regions) {
        if (!r.explored) {
            for (int k = 0; k < 4; ++k) {
                float a = k * kPi / 2 + 0.4f;
                draw_fog(dl, S(r.x + std::cos(a) * r.radius * 0.45f, r.y + std::sin(a) * r.radius * 0.45f), r.radius * 0.75f * map_zoom_, hash(r.id) + k, time);
            }
            draw_fog(dl, S(r.x, r.y), r.radius * 0.8f * map_zoom_, hash(r.id) + 9, time);
            continue;
        }
        if (!r.campaign) continue;
        for (int f = 0; f < kFactions; ++f) {
            if (r.sectors[size_t(f)]) continue;
            float a = (60.0f * f - 90.0f) * kPi / 180.0f;
            ImVec2 c = S(r.x + std::cos(a) * 125, r.y + std::sin(a) * 125);
            draw_fog(dl, c, 62 * map_zoom_, hash(r.id) * 7 + f, time);
            text_center(dl, fonts.semibold, std::max(10.0f, 20 * map_zoom_), c, IM_COL32(120, 124, 140, 200), "?");
        }
    }

    // Названия земель поверх тумана.
    for (auto& r : world_.regions) {
        if (r.id == "capital") continue;
        ImVec2 c = S(r.x, r.y - r.radius - 16);
        std::string name = r.explored ? r.name : (r.campaign ? r.name + " — не разведаны" : r.name);
        text_center(dl, fonts.semibold, std::clamp(18 * map_zoom_ * 1.3f, 11.0f, 22.0f), c, r.explored ? IM_COL32(230, 220, 196, 255) : IM_COL32(140, 140, 150, 255), name.c_str());
    }
    dl->PopClipRect();

    if (hover_node) {
        ImGui::BeginTooltip();
        ImGui::TextUnformatted(hover_node->label.c_str());
        if (!hover_node->detail.empty()) dim_text("%s", hover_node->detail.c_str());
        ImGui::EndTooltip();
    }
    if (released && !dragged) selected_node_ = hover_node ? hover_node->id : "";

    // Подсказка внизу карты.
    ImGui::SetCursorScreenPos(ImVec2(p0.x + px(10), p0.y + size.y - ImGui::GetFontSize() - px(10)));
    dim_text("Колесо — масштаб, перетаскивание — сдвиг, щелчок — подробности");
}

void App::game_panel() {
    const Node* n = selected_node_.empty() ? nullptr : world_.node(selected_node_);
    if (!n) {
        // Герой, снаряжение, магия и армия.
        ImGui::PushFont(fonts.semibold, 20.0f);
        ImGui::Text("Герой · уровень %d", world_.level);
        ImGui::PopFont();
        dim_text("Атака +%d  ·  Защита +%d  ·  Сила магии %d", world_.army.hero_atk, world_.army.hero_def, world_.army.hero_power);
        tooltip("Атака растёт от навыков реализации и охоты, защита — от проектирования и интеграции, магия — от обучения и наставничества.");
        ImGui::Dummy(ImVec2(0, px(4)));

        subheading("Броня против фракций");
        float tw = (ImGui::GetContentRegionAvail().x - px(5) * 5) / 6;
        for (int f = 0; f < kFactions; ++f) {
            if (f) ImGui::SameLine(0, px(5));
            int a = world_.army.armor[size_t(f)];
            char letter[2] = {faction(f).letter, 0};
            std::string tier = a ? std::string(size_t(a), '|') : "—";
            std::string tip = a ? std::format("Броня против {}: ступень {}. Урон от них −{}%.", faction(f).genitive, a, std::min(4, a) * 15)
                                : std::format("Брони против {} нет: их лагеря и боссы неприступны. Митигируйте угрозу класса {}.", faction(f).genitive, faction(f).letter);
            tile(letter, tier.c_str(), ImVec2(tw, px(52)), a > 0, kFactionColors[f], tip.c_str());
        }
        ImGui::Dummy(ImVec2(0, px(4)));
        subheading("Школы магии");
        for (int sc = 0; sc < kSchools; ++sc) {
            int lvl = world_.army.spells[size_t(sc)], scrolls = world_.army.scrolls[size_t(sc)];
            ImGui::PushStyleColor(ImGuiCol_Text, lvl ? kSchoolColors[sc] : (scrolls ? col::text : col::faint));
            ImGui::Text("%s %s", lvl ? "◆" : "◇", school(sc).name);
            ImGui::PopStyleColor();
            tooltip(std::format("Заклинание «{}». Открывается уязвимостью из ветки «{}» в бестиарии; сила растёт с числом пойманных классов. "
                                "Свиток действует один бой.",
                                school(sc).spell, school(sc).skill)
                        .c_str());
            ImGui::SameLine(ImGui::GetCursorPosX() + ImGui::GetContentRegionAvail().x - px(110));
            if (lvl) dim_text("ур. %d", lvl);
            if (scrolls) {
                if (lvl) ImGui::SameLine();
                dim_text("свитков %d", scrolls);
            }
            if (!lvl && !scrolls) dim_text("закрыта");
        }
        ImGui::Dummy(ImVec2(0, px(4)));
        subheading("Армия");
        if (world_.army.stacks.empty()) wrapped_dim("В строю никого. Наймите войска в городе — золото приносят побочные квесты.");
        for (auto& s : world_.army.stacks) {
            ImGui::BulletText("%s × %d", s.name.c_str(), s.count);
        }
        ImGui::Dummy(ImVec2(0, px(6)));
        if (accent_button(std::format("{}  В город", icon::town).c_str(), ImVec2(-1, 0))) game_tab_ = 1;
        ImGui::Dummy(ImVec2(0, px(6)));
        wrapped_dim("Щёлкните по лагерю, логову или монстру на карте, чтобы увидеть противника.");
        return;
    }

    ImGui::PushFont(fonts.semibold, 20.0f);
    ImGui::TextWrapped("%s", n->label.c_str());
    ImGui::PopFont();
    if (!n->detail.empty()) wrapped_dim(n->detail);
    if (ImGui::SmallButton("× Закрыть")) selected_node_.clear();
    ImGui::Separator();

    if (n->kind == Node::Capital) {
        ImGui::TextWrapped("Столица королевства. Здесь нанимают войска, обучают элиту и покупают свитки.");
        if (accent_button("В город", ImVec2(-1, 0))) game_tab_ = 1;
        return;
    }
    if (n->kind == Node::Fort) {
        static const char* stages[3] = {"заложена", "построена", "укреплена"};
        ImGui::Text("Крепость %s", stages[std::clamp(n->stage, 0, 2)]);
        wrapped_dim(std::format("Каждая ступень — башня, которая бьёт по налётчикам при набеге на земли {}. Достраивается трейлерами "
                                "Integration: и Integration-Test:.",
                                n->region));
        return;
    }

    const Enemy& e = n->enemy;
    if (n->cleared) {
        colored_text(col::teal, std::format("{} Повержен", icon::check).c_str());
        return;
    }
    if (n->sealed) {
        colored_text(col::orange, std::format("{} Логово запечатано", icon::lock).c_str());
        wrapped_dim("Босс неуязвим, пока задача не сдана. Влейте ветку в main — чары спадут при следующей синхронизации.");
    }
    if (e.faction >= 0) {
        ImGui::PushStyleColor(ImGuiCol_Text, kFactionColors[e.faction]);
        ImGui::Text("Фракция: %s", faction(e.faction).name);
        ImGui::PopStyleColor();
    }
    ImGui::Text("Ступень угрозы: %d", e.tier);
    if (e.shield_school >= 0) {
        ImGui::PushStyleColor(ImGuiCol_Text, kSchoolColors[e.shield_school]);
        ImGui::TextWrapped("Защищён чарами: нужна %s", school(e.shield_school).name);
        ImGui::PopStyleColor();
    }
    ImGui::Dummy(ImVec2(0, px(2)));
    subheading("Войско противника");
    for (auto& s : e.stacks) {
        ImGui::BulletText("%s × %d", s.name.c_str(), s.count);
        ImGui::SameLine();
        dim_text("(здоровье %d, атака %d, защита %d)", s.hp, s.atk, s.def);
    }

    int ours = power_of(world_.army.stacks), theirs = power_of(e.stacks);
    ImGui::Dummy(ImVec2(0, px(4)));
    dim_text("Сила: ваша %d против %d", ours, theirs);
    float frac = ours + theirs > 0 ? float(ours) / float(ours + theirs) : 0.5f;
    bar(frac, ImVec2(0, px(8)), kOurs, IM_COL32(110, 160, 255, 255), alpha(faction_color(e.faction), 0.6f));
    if (e.faction >= 0 && world_.army.armor[size_t(e.faction)] == 0) colored_text(col::red, "Без брони: урон ваших войск вдвое ниже.");
    dim_text("Награда: %d золота", e.reward);

    ImGui::Dummy(ImVec2(0, px(6)));
    std::string blocker = n->sealed ? "" : battle_blocker(world_.army, e);
    if (!blocker.empty()) {
        card_begin("blocker", ImVec2(0, 0), alpha(col::red, 0.12f));
        colored_text(col::red, std::format("{} Пока не пройти", icon::lock).c_str());
        ImGui::TextWrapped("%s", blocker.c_str());
        card_end();
    }
    ImGui::BeginDisabled(n->sealed || !blocker.empty());
    if (accent_button("В бой!", ImVec2(-1, px(40)), col::red)) {
        std::string id = n->id, name = e.name;
        int reward = e.reward;
        BattleResult r = fight(world_, *game_log_, id);
        refresh_state();
        watch_battle(std::move(r), name, reward, false);
    }
    ImGui::EndDisabled();
    if (!n->sealed && blocker.empty()) wrapped_dim("Поражение стоит войск, но не очков за работу. Лагерь можно атаковать снова.");
}

void App::game_town() {
    heading("Город");
    wrapped_dim(std::format("В казне {} золота. Золото приносят побочные квесты (×3 к их очкам), победы и отбитые набеги. "
                            "Новые войска открываются с ростом уровня героя — то есть с вашей работой.",
                            world_.gold));
    ImGui::Dummy(ImVec2(0, px(4)));

    auto& units = unit_types();
    int columns = std::max(1, int(ImGui::GetContentRegionAvail().x / px(300)));
    if (ImGui::BeginTable("units", columns, ImGuiTableFlags_SizingStretchSame)) {
        for (size_t i = 0; i < units.size(); ++i) {
            const UnitType& u = units[i];
            ImGui::TableNextColumn();
            ImGui::PushID(int(i));
            bool locked = world_.level < u.level_req;
            card_begin("unit");
            ImDrawList* dl = ImGui::GetWindowDrawList();
            ImVec2 p = ImGui::GetCursorScreenPos();
            Stack preview;
            preview.icon = u.id;
            draw_unit(dl, ImVec2(p.x + px(26), p.y + px(26)), px(24), preview, 0, -1, locked ? 0.4f : 1.0f, 0);
            ImGui::Dummy(ImVec2(px(56), px(52)));
            ImGui::SameLine();
            ImGui::BeginGroup();
            subheading(u.name);
            dim_text("элита: %s", u.elite_name);
            wrapped_dim(std::format("{} здоровья · атака {} · защита {} · урон {}–{}{}", u.hp, u.atk, u.def, u.dmg_min, u.dmg_max, u.ranged ? " · стрелок" : ""));
            ImGui::EndGroup();

            int have = world_.army_count(int(i), false), elite = world_.army_count(int(i), true);
            if (have || elite) dim_text("В строю: %d, элиты %d", have, elite);
            if (locked) {
                colored_text(col::faint, std::format("{} Откроется на {} уровне героя", icon::lock, u.level_req).c_str());
            } else {
                int& count = hire_counts_[int(i)];
                if (count <= 0) count = std::max(1, std::min(5, world_.gold / u.cost));
                ImGui::SetNextItemWidth(px(110));
                ImGui::InputInt("##count", &count, 1, 5);
                count = std::clamp(count, 1, 999);
                ImGui::SameLine();
                bool afford = u.cost * count <= world_.gold;
                ImGui::BeginDisabled(!afford);
                if (accent_button(std::format("Нанять · {}", u.cost * count).c_str(), ImVec2(-1, 0)))
                    game_act([&] { return hire(world_, *game_log_, int(i), count); }, std::format("{} × {} встали под знамёна", u.name, count));
                ImGui::EndDisabled();
                if (have > 0) {
                    int cost = upgrade_cost(int(i)) * have;
                    ImGui::BeginDisabled(cost > world_.gold);
                    if (ImGui::Button(std::format("Обучить всех {} до элиты · {}", have, cost).c_str(), ImVec2(-1, 0)))
                        game_act([&] { return upgrade(world_, *game_log_, int(i), have); }, std::format("Теперь это {}", u.elite_name));
                    ImGui::EndDisabled();
                }
            }
            card_end();
            ImGui::PopID();
        }
        ImGui::EndTable();
    }

    ImGui::Dummy(ImVec2(0, px(6)));
    heading("Гильдия магов");
    wrapped_dim(std::format("Школа магии открывается навсегда, когда вы ловите уязвимость её ветки. Пока школы нет, можно купить "
                            "свиток за {} золота: он снимает чары с одного босса.",
                            kScrollCost));
    if (ImGui::BeginTable("schools", 3, ImGuiTableFlags_SizingStretchSame)) {
        for (int sc = 0; sc < kSchools; ++sc) {
            ImGui::TableNextColumn();
            ImGui::PushID(sc + 100);
            card_begin("school");
            ImGui::PushStyleColor(ImGuiCol_Text, kSchoolColors[sc]);
            subheading(school(sc).name);
            ImGui::PopStyleColor();
            dim_text("«%s» · ветка «%s»", school(sc).spell, school(sc).skill);
            int lvl = world_.army.spells[size_t(sc)];
            if (lvl) colored_text(col::teal, std::format("{} Открыта, уровень {}", icon::check, lvl).c_str());
            else dim_text("Свитков: %d", world_.army.scrolls[size_t(sc)]);
            ImGui::BeginDisabled(world_.gold < kScrollCost || lvl > 0);
            if (ImGui::Button(std::format("Купить свиток · {}", kScrollCost).c_str(), ImVec2(-1, 0)))
                game_act([&] { return buy_scroll(world_, *game_log_, sc); }, std::format("Свиток: {}", school(sc).name));
            ImGui::EndDisabled();
            card_end();
            ImGui::PopID();
        }
        ImGui::EndTable();
    }
}

void App::game_chronicle() {
    heading("Летопись");
    wrapped_dim("История похода, рассказанная по вашей работе.");
    ImGui::BeginChild("chronicle", ImVec2(0, 0), ImGuiChildFlags_Borders | ImGuiChildFlags_AlwaysUseWindowPadding);
    for (auto& c : world_.chronicle) {
        if (c.tone == Chronicle::Chapter) {
            ImGui::Dummy(ImVec2(0, px(6)));
            ImGui::PushFont(fonts.semibold, 19.0f);
            colored_text(col::gold, c.text.c_str());
            ImGui::PopFont();
            ImGui::Dummy(ImVec2(0, px(2)));
            continue;
        }
        ImU32 color = c.tone == Chronicle::Good ? col::teal : c.tone == Chronicle::Bad ? col::red : c.tone == Chronicle::Gold ? col::gold : col::dim;
        std::string when = c.time.size() >= 10 ? c.time.substr(0, 10) : c.time;
        dim_text("%s", when.c_str());
        ImGui::SameLine(px(100));
        ImGui::PushStyleColor(ImGuiCol_Text, mix(color, col::text, 0.55f));
        ImGui::TextWrapped("%s", c.text.c_str());
        ImGui::PopStyleColor();
    }
    if (chronicle_scroll_) {
        ImGui::SetScrollHereY(1.0f);
        chronicle_scroll_ = false;
    }
    ImGui::EndChild();
}

// ---------------------------------------------------------------------------
// Анимация боя: проигрывание заранее рассчитанного журнала ходов.

void App::game_battle() {
    BattleView& b = battle_;
    const BattleResult& r = b.result;
    int n = int(r.actions.size());
    b.progress = std::min(b.progress + ImGui::GetIO().DeltaTime * b.speed / kActionTime, float(n) + 2.0f);

    ImDrawList* dl = ImGui::GetWindowDrawList();
    ImVec2 p0 = ImGui::GetCursorScreenPos();
    ImVec2 size = ImGui::GetContentRegionAvail();
    ImGui::InvisibleButton("battlefield", size);
    ImVec2 p1 = add(p0, size);
    float W = size.x, H = size.y;
    float time = float(clock());

    // Поле: небо, холмы, земля.
    dl->AddRectFilledMultiColor(p0, ImVec2(p1.x, p0.y + H * 0.45f), IM_COL32(26, 32, 52, 255), IM_COL32(26, 32, 52, 255), IM_COL32(58, 52, 62, 255), IM_COL32(58, 52, 62, 255));
    std::vector<ImVec2> hills;
    for (int k = 0; k <= 40; ++k) {
        float x = p0.x + W * k / 40.0f;
        hills.push_back(ImVec2(x, p0.y + H * (0.40f + 0.04f * std::sin(k * 0.7f) + 0.02f * std::sin(k * 1.9f))));
    }
    hills.push_back(ImVec2(p1.x, p1.y));
    hills.push_back(ImVec2(p0.x, p1.y));
    dl->AddConcavePolyFilled(hills.data(), int(hills.size()), IM_COL32(36, 48, 38, 255));
    dl->AddRectFilledMultiColor(ImVec2(p0.x, p0.y + H * 0.5f), p1, IM_COL32(40, 54, 40, 255), IM_COL32(40, 54, 40, 255), IM_COL32(28, 36, 28, 255), IM_COL32(28, 36, 28, 255));

    // Текущее состояние отрядов: применяем потери всех ходов, чей удар уже прошёл.
    int cur = int(std::floor(b.progress));
    float phase = b.progress - float(cur);
    std::vector<int> counts[2];
    for (auto& s : r.ours) counts[0].push_back(s.count);
    for (auto& s : r.theirs) counts[1].push_back(s.count);
    std::vector<bool> shield;
    for (auto& s : r.theirs) shield.push_back(s.shielded);
    int round = 0;
    for (int i = 0; i < n && (i < cur || (i == cur && phase >= 0.55f)); ++i) {
        const BattleAction& a = r.actions[size_t(i)];
        int tside = a.side == 0 ? 1 : 0;
        if (a.kind == BattleAction::ShieldBreak) shield[size_t(a.target)] = false;
        counts[tside][size_t(a.target)] = std::max(0, counts[tside][size_t(a.target)] - a.kills);
        round = a.round;
    }

    float r_unit = std::clamp(H * 0.055f, 16.0f, 34.0f);
    auto pos = [&](int side, int idx) {
        int total = int(side == 0 ? r.ours.size() : r.theirs.size());
        float y = p0.y + H * (0.52f + 0.38f * (float(idx) + 0.5f) / float(std::max(total, 1)) - 0.19f);
        return ImVec2(p0.x + W * (side == 0 ? 0.24f : 0.76f), y);
    };
    ImVec2 hero(p0.x + W * 0.08f, p0.y + H * 0.36f);
    ImVec2 tower_origin(p0.x + W * 0.05f, p0.y + H * 0.12f);

    const BattleAction* act = (cur >= 0 && cur < n) ? &r.actions[size_t(cur)] : nullptr;
    int act_side = act ? act->side : -1, act_actor = act ? act->actor : -1;
    int tgt_side = act ? (act->side == 0 ? 1 : 0) : -1;

    // Герой и башни.
    dl->AddCircleFilled(hero, r_unit * 0.8f, IM_COL32(60, 50, 30, 255));
    dl->AddCircle(hero, r_unit * 0.8f, col::gold, 0, 2);
    poly(dl, hero, r_unit * 0.55f, {{0, -0.7f}, {0.2f, -0.2f}, {0.7f, -0.2f}, {0.3f, 0.15f}, {0.45f, 0.7f}, {0, 0.38f}, {-0.45f, 0.7f}, {-0.3f, 0.15f}, {-0.7f, -0.2f}, {-0.2f, -0.2f}}, col::gold);
    text_center(dl, fonts.semibold, 14, ImVec2(hero.x, hero.y + r_unit * 1.2f), col::gold, "Герой");
    if (b.raid) {
        draw_tower(dl, ImVec2(tower_origin.x, tower_origin.y + 20), 16, 2);
        text_center(dl, fonts.regular, 13, ImVec2(tower_origin.x, tower_origin.y + 52), col::dim, "Крепости");
    }

    // Отряды.
    for (int side = 0; side < 2; ++side) {
        const auto& stacks = side == 0 ? r.ours : r.theirs;
        for (size_t i = 0; i < stacks.size(); ++i) {
            ImVec2 c = pos(side, int(i));
            float flash = 0;
            if (act && act_side == side && act_actor == int(i) && act->kind == BattleAction::Melee) {
                ImVec2 t = pos(tgt_side, act->target);
                float lunge = phase < 0.5f ? ease(phase / 0.5f) : 1 - ease((phase - 0.5f) / 0.5f);
                c = lerp(c, t, 0.62f * lunge);
            }
            if (act && tgt_side == side && act->target == int(i) && phase >= 0.55f && phase < 0.85f) {
                flash = 1 - (phase - 0.55f) / 0.3f;
                c.x += std::sin(phase * 90) * 4 * flash;
            }
            int cnt = counts[side][i];
            float a = cnt > 0 ? 1.0f : 0.25f;
            draw_unit(dl, c, stacks[i].icon == "boss" ? r_unit * 1.35f : r_unit, stacks[i], side, side == 1 ? (stacks[i].icon.size() == 1 ? faction_of_letter(stacks[i].icon[0]) : -1) : -1, a, flash);
            if (side == 1 && shield[i]) {
                float pulse = 0.5f + 0.5f * std::sin(time * 4);
                dl->AddCircle(c, r_unit * 1.7f, alpha(IM_COL32(170, 200, 255, 255), 0.5f + 0.3f * pulse), 0, 3);
            }
            // Подпись: имя и число бойцов.
            std::string label = cnt > 0 ? std::format("{} × {}", stacks[i].name, cnt) : stacks[i].name + " — пали";
            ImVec2 ts = fonts.regular->CalcTextSizeA(14, FLT_MAX, 0, label.c_str());
            float ly = c.y + r_unit * (stacks[i].icon == "boss" ? 1.45f : 1.1f);
            dl->AddRectFilled(ImVec2(c.x - ts.x * 0.5f - 6, ly), ImVec2(c.x + ts.x * 0.5f + 6, ly + ts.y + 2), IM_COL32(10, 12, 18, 190), 6);
            dl->AddText(fonts.regular, 14, ImVec2(c.x - ts.x * 0.5f, ly + 1), cnt > 0 ? col::text : col::faint, label.c_str());
            // Полоса здоровья отряда.
            float frac = stacks[i].count ? float(cnt) / float(stacks[i].count) : 0;
            ImVec2 hb(c.x - r_unit, c.y - r_unit * 1.35f - 6);
            dl->AddRectFilled(hb, ImVec2(hb.x + r_unit * 2, hb.y + 5), IM_COL32(0, 0, 0, 160), 2);
            dl->AddRectFilled(hb, ImVec2(hb.x + r_unit * 2 * frac, hb.y + 5), side == 0 ? col::teal : col::red, 2);
        }
    }

    // Эффекты текущего хода.
    if (act) {
        ImVec2 tgt = pos(tgt_side, act->target);
        ImVec2 from = act->actor >= 0 ? pos(act->side, act->actor) : (act->kind == BattleAction::Tower ? tower_origin : hero);
        float travel = std::clamp((phase - 0.1f) / 0.45f, 0.0f, 1.0f);
        if (act->kind == BattleAction::Ranged || act->kind == BattleAction::Tower) {
            if (phase > 0.1f && phase < 0.58f) {
                ImVec2 pnt = lerp(from, tgt, travel);
                pnt.y -= std::sin(travel * kPi) * H * 0.06f;
                ImVec2 tail = lerp(from, tgt, std::max(0.0f, travel - 0.08f));
                tail.y -= std::sin(std::max(0.0f, travel - 0.08f) * kPi) * H * 0.06f;
                dl->AddLine(tail, pnt, act->kind == BattleAction::Tower ? col::gold : IM_COL32(230, 220, 190, 255), 2.5f);
                dl->AddCircleFilled(pnt, 3.5f, IM_COL32(255, 240, 200, 255));
            }
        } else if (act->kind == BattleAction::Spell || act->kind == BattleAction::ShieldBreak) {
            ImU32 sc = act->school >= 0 ? kSchoolColors[act->school] : col::violet;
            if (phase < 0.6f)
                for (int k = 0; k < 12; ++k) {
                    float t = std::clamp((phase - k * 0.02f) / 0.5f, 0.0f, 1.0f);
                    ImVec2 q = lerp(from, tgt, ease(t));
                    float swirl = (1 - t) * 26;
                    q.x += std::cos(k * 0.52f + phase * 12) * swirl;
                    q.y += std::sin(k * 0.52f + phase * 12) * swirl;
                    dl->AddCircleFilled(q, 3.5f * (1 - t * 0.5f), alpha(sc, 0.9f));
                }
            if (phase >= 0.55f) {
                float t = (phase - 0.55f) / 0.45f;
                dl->AddCircle(tgt, r_unit * (1.0f + 1.6f * t), alpha(sc, 1 - t), 0, 4 * (1 - t) + 1);
            }
            text_center(dl, fonts.semibold, 16, ImVec2(from.x + 40, from.y - r_unit - 14), alpha(sc, 1 - phase * 0.6f),
                        act->kind == BattleAction::ShieldBreak ? "Чары развеяны!" : school(act->school).spell);
        }
        if (phase >= 0.55f && act->damage > 0) {
            float t = (phase - 0.55f) / 0.45f;
            std::string dmg = act->kills > 0 ? std::format("−{}  ☠{}", act->damage, act->kills) : std::format("−{}", act->damage);
            text_center(dl, fonts.semibold, 20, ImVec2(tgt.x, tgt.y - r_unit - 18 - t * 30), alpha(tgt_side == 1 ? col::gold : col::red, 1 - t * 0.8f), dmg.c_str());
        }
    }

    // Заголовок и управление.
    text_center(dl, fonts.semibold, 24, ImVec2(p0.x + W * 0.5f, p0.y + 28), col::text, b.title.c_str());
    std::string sub = b.progress < 0 ? "Войска выстраиваются…" : std::format("Раунд {}", std::max(1, round));
    text_center(dl, fonts.regular, 16, ImVec2(p0.x + W * 0.5f, p0.y + 56), col::dim, sub.c_str());

    ImGui::SetCursorScreenPos(ImVec2(p0.x + px(12), p1.y - ImGui::GetFrameHeight() - px(12)));
    for (float sp : {1.0f, 2.0f, 4.0f}) {
        bool on = b.speed == sp;
        ImGui::PushStyleColor(ImGuiCol_Button, on ? alpha(col::gold, 0.35f) : col::panel_hi);
        if (ImGui::Button(std::format("×{}", int(sp)).c_str())) b.speed = sp;
        ImGui::PopStyleColor();
        ImGui::SameLine();
    }
    if (b.progress < float(n)) {
        if (ImGui::Button("Пропустить")) b.progress = float(n) + 2.0f;
    }

    // Итог.
    if (b.progress >= float(n) + 0.4f) {
        float t = std::clamp((b.progress - float(n) - 0.4f) / 0.6f, 0.0f, 1.0f);
        ImVec2 c(p0.x + W * 0.5f, p0.y + H * 0.45f);
        ImVec2 half(std::min(W * 0.36f, 380.0f), 120);
        dl->AddRectFilled(ImVec2(c.x - half.x, c.y - half.y), ImVec2(c.x + half.x, c.y + half.y), alpha(IM_COL32(14, 16, 24, 255), 0.92f * t), 14);
        dl->AddRect(ImVec2(c.x - half.x, c.y - half.y), ImVec2(c.x + half.x, c.y + half.y), alpha(r.won ? col::gold : col::red, t), 14.0f, 2.0f);
        const char* verdict = r.won ? (b.raid ? "Набег отбит!" : "Победа!") : (b.raid ? "Набег прорвался" : "Отступление");
        text_center(dl, fonts.semibold, 40, ImVec2(c.x, c.y - 70), alpha(r.won ? col::gold : col::red, t), verdict);
        std::string reward = r.won ? (b.reward > 0 ? std::format("Добыча: {} золота", b.reward) : (b.raid ? "Казна цела, +25 золота" : ""))
                                   : (b.raid ? "Налётчики разграбили часть казны" : "Противник устоял. Усильте армию и возвращайтесь.");
        text_center(dl, fonts.regular, 18, ImVec2(c.x, c.y - 26), alpha(col::text, t), reward.c_str());
        std::string losses;
        for (size_t i = 0; i < r.ours.size() && i < r.our_losses.size(); ++i)
            if (r.our_losses[i] > 0) losses += std::format("{}{} −{}", losses.empty() ? "" : ",  ", r.ours[i].name, r.our_losses[i]);
        text_center(dl, fonts.regular, 15, ImVec2(c.x, c.y + 6), alpha(col::dim, t), losses.empty() ? "Без потерь" : ("Потери: " + losses).c_str());
        if (!r.scrolls_used.empty()) text_center(dl, fonts.regular, 15, ImVec2(c.x, c.y + 30), alpha(col::dim, t), "Свиток израсходован");
        ImGui::SetCursorScreenPos(ImVec2(c.x - px(90), c.y + half.y - px(56)));
        if (accent_button("К карте", ImVec2(px(180), px(38)))) b.active = false;
    }
}

}  // namespace sq::gui
