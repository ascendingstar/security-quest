#include "quest.h"

#include "cwe.h"
#include "util.h"

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <format>
#include <map>
#include <numbers>
#include <set>

namespace sq::quest {

// ---------------------------------------------------------------------------
// Справочники

const FactionInfo& faction(int f) {
    static const FactionInfo table[kFactions] = {
        {'S', "Подменыши", "Подменышей", "Подменыш", "Двуликий", "Король Масок"},
        {'T', "Искажатели", "Искажателей", "Искажатель", "Ткач скверны", "Владыка Искажений"},
        {'R', "Отрекшиеся", "Отрекшихся", "Безымянный", "Отрекшийся", "Безликий Судия"},
        {'I', "Соглядатаи", "Соглядатаев", "Соглядатай", "Око тьмы", "Великий Шпион"},
        {'D', "Осаждающие", "Осаждающих", "Таран", "Осадный голем", "Повелитель Осады"},
        {'E', "Узурпаторы", "Узурпаторов", "Узурпатор", "Тёмный регент", "Самозваный Император"},
    };
    return table[std::clamp(f, 0, kFactions - 1)];
}

int faction_of_letter(char letter) {
    const std::string letters = "STRIDE";
    auto pos = letters.find(letter);
    return pos == std::string::npos ? -1 : int(pos);
}

const SchoolInfo& school(int s) {
    static const SchoolInfo table[kSchools] = {
        {"Память", "Магия Памяти", "Упокоение"},
        {"Конкурентность", "Магия Времени", "Остановка времени"},
        {"Криптография", "Рунная магия", "Печать рун"},
        {"Доступ", "Магия Врат", "Запечатывание врат"},
        {"Парсинг", "Магия Слова", "Очищение слова"},
        {"Дизайн API", "Магия Порядка", "Закон"},
    };
    return table[std::clamp(s, 0, kSchools - 1)];
}

const std::vector<UnitType>& unit_types() {
    static const std::vector<UnitType> units = {
        {"guard", "Стражник", "Страж цитадели", 20, 1, 12, 3, 5, 2, 3, 4, false},
        {"archer", "Лучник", "Следопыт", 35, 2, 9, 5, 2, 3, 4, 5, true},
        {"knight", "Рыцарь", "Паладин", 90, 3, 30, 8, 8, 6, 9, 5, false},
        {"mage", "Рунописец", "Архимаг", 120, 4, 14, 9, 3, 8, 11, 4, true},
        {"griffin", "Грифон", "Королевский грифон", 200, 6, 45, 11, 9, 10, 14, 8, false},
    };
    return units;
}

int unit_index(const std::string& id) {
    auto& u = unit_types();
    for (size_t i = 0; i < u.size(); ++i)
        if (id == u[i].id) return int(i);
    return -1;
}

int upgrade_cost(int unit) {
    return int(std::lround(unit_types()[size_t(unit)].cost * 0.6));
}

namespace {

uint32_t hash(std::string_view s) {
    uint32_t h = 2166136261u;
    for (unsigned char c : s) h = (h ^ c) * 16777619u;
    return h;
}

struct Rng {
    uint64_t state;
    explicit Rng(uint32_t seed) : state(seed * 0x9E3779B97F4A7C15ull + 1) {}
    uint32_t next() {
        state ^= state << 13;
        state ^= state >> 7;
        state ^= state << 17;
        return uint32_t(state >> 16);
    }
    int range(int lo, int hi) { return hi <= lo ? lo : lo + int(next() % uint32_t(hi - lo + 1)); }
};

int school_of_skill(const std::string& skill) {
    for (int s = 0; s < kSchools; ++s)
        if (skill == school(s).skill) return s;
    return -1;
}

Stack player_stack(int unit, bool elite, int count) {
    const UnitType& u = unit_types()[size_t(unit)];
    Stack s;
    s.name = elite ? u.elite_name : u.name;
    s.icon = u.id;
    s.count = count;
    s.hp = elite ? int(u.hp * 1.4) : u.hp;
    s.atk = u.atk + (elite ? 2 : 0);
    s.def = u.def + (elite ? 2 : 0);
    s.dmg_min = elite ? int(std::lround(u.dmg_min * 1.3)) : u.dmg_min;
    s.dmg_max = elite ? int(std::lround(u.dmg_max * 1.3)) : u.dmg_max;
    s.speed = u.speed + (elite ? 1 : 0);
    s.ranged = u.ranged;
    s.unit = unit;
    s.elite = elite;
    return s;
}

Stack faction_stack(int f, int tier, bool elite, int count) {
    struct Tweak {
        double hp;
        int atk, def, dmg, spd;
        bool ranged;
    };
    static const Tweak tweaks[kFactions] = {
        {1.0, 1, 0, 0, 2, false}, {1.0, 0, 0, 2, 0, false}, {1.1, 0, 3, 0, -1, false},
        {0.9, 1, 0, 0, 0, true},  {1.6, 0, 1, 1, -2, false}, {1.1, 3, 1, 0, 0, false},
    };
    const Tweak& t = tweaks[f];
    Stack s;
    s.name = elite ? faction(f).elite : faction(f).unit;
    s.icon = std::string(1, faction(f).letter);
    s.count = count;
    double grow = 1.0 + 0.2 * (tier - 1);
    s.hp = int(std::lround(13 * t.hp * grow * (elite ? 1.6 : 1.0)));
    s.atk = 5 + t.atk + 2 * (tier - 1) + (elite ? 3 : 0);
    s.def = 4 + t.def + 2 * (tier - 1) + (elite ? 2 : 0);
    s.dmg_min = int(std::lround((3 + t.dmg) * grow * (elite ? 1.4 : 1.0)));
    s.dmg_max = int(std::lround((5 + t.dmg) * grow * (elite ? 1.4 : 1.0)));
    s.speed = 5 + t.spd + (elite ? 1 : 0);
    s.ranged = t.ranged;
    return s;
}

Stack beast_stack(const std::string& name, int tier, int count) {
    Stack s;
    s.name = name;
    s.icon = "beast";
    s.count = count;
    s.hp = 12 + 6 * tier;
    s.atk = 4 + 2 * tier;
    s.def = 3 + 2 * tier;
    s.dmg_min = 2 + tier;
    s.dmg_max = 4 + 2 * tier;
    s.speed = 5;
    return s;
}

Stack boss_stack(const std::string& name, int tier) {
    Stack s;
    s.name = name;
    s.icon = "boss";
    s.count = 1;
    s.hp = 40 + 45 * tier;
    s.atk = 6 + 3 * tier;
    s.def = 5 + 2 * tier;
    s.dmg_min = 6 * tier;
    s.dmg_max = 9 * tier;
    s.speed = 6;
    return s;
}

Enemy camp_enemy(int f, int tier, const std::string& threat_id, double scale = 1.0) {
    Enemy e;
    e.faction = f;
    e.tier = tier;
    e.needs_armor = true;
    e.name = std::format("Лагерь {} ({})", faction(f).genitive, threat_id);
    e.title = faction(f).name;
    auto n = [&](int c) { return std::max(1, int(std::lround(c * scale))); };
    e.stacks.push_back(faction_stack(f, tier, false, n(5 + 4 * tier)));
    if (tier >= 2) e.stacks.push_back(faction_stack(f, tier, true, n(1 + tier)));
    if (tier >= 4) e.stacks.push_back(faction_stack(f, tier, false, n(6 + 2 * tier)));
    e.reward = 40 * tier;
    return e;
}

const char* monster_name(int school_index) {
    static const char* names[kSchools] = {"Неупокоенный", "Гончая гонок", "Слепой оракул",
                                          "Привратник-самозванец", "Слизень скверны", "Химера"};
    return school_index >= 0 ? names[school_index] : "Безымянная тварь";
}

std::string join_losses(const std::vector<Stack>& ours, const std::vector<int>& losses) {
    std::string r;
    for (size_t i = 0; i < ours.size(); ++i)
        if (losses[i] > 0 && ours[i].unit >= 0)
            r += std::format("{}{}:{}:{}", r.empty() ? "" : ",", unit_types()[size_t(ours[i].unit)].id, ours[i].elite ? 1 : 0, losses[i]);
    return r;
}

}  // namespace

// ---------------------------------------------------------------------------
// Бой

int power_of(const std::vector<Stack>& stacks) {
    double p = 0;
    for (auto& s : stacks) p += s.count * (s.hp + (s.dmg_min + s.dmg_max) * 1.5 + s.atk * 2 + s.def * 2);
    return int(p);
}

std::string battle_blocker(const Army& army, const Enemy& enemy) {
    if (army.stacks.empty()) return "Нужны войска: наймите их в городе.";
    if (enemy.needs_armor && enemy.faction >= 0 && army.armor[size_t(enemy.faction)] == 0) {
        const FactionInfo& f = faction(enemy.faction);
        return std::format("Без брони против {} не пройти. Броню куют митигации: закройте любую угрозу класса {} "
                           "коммитом с трейлером Threat:.",
                           f.genitive, f.letter);
    }
    if (enemy.shield_school >= 0) {
        int s = enemy.shield_school;
        if (army.spells[size_t(s)] == 0 && army.scrolls[size_t(s)] == 0)
            return std::format("Предводитель защищён чарами: нужна {}. Её открывает уязвимость из ветки «{}» в бестиарии, "
                               "или купите свиток в гильдии магов.",
                               school(s).name, school(s).skill);
    }
    return {};
}

BattleResult simulate(const Army& army, const Enemy& enemy, uint32_t seed) {
    BattleResult r;
    Rng rng(seed);
    r.ours = army.stacks;
    for (auto& s : r.ours) {
        s.atk += army.hero_atk;
        s.def += army.hero_def;
    }
    r.theirs = enemy.stacks;
    if (enemy.shield_school >= 0)
        for (auto& s : r.theirs)
            if (s.icon == "boss") s.shielded = true;

    struct Live {
        int count, top;
    };
    std::vector<Live> live[2];
    for (auto& s : r.ours) live[0].push_back({s.count, s.hp});
    for (auto& s : r.theirs) live[1].push_back({s.count, s.hp});
    std::vector<Stack>* stacks[2] = {&r.ours, &r.theirs};
    std::vector<bool> shielded;
    for (auto& s : r.theirs) shielded.push_back(s.shielded);

    auto alive = [&](int side) {
        for (auto& l : live[side])
            if (l.count > 0) return true;
        return false;
    };
    auto hit = [&](int side, int target, int damage) {
        Live& l = live[side][size_t(target)];
        int hp = (*stacks[side])[size_t(target)].hp;
        int total = (l.count - 1) * hp + l.top - damage;
        int before = l.count;
        if (total <= 0) {
            l.count = 0;
            l.top = 0;
        } else {
            l.count = (total + hp - 1) / hp;
            l.top = total - (l.count - 1) * hp;
        }
        return before - l.count;
    };
    auto pick_target = [&](int side) {  // side — по кому бьём
        std::vector<int> options;
        for (size_t i = 0; i < live[side].size(); ++i)
            if (live[side][i].count > 0 && !(side == 1 && shielded[i])) options.push_back(int(i));
        if (options.empty())
            for (size_t i = 0; i < live[side].size(); ++i)
                if (live[side][i].count > 0) options.push_back(int(i));
        return options.empty() ? -1 : options[size_t(rng.range(0, int(options.size()) - 1))];
    };
    int f = enemy.faction;
    double armor_cut = f >= 0 ? std::min(4, army.armor[size_t(f)]) * 0.15 : 0.0;
    bool demoralized = f >= 0 && army.armor[size_t(f)] == 0;

    // Снятие чар с предводителя — до первого удара.
    if (enemy.shield_school >= 0) {
        int s = enemy.shield_school;
        bool known = army.spells[size_t(s)] > 0, scroll = army.scrolls[size_t(s)] > 0;
        if (known || scroll) {
            if (!known) r.scrolls_used.push_back(s);
            for (size_t i = 0; i < shielded.size(); ++i)
                if (shielded[i]) {
                    shielded[i] = false;
                    r.actions.push_back({BattleAction::ShieldBreak, 0, -1, int(i), 0, 0, s, 0});
                }
        }
    }

    int best_school = -1;
    for (int s = 0; s < kSchools; ++s)
        if (army.spells[size_t(s)] > 0 && (best_school < 0 || army.spells[size_t(s)] > army.spells[size_t(best_school)])) best_school = s;

    for (int round = 1; round <= 25 && alive(0) + alive(1) == 2; ++round) {
        r.rounds = round;
        if (army.towers > 0) {
            int t = pick_target(1);
            if (t >= 0 && !shielded[size_t(t)]) {
                int dmg = 10 * army.towers + rng.range(0, 6 * army.towers);
                r.actions.push_back({BattleAction::Tower, 0, -1, t, dmg, hit(1, t, dmg), -1, round});
            }
        }
        if (best_school >= 0 && alive(1)) {
            int t = pick_target(1);
            if (t >= 0 && !shielded[size_t(t)]) {
                int dmg = 6 * army.hero_power * (1 + army.spells[size_t(best_school)]) + rng.range(0, 8);
                r.actions.push_back({BattleAction::Spell, 0, -1, t, dmg, hit(1, t, dmg), best_school, round});
            }
        }

        struct Turn {
            int side, idx, speed;
        };
        std::vector<Turn> order;
        for (int side = 0; side < 2; ++side)
            for (size_t i = 0; i < live[side].size(); ++i) order.push_back({side, int(i), (*stacks[side])[i].speed});
        std::stable_sort(order.begin(), order.end(), [](const Turn& a, const Turn& b) { return a.speed > b.speed; });

        for (auto& turn : order) {
            if (live[turn.side][size_t(turn.idx)].count <= 0) continue;
            int other = 1 - turn.side;
            if (!alive(other)) break;
            int t = pick_target(other);
            const Stack& a = (*stacks[turn.side])[size_t(turn.idx)];
            const Stack& d = (*stacks[other])[size_t(t)];
            int count = live[turn.side][size_t(turn.idx)].count;
            double dmg = count * rng.range(a.dmg_min, a.dmg_max);
            dmg *= std::clamp(1.0 + 0.05 * (a.atk - d.def), 0.3, 3.0);
            if (turn.side == 1) dmg *= 1.0 - armor_cut;
            if (turn.side == 0 && demoralized) dmg *= 0.5;
            if (other == 1 && shielded[size_t(t)]) dmg = 0;
            int damage = std::max(shielded[size_t(t)] && other == 1 ? 0 : 1, int(std::lround(dmg)));
            r.actions.push_back({a.ranged ? BattleAction::Ranged : BattleAction::Melee, turn.side, turn.idx, t, damage,
                                 hit(other, t, damage), -1, round});
        }
    }

    r.won = alive(0) && !alive(1);
    for (size_t i = 0; i < r.ours.size(); ++i) r.our_losses.push_back(r.ours[i].count - live[0][i].count);
    return r;
}

// ---------------------------------------------------------------------------
// Мир

const Node* World::node(const std::string& id) const {
    for (auto& n : nodes)
        if (n.id == id) return &n;
    return nullptr;
}

int World::army_count(int unit, bool elite) const {
    for (auto& s : army.stacks)
        if (s.unit == unit && s.elite == elite) return s.count;
    return 0;
}

namespace {

std::string side_title(const Config& cfg, const std::string& id) {
    std::string title = cfg.ini.get("side." + id, "title");
    return title.empty() ? id : title;
}

}  // namespace

World build_world(const Config& cfg, const State& st, const EventLog& work, const EventLog& game) {
    World w;
    w.level = level_of(st.total).level;
    const auto& events = work.all();

    // --- Герой: характеристики из навыков работы.
    auto skill = [&](const char* name) { return st.skills.count(name) ? st.skills.at(name) : 0; };
    for (auto& [cwe, n] : st.bestiary) {
        int s = school_of_skill(cwe_skill(cwe));
        if (s >= 0) w.army.spells[size_t(s)] = std::min(5, w.army.spells[size_t(s)] + 1);
    }
    int schools_known = 0;
    for (int s : w.army.spells) schools_known += s > 0;
    w.army.hero_atk = w.level / 2 + (skill("Реализация") + skill("Охота") + skill("Ремесло")) / 120;
    w.army.hero_def = w.level / 2 + (skill("Проектирование") + skill("Интеграция")) / 120;
    w.army.hero_power = 1 + (skill("Обучение") + skill("Наставничество")) / 80 + schools_known / 2;

    // --- Броня: митигации угроз каждого класса STRIDE.
    std::array<int, kFactions> mitigated{}, tested{};
    for (auto& [code, c] : st.campaigns)
        for (auto& [id, t] : c.threats) {
            if (!t.active || t.na) continue;
            for (char l : t.stride) {
                int f = faction_of_letter(l);
                if (f < 0) continue;
                mitigated[size_t(f)] += t.mitigated;
                tested[size_t(f)] += t.mitigated && t.tested;
            }
        }
    for (int f = 0; f < kFactions; ++f)
        w.army.armor[size_t(f)] = mitigated[size_t(f)] ? std::min(3, mitigated[size_t(f)]) + (tested[size_t(f)] ? 1 : 0) : 0;

    // --- Золото от побочных квестов.
    w.gold = w.gold_earned = 100;
    std::map<size_t, int> side_gold;
    for (auto& a : st.awards) {
        const Event& e = events[a.event];
        bool fix = e.type == "quest.done" && st.quests.count(e.get("branch")) && st.quests.at(e.get("branch")).kind == "fix";
        if (e.type == "side" || fix) side_gold[a.event] += a.xp * 3;
    }
    for (auto& [_, g] : side_gold) w.gold += g, w.gold_earned += g;

    // --- Регионы и узлы карты.
    Region capital_region{"capital", "Столица", true, false, {}, 0, 0, 120, 0};
    capital_region.sectors.fill(true);
    w.regions.push_back(capital_region);
    Region frontier{"frontier", "Пограничье", true, false, {}, 0, 300, 150, 7};
    frontier.sectors.fill(true);
    w.regions.push_back(frontier);
    w.nodes.push_back({"capital", Node::Capital, "capital", -1, "Столица", "Ваш город: здесь нанимают и улучшают войска.", false, false, 0, {}, 0, 0});

    std::vector<std::string> codes;
    for (auto& [code, _] : st.campaigns) codes.push_back(code);
    int n = int(codes.size());
    auto place_region = [&](int i, int total, float& x, float& y) {
        double step = 52.0;
        double angle = (-90.0 + (i - (total - 1) / 2.0) * step) * std::numbers::pi / 180.0;
        double radius = 390 + (total > 6 ? 120 * ((i % 2)) : 0);
        x = float(std::cos(angle) * radius);
        y = float(std::sin(angle) * radius);
    };
    for (int i = 0; i < n; ++i) {
        const Campaign& c = st.campaigns.at(codes[size_t(i)]);
        Region r;
        r.id = c.code;
        r.name = c.title.empty() ? "Земли " + c.code : c.title;
        r.campaign = true;
        std::string covered = c.stride_covered();
        for (int f = 0; f < kFactions; ++f) r.sectors[size_t(f)] = covered.find(faction(f).letter) != std::string::npos;
        r.explored = !c.threats.empty();
        place_region(i, n + 1, r.x, r.y);
        r.radius = 210;
        r.color_seed = int(hash(c.code) % 7);
        w.regions.push_back(r);
    }
    Region unknown{"unknown", "Неизведанные земли", false, false, {}, 0, 0, 190, 3};
    place_region(n, n + 1, unknown.x, unknown.y);
    w.regions.push_back(unknown);

    auto region_of = [&](const std::string& id) -> const Region& {
        for (auto& r : w.regions)
            if (r.id == id) return r;
        return w.regions[1];
    };
    auto around = [](float cx, float cy, double angle, double radius, float& x, float& y) {
        x = float(cx + std::cos(angle) * radius);
        y = float(cy + std::sin(angle) * radius);
    };

    // Лагеря: угрозы. Сила растёт с порядковым номером угрозы в кампании.
    for (auto& code : codes) {
        const Campaign& c = st.campaigns.at(code);
        const Region& reg = region_of(code);
        std::map<int, int> per_sector;
        int order = 0;
        for (auto& [id, t] : c.threats) {
            if (!t.active || t.na) continue;
            int f = t.stride.empty() ? int(hash(code + id) % kFactions) : faction_of_letter(t.stride[0]);
            int tier = std::min(4, 1 + order / 2);
            ++order;
            Node node;
            node.id = "camp:" + code + "/" + id;
            node.kind = Node::Camp;
            node.region = code;
            node.sector = f;
            node.enemy = camp_enemy(f, tier, id);
            node.label = std::format("{}: {}", id, faction(f).name);
            node.detail = t.desc;
            double sector_angle = (60.0 * f - 90.0) * std::numbers::pi / 180.0;
            float sx, sy;
            around(reg.x, reg.y, sector_angle, 125, sx, sy);
            int k = per_sector[f]++;
            around(sx, sy, k * 2.3 + 0.6, k ? 34 : 0, node.x, node.y);
            w.nodes.push_back(node);
        }
        // Крепости — точки интеграции.
        int k = 0;
        for (auto& [pid, p] : c.points) {
            Node node;
            node.id = "fort:" + code + "/" + pid;
            node.kind = Node::Fort;
            node.region = code;
            node.stage = p.stage;
            node.label = "Крепость " + pid;
            node.detail = p.title;
            around(reg.x, reg.y, (35.0 + 70.0 * k++) * std::numbers::pi / 180.0, 190, node.x, node.y);
            w.nodes.push_back(node);
        }
    }

    // Логова боссов — ветки задач.
    std::map<std::string, int> lairs_in_region;
    std::vector<const Quest*> quests;
    for (auto& [_, q] : st.quests)
        if (q.work) quests.push_back(&q);
    std::ranges::sort(quests, [](auto* a, auto* b) { return a->started < b->started; });
    for (auto* q : quests) {
        std::string region = st.campaigns.count(q->campaign) ? q->campaign : "frontier";
        const Region& reg = region_of(region);
        Node node;
        node.id = "lair:" + q->branch;
        node.kind = Node::Lair;
        node.region = region;
        node.sealed = !q->done;
        int k = lairs_in_region[region]++;
        around(reg.x, reg.y, k * 2.4 + 1.0, region == "frontier" ? 70 + 30 * (k % 3) : 45 + 12 * (k / 3), node.x, node.y);
        node.label = q->branch;
        w.nodes.push_back(node);
    }

    // Монстры — находки.
    for (auto& e : events) {
        if (e.type != "finding") continue;
        int cwe = std::atoi(e.get("cwe").c_str());
        int s = school_of_skill(cwe_skill(cwe));
        std::string sev = e.get("sev");
        int tier = sev == "critical" ? 4 : sev == "high" ? 3 : sev == "medium" ? 2 : 1;
        std::string region = st.campaigns.count(e.get("campaign")) ? e.get("campaign") : "frontier";
        const Region& reg = region_of(region);
        Node node;
        node.id = "monster:" + e.get("id");
        node.kind = Node::Monster;
        node.region = region;
        std::string name = monster_name(s);
        node.label = std::format("{} ({})", name, e.get("id"));
        auto* info = find_cwe(cwe);
        node.detail = std::format("CWE-{}{}", cwe, info ? std::string(" ") + info->name : "");
        node.enemy.name = name;
        node.enemy.title = node.detail;
        node.enemy.tier = tier;
        node.enemy.stacks.push_back(beast_stack(name, tier, 2 + 2 * tier));
        node.enemy.reward = 30 * tier;
        uint32_t h = hash(node.id);
        around(reg.x, reg.y, (h % 628) / 100.0, 70 + (h >> 10) % 90, node.x, node.y);
        w.nodes.push_back(node);
    }

    // --- Игровой журнал: найм, улучшения, свитки, бои, набеги.
    std::map<std::pair<int, bool>, int> army;
    std::set<std::string> cleared;
    std::string start_time;
    auto apply_losses = [&](const std::string& losses) {
        for (auto& item : split(losses, ',')) {
            auto parts = split(item, ':');
            if (parts.size() != 3) continue;
            int u = unit_index(parts[0]);
            if (u < 0) continue;
            int& cnt = army[{u, parts[1] == "1"}];
            cnt = std::max(0, cnt - std::atoi(parts[2].c_str()));
        }
    };
    for (auto& e : game.all()) {
        const std::string& t = e.type;
        int cost = std::atoi(e.get("cost").c_str());
        if (t == "start") {
            w.started = true;
            start_time = e.time;
        } else if (t == "hire") {
            int u = unit_index(e.get("unit"));
            if (u >= 0) army[{u, false}] += std::atoi(e.get("count").c_str());
            w.gold -= cost;
        } else if (t == "upgrade") {
            int u = unit_index(e.get("unit"));
            int cnt = std::atoi(e.get("count").c_str());
            if (u >= 0) {
                cnt = std::min(cnt, army[{u, false}]);
                army[{u, false}] -= cnt;
                army[{u, true}] += cnt;
            }
            w.gold -= cost;
        } else if (t == "scroll") {
            int s = std::atoi(e.get("school").c_str());
            if (s >= 0 && s < kSchools) w.army.scrolls[size_t(s)]++;
            w.gold -= cost;
        } else if (t == "battle" || t == "raid") {
            apply_losses(e.get("losses"));
            for (auto& s : split(e.get("scrolls"), ','))
                if (!s.empty()) {
                    int idx = std::atoi(s.c_str());
                    if (idx >= 0 && idx < kSchools) w.army.scrolls[size_t(idx)] = std::max(0, w.army.scrolls[size_t(idx)] - 1);
                }
            int delta = std::atoi(e.get("gold").c_str());
            w.gold += delta;
            if (delta > 0) w.gold_earned += delta;
            if (t == "battle" && e.get("won") == "1") {
                cleared.insert(e.get("node"));
                if (starts_with(e.get("node"), "lair:")) w.bosses_defeated++;
            }
        }
    }
    for (auto& [key, cnt] : army)
        if (cnt > 0) w.army.stacks.push_back(player_stack(key.first, key.second, cnt));

    // Боссы: сила растёт с каждым побеждённым, чтобы противники оставались достойными.
    int boss_index = 0;
    for (auto& node : w.nodes) {
        node.cleared = cleared.count(node.id) != 0;
        if (node.kind != Node::Lair) continue;
        std::string branch = node.id.substr(5);
        const Quest& q = st.quests.at(branch);
        static const std::map<std::string, int> base = {{"fix", 1}, {"review", 2}, {"impl", 3}, {"integ", 3}};
        int tier = (base.count(q.kind) ? base.at(q.kind) : 1) + boss_index++ / 3;
        tier = std::min(tier, 7);
        Enemy& e = node.enemy;
        e.tier = tier;
        int f = -1;
        if (st.campaigns.count(q.campaign)) {
            std::array<int, kFactions> counts{};
            for (auto& [_, t] : st.campaigns.at(q.campaign).threats)
                if (t.active && !t.na && !t.stride.empty() && faction_of_letter(t.stride[0]) >= 0) counts[size_t(faction_of_letter(t.stride[0]))]++;
            int best = int(std::max_element(counts.begin(), counts.end()) - counts.begin());
            f = counts[size_t(best)] ? best : int(hash(branch) % kFactions);
        } else if (q.kind == "review") {
            f = int(hash(branch) % kFactions);
        }
        e.faction = f;
        e.needs_armor = f >= 0;
        std::string boss_name = f >= 0 ? faction(f).boss : (q.kind == "fix" ? "Багоед" : "Бродячий тролль");
        e.name = boss_name;
        e.title = "Логово «" + branch + "»";
        e.stacks.push_back(boss_stack(boss_name, tier));
        if (f >= 0) e.stacks.push_back(faction_stack(f, std::max(1, tier - 1), false, 4 + 3 * tier));
        else e.stacks.push_back(beast_stack(q.kind == "fix" ? "Мелкий баг" : "Гоблин", std::max(1, tier - 1), 4 + 3 * tier));
        if (q.kind == "impl" || q.kind == "integ") e.shield_school = int(hash(branch + "#") % kSchools);
        e.reward = 80 * tier;
        node.detail = node.sealed ? "Босс неуязвим, пока задача не сдана: влейте ветку в main." : "Задача сдана — логово открыто!";
    }

    // --- Набеги: каждую неделю лагерь угрозы без митигации нападает на земли кампании.
    if (w.started) {
        Date now = today();
        std::string this_week = week_start(now);
        std::string prev_week = week_start(add_days(now, -7));
        std::string start_week = week_start(parse_date(start_time));
        for (auto& code : codes) {
            const Campaign& c = st.campaigns.at(code);
            int order = 0;
            for (auto& [id, t] : c.threats) {
                if (!t.active || t.na) continue;
                int tier = std::min(4, 1 + order++ / 2);
                if (t.mitigated || cleared.count("camp:" + code + "/" + id)) continue;
                std::string added;
                for (auto& e : events)
                    if (e.type == "threat.add" && e.get("campaign") == code && e.get("id") == id) added = e.time;
                std::string first_week = week_start(add_days(parse_date(added), 7));
                for (const std::string& wk : {prev_week, this_week}) {
                    if (wk <= start_week || wk < first_week || wk > this_week) continue;
                    std::string key = "raid:" + code + "/" + id + ":" + wk;
                    if (game.has_key(key)) continue;
                    int f = t.stride.empty() ? int(hash(code + id) % kFactions) : faction_of_letter(t.stride[0]);
                    Raid raid{key, code, id, camp_enemy(f, tier, id, 0.7)};
                    raid.enemy.name = std::format("Набег {} ({})", faction(f).genitive, id);
                    raid.enemy.needs_armor = false;
                    w.raids.push_back(raid);
                }
            }
        }
        if (w.raids.size() > 3) w.raids.resize(3);
    }

    // --- Летопись: события работы и игры, рассказанные языком похода.
    struct Item {
        std::string time;
        Chronicle c;
    };
    std::vector<Item> items;
    auto add = [&](const std::string& time, std::string text, Chronicle::Tone tone) { items.push_back({time, {time, std::move(text), tone}}); };
    std::string first = events.empty() ? now_iso() : events.front().time;
    add(first.substr(0, 10) + "T00:00:00",
        "Пролог. Королевство платформы живёт спокойно, но на его рубежах собираются шесть враждебных фракций. "
        "Герою предстоит разведать земли, выковать защиту и отбить набеги.",
        Chronicle::Chapter);
    std::set<std::string> chapters;
    int chapter_no = 0;
    auto chapter = [&](const std::string& time, const std::string& code) {
        if (code.empty() || !st.campaigns.count(code) || !chapters.insert(code).second) return;
        const Campaign& c = st.campaigns.at(code);
        add(time, std::format("Глава {}. {}{}", ++chapter_no, c.title.empty() ? "Земли " + code : c.title, " — " + code), Chronicle::Chapter);
    };
    std::map<size_t, int> xp_of;
    for (auto& a : st.awards) xp_of[a.event] += a.xp;
    for (size_t i = 0; i < events.size(); ++i) {
        const Event& e = events[i];
        const std::string& t = e.type;
        std::string code = e.get("campaign");
        if (t == "threat.add") {
            chapter(e.time, code);
            int f = e.get("stride").empty() ? -1 : faction_of_letter(e.get("stride")[0]);
            if (e.get("na") == "1") add(e.time, std::format("Летописцы сочли слух {} пустым: угроза неприменима.", e.get("id")), Chronicle::Story);
            else add(e.time, std::format("Разведчики донесли: в землях {} встали лагерем {} ({}: «{}»).", code,
                                         f >= 0 ? faction(f).name : "неведомые враги", e.get("id"), e.get("desc")),
                     Chronicle::Bad);
        } else if (t == "link") {
            std::string kind = e.get("kind"), target = e.get("target");
            if (kind == "threat") add(e.time, std::format("Кузнецы выковали защиту от угрозы {}.", target), Chronicle::Good);
            else if (kind == "threat-test") add(e.time, std::format("Защита от {} выдержала испытание огнём.", target), Chronicle::Good);
            else if (kind == "integration") add(e.time, std::format("Построена крепость {}.", target), Chronicle::Good);
            else add(e.time, std::format("Крепость {} укреплена и прошла смотр.", target), Chronicle::Good);
        } else if (t == "quest.work") {
            std::string branch = e.get("branch");
            if (st.quests.count(branch)) chapter(e.time, st.quests.at(branch).campaign);
            add(e.time, std::format("В глубине земель проснулось чудовище: логово «{}».", branch), Chronicle::Bad);
        } else if (t == "quest.done") {
            add(e.time, std::format("Задача «{}» сдана — чары логова пали, босс уязвим!", e.get("branch")), Chronicle::Good);
        } else if (t == "finding") {
            int cwe = std::atoi(e.get("cwe").c_str());
            auto* info = find_cwe(cwe);
            add(e.time, std::format("Герой выследил {} — CWE-{}{}.", monster_name(school_of_skill(cwe_skill(cwe))), cwe,
                                    info ? std::string(" «") + info->name + "»" : ""),
                Chronicle::Good);
        } else if (t == "side" && xp_of.count(i)) {
            std::string title = e.get("id") == "adhoc" ? e.get("title") : side_title(cfg, e.get("id"));
            add(e.time, std::format("Казна пополнилась на {} золота: {}.", side_gold.count(i) ? side_gold.at(i) : 0, title), Chronicle::Gold);
        } else if (t == "point.plan") {
            add(e.time, std::format("Зодчие заложили крепость {}/{}.", code, e.get("point")), Chronicle::Story);
        }
    }
    for (auto& e : game.all()) {
        const std::string& t = e.type;
        if (t == "start") add(e.time, "Герой поднял знамя и выступил в поход.", Chronicle::Chapter);
        else if (t == "hire") {
            int u = unit_index(e.get("unit"));
            if (u >= 0) add(e.time, std::format("Под знамёна встали новые бойцы: {} × {}.", unit_types()[size_t(u)].name, e.get("count")), Chronicle::Story);
        } else if (t == "upgrade") {
            int u = unit_index(e.get("unit"));
            if (u >= 0) add(e.time, std::format("{} × {} прошли обучение: теперь это {}.", unit_types()[size_t(u)].name, e.get("count"), unit_types()[size_t(u)].elite_name), Chronicle::Story);
        } else if (t == "scroll") {
            add(e.time, std::format("В гильдии магов куплен свиток: {}.", school(std::atoi(e.get("school").c_str())).name), Chronicle::Story);
        } else if (t == "battle") {
            bool won = e.get("won") == "1";
            add(e.time, won ? std::format("Победа: {} повержен. Добыча — {} золота.", e.get("enemy"), e.get("gold"))
                            : std::format("Отступление: {} оказался сильнее. Войска потрёпаны.", e.get("enemy")),
                won ? Chronicle::Gold : Chronicle::Bad);
        } else if (t == "raid") {
            bool won = e.get("won") == "1";
            add(e.time, won ? std::format("{} отбит у стен земель {}.", e.get("enemy"), e.get("region"))
                            : std::format("{} прорвался в земли {}: разграблено {} золота.", e.get("enemy"), e.get("region"), -std::atoi(e.get("gold").c_str())),
                won ? Chronicle::Good : Chronicle::Bad);
        }
    }
    std::stable_sort(items.begin(), items.end(), [](const Item& a, const Item& b) { return a.time < b.time; });
    for (auto& it : items) w.chronicle.push_back(it.c);
    return w;
}

// ---------------------------------------------------------------------------
// Действия

std::string start_game(EventLog& game) {
    if (game.has_key("start")) return {};
    Event e;
    e.type = "start";
    e.set("key", "start");
    return game.append(std::move(e)) ? "" : "Не удалось записать игровой журнал";
}

std::string hire(const World& w, EventLog& game, int unit, int count) {
    if (unit < 0 || unit >= int(unit_types().size()) || count <= 0) return "Неверный отряд";
    const UnitType& u = unit_types()[size_t(unit)];
    if (w.level < u.level_req) return std::format("{} доступны с {} уровня героя", u.name, u.level_req);
    int cost = u.cost * count;
    if (cost > w.gold) return std::format("Не хватает золота: нужно {}, в казне {}", cost, w.gold);
    Event e;
    e.type = "hire";
    e.set("unit", u.id).set("count", std::to_string(count)).set("cost", std::to_string(cost));
    return game.append(std::move(e)) ? "" : "Не удалось записать игровой журнал";
}

std::string upgrade(const World& w, EventLog& game, int unit, int count) {
    if (unit < 0 || unit >= int(unit_types().size()) || count <= 0) return "Неверный отряд";
    if (w.army_count(unit, false) < count) return "Столько бойцов нет в строю";
    int cost = upgrade_cost(unit) * count;
    if (cost > w.gold) return std::format("Не хватает золота: нужно {}, в казне {}", cost, w.gold);
    Event e;
    e.type = "upgrade";
    e.set("unit", unit_types()[size_t(unit)].id).set("count", std::to_string(count)).set("cost", std::to_string(cost));
    return game.append(std::move(e)) ? "" : "Не удалось записать игровой журнал";
}

std::string buy_scroll(const World& w, EventLog& game, int s) {
    if (s < 0 || s >= kSchools) return "Неверная школа";
    if (w.gold < kScrollCost) return std::format("Свиток стоит {} золота, в казне {}", kScrollCost, w.gold);
    Event e;
    e.type = "scroll";
    e.set("school", std::to_string(s)).set("cost", std::to_string(kScrollCost));
    return game.append(std::move(e)) ? "" : "Не удалось записать игровой журнал";
}

BattleResult fight(const World& w, EventLog& game, const std::string& node_id) {
    const Node* node = w.node(node_id);
    if (!node || node->cleared || node->sealed || !battle_blocker(w.army, node->enemy).empty()) return {};
    BattleResult r = simulate(w.army, node->enemy, hash(node_id) ^ uint32_t(game.all().size() * 7919));
    Event e;
    e.type = "battle";
    e.set("node", node_id).set("enemy", node->enemy.name).set("won", r.won ? "1" : "0");
    e.set("gold", std::to_string(r.won ? node->enemy.reward : 0));
    e.set("losses", join_losses(r.ours, r.our_losses));
    std::string scrolls;
    for (int s : r.scrolls_used) scrolls += (scrolls.empty() ? "" : ",") + std::to_string(s);
    e.set("scrolls", scrolls);
    game.append(std::move(e));
    return r;
}

BattleResult defend(const World& w, EventLog& game, const Raid& raid) {
    Army army = w.army;
    for (auto& n : w.nodes)
        if (n.kind == Node::Fort && n.region == raid.region) army.towers += n.stage;
    BattleResult r = simulate(army, raid.enemy, hash(raid.key));
    int delta = r.won ? 25 : -std::min(150, std::max(0, w.gold) * 15 / 100);
    Event e;
    e.type = "raid";
    e.set("key", raid.key).set("enemy", raid.enemy.name).set("region", raid.region).set("won", r.won ? "1" : "0");
    e.set("gold", std::to_string(delta)).set("losses", join_losses(r.ours, r.our_losses));
    game.append(std::move(e));
    return r;
}

}  // namespace sq::quest
