#pragma once

// Состояние окна: данные игры, фоновая синхронизация, всплывающие уведомления,
// страницы и диалоги. Хост (main_gui.cpp) отвечает за окно, DirectX и трей.

#include "actions.h"
#include "config.h"
#include "events.h"
#include "game.h"
#include "quest.h"

#include "imgui.h"

#include <windows.h>

#include <atomic>
#include <chrono>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

namespace sq::gui {

enum class Page { Overview, Game, Quests, Campaigns, Bestiary, Journal, Settings };

struct Toast {
    std::string title, text;
    ImU32 color;
    double born;
};

// Подсказка «что дальше» на сводке: текст и действие по кнопке.
struct Hint {
    enum class Kind { Info, Copy, Side, Lesson, AddCampaign, Settings, OpenDoc, Sync };
    Kind kind;
    const char* icon;
    ImU32 color;
    std::string text, payload, button;
};

class App {
public:
    explicit App(HWND hwnd);
    ~App();

    void frame();
    void tick();                 // таймеры и завершение синхронизации; вызывается каждый кадр
    void request_sync();
    bool busy() const;           // идёт анимация или синхронизация: кадры нужны чаще
    int frame_cap_ms() const;    // пауза между кадрами для спокойных анимаций; 0 — без ограничения

    Page page = Page::Overview;
    bool window_visible = true;
    std::function<void(const std::string&, const std::string&)> notify;  // всплывашка в трее
    std::function<void()> quit;

    int level() const;
    std::string tray_tip() const;
    bool close_to_tray() const;
    void open_dialog(const std::string& name);  // finding | campaign | point

private:
    double clock() const;  // секунды с запуска; идёт и тогда, когда окно скрыто в трее

    // данные
    void load();
    void refresh_state();
    void after_change(size_t first_event, int total_before);
    bool guard_busy();
    void act(const std::function<ActionResult()>& action);  // запись с уведомлениями о наградах

    // каркас
    void draw_sidebar();
    void draw_header();
    void draw_toasts();
    void toast(std::string title, std::string text, ImU32 color);

    // страницы (pages.cpp)
    void page_welcome();
    void page_overview();
    void page_quests();
    void page_campaigns();
    void page_bestiary();
    void page_journal();
    void page_settings();
    std::vector<Hint> hints() const;
    void run_hint(const Hint& h);

    // поход (game_view.cpp)
    void page_game();
    void game_intro();
    void game_map();
    void game_panel();
    void game_town();
    void game_chronicle();
    void game_battle();
    void watch_battle(quest::BattleResult result, std::string title, int reward, bool raid);
    void run_raid();
    void game_act(const std::function<std::string()>& action, const std::string& done);

    // диалоги (pages.cpp)
    void dialog_finding();
    void dialog_campaign();
    void dialog_point();
    void dialog_lesson();
    int estimate_finding_xp() const;

    HWND hwnd_;
    Config cfg_;
    std::unique_ptr<EventLog> log_;
    State st_;
    bool configured_ = false;
    fs::file_time_type log_mtime_{};
    double next_file_check_ = 0;

    // синхронизация в фоне
    std::thread worker_;
    std::atomic<bool> syncing_{false};
    std::atomic<bool> sync_finished_{false};
    mutable std::mutex sync_mu_;
    std::chrono::steady_clock::time_point started_ = std::chrono::steady_clock::now();
    std::vector<std::string> sync_report_;
    std::string last_sync_label_ = "ещё не было";
    double next_auto_sync_ = 0;
    size_t sync_first_event_ = 0;
    int sync_total_before_ = 0;

    std::vector<Toast> toasts_;

    // поход
    std::unique_ptr<EventLog> game_log_;
    quest::World world_;
    int game_tab_ = 0;  // 0 карта, 1 город, 2 летопись
    ImVec2 map_pan_{0, 0};
    float map_zoom_ = 0;  // 0 — подобрать по размеру
    std::string selected_node_;
    std::map<int, int> hire_counts_;
    bool chronicle_scroll_ = true;
    double next_raid_ = 5.0;
    struct BattleView {
        bool active = false;
        quest::BattleResult result;
        std::string title;
        int reward = 0;
        bool raid = false;
        float progress = 0;  // в «ходах»; отрицательное — вступление
        float speed = 1;
    } battle_;
    struct Replay {
        quest::BattleResult result;
        std::string title;
        int reward;
        bool raid;
    };
    std::vector<Replay> replays_;

    // формы
    struct {
        bool open = false;
        int cwe_index = -1;
        std::string cwe_text, note, lesson, filter;
        int severity = 2, stage = 3, campaign = 0, threat = 0;  // по умолчанию — ревью платформы
    } finding_;
    struct {
        bool open = false;
        std::string code, title, doc, error;
    } campaign_form_;
    struct {
        bool open = false;
        int campaign = 0;
        std::string name, title, error;
    } point_form_;
    struct {
        bool open = false;
        std::string id, text;
    } lesson_form_;
    std::map<std::string, std::string> side_notes_;
    std::string adhoc_text_;
    std::string selected_campaign_;
    std::string journal_filter_;
    std::string welcome_repo_, settings_repo_, settings_main_;
    int settings_sync_minutes_ = 10;
    std::string confirm_close_branch_;
};

}  // namespace sq::gui
