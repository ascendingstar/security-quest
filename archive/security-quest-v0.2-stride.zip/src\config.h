#pragma once

#include "ini.h"
#include "platform.h"

#include <string>

namespace sq {

struct Config {
    fs::path home;  // каталог данных: config.ini и events.log
    Ini ini;

    fs::path config_file() const { return home / "config.ini"; }
    fs::path events_file() const { return home / "events.log"; }
    double xp(const std::string& key, double def) const { return ini.num("xp", key, def); }
};

// SQ_HOME, иначе папка data рядом с exe, иначе %LOCALAPPDATA%\SecurityQuest.
fs::path data_home();

extern const char* const kDefaultConfig;

// Меняет или добавляет «key = value» в секции, сохраняя остальной файл и комментарии.
bool set_ini_value(const fs::path& file, const std::string& section, const std::string& key,
                   const std::string& value);
bool append_text(const fs::path& file, const std::string& text);

}  // namespace sq
