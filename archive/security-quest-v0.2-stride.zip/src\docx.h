#pragma once

// Чтение таблицы угроз из дизайн-документа Word, только на чтение.
// Строка таблицы считается угрозой, если в первой ячейке стоит ID вида T-03.
// Колонки: ID | описание | класс STRIDE (буквы S T R I D E, английские или русские названия).
// Строка с «неприменимо» или N/A засчитывается в покрытие STRIDE, но не открывает квест.

#include "platform.h"

#include <optional>
#include <string>
#include <vector>

namespace sq {

struct ThreatRow {
    std::string id;
    std::string desc;
    std::string stride;  // буквы из STRIDE в каноническом порядке, например "TI"
    bool na = false;
};

std::optional<std::vector<ThreatRow>> read_threats(const fs::path& docx, std::string& err);

// Разбор уже извлечённого word/document.xml; вынесено отдельно для проверок.
std::vector<ThreatRow> parse_threat_tables(const std::string& document_xml);
std::string parse_stride(const std::string& cell);

}  // namespace sq
