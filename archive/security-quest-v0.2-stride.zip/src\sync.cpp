#include "sync.h"

#include "docx.h"
#include "game.h"
#include "util.h"

#include <cctype>
#include <cstdlib>
#include <set>

namespace sq {

namespace {

std::string truncate_utf8(const std::string& s, size_t max_bytes) {
    if (s.size() <= max_bytes) return s;
    size_t n = max_bytes;
    while (n > 0 && (static_cast<unsigned char>(s[n]) & 0xC0) == 0x80) --n;
    return s.substr(0, n) + "…";
}

std::string plural(int n, const char* one, const char* few, const char* many) {
    int m10 = n % 10, m100 = n % 100;
    if (m10 == 1 && m100 != 11) return std::to_string(n) + " " + one;
    if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return std::to_string(n) + " " + few;
    return std::to_string(n) + " " + many;
}

class Git {
public:
    Git(fs::path exe, std::string repo) : exe_(std::move(exe)), repo_(std::move(repo)) {}

    ProcResult operator()(std::vector<std::string> args) const {
        args.insert(args.begin(), {"-C", repo_});
        return run(exe_, args);
    }

private:
    fs::path exe_;
    std::string repo_;
};

}  // namespace

BranchInfo classify_branch(const std::string& branch) {
    static const std::set<std::string> kinds = {"impl", "integ", "fix", "review"};
    auto parts = split(branch, '/');
    BranchInfo info{"other", ""};
    if (parts.size() >= 2 && kinds.count(parts[0])) {
        info.kind = parts[0];
        if (parts.size() >= 3) info.campaign = upper_ascii(parts[1]);
    }
    return info;
}

void sync_documents(const Config& cfg, EventLog& log, std::vector<std::string>& report) {
    State st = replay(cfg, log);
    for (auto& sec : cfg.ini.sections("campaign.")) {
        std::string code = sec.substr(9);
        std::string doc = cfg.ini.get(sec, "doc");
        if (doc.empty()) continue;

        std::string err;
        auto rows = read_threats(to_path(doc), err);
        if (!rows) {
            report.push_back(code + ": " + err);
            continue;
        }

        Campaign& c = st.campaigns[code];
        std::set<std::string> seen;
        int added = 0, changed = 0, dropped = 0;
        for (auto& row : *rows) {
            if (!seen.insert(row.id).second) {
                report.push_back(code + ": угроза " + row.id + " встречается в документе дважды, учтена первая");
                continue;
            }
            Event e;
            e.set("campaign", code).set("id", row.id).set("desc", truncate_utf8(row.desc, 300));
            e.set("stride", row.stride).set("na", row.na ? "1" : "0");

            auto it = c.threats.find(row.id);
            if (it == c.threats.end()) {
                e.type = "threat.add";
                e.set("key", "threat:" + code + "/" + row.id);
                ++added;
            } else if (!it->second.active) {
                e.type = "threat.restore";
                ++changed;
            } else if (it->second.stride != row.stride || it->second.na != row.na ||
                       it->second.desc != e.get("desc")) {
                e.type = "threat.update";
                ++changed;
            } else {
                continue;
            }
            log.append(std::move(e));
        }
        for (auto& [id, t] : c.threats) {
            if (!t.active || seen.count(id)) continue;
            Event e;
            e.type = "threat.drop";
            e.set("campaign", code).set("id", id);
            log.append(std::move(e));
            ++dropped;
        }
        report.push_back(code + ": в документе " + plural(int(rows->size()), "угроза", "угрозы", "угроз") +
                         "; новых " + std::to_string(added) + ", изменено " + std::to_string(changed) +
                         ", убрано " + std::to_string(dropped));
    }
}

void sync_git(const Config& cfg, EventLog& log, std::vector<std::string>& report) {
    std::string repo = cfg.ini.get("repo", "path");
    if (repo.empty()) {
        report.push_back("git: репозиторий не задан (sq init --repo <путь>)");
        return;
    }
    std::string git_setting = cfg.ini.get("repo", "git");
    auto exe = git_setting.empty() ? find_in_path("git.exe") : std::optional<fs::path>(to_path(git_setting));
    if (!exe) {
        report.push_back("git: git.exe не найден в PATH, укажите путь в [repo] git = …");
        return;
    }
    Git git(*exe, repo);
    std::string main = cfg.ini.get("repo", "main", "main");
    if (git({"rev-parse", "--verify", "--quiet", "refs/heads/" + main}).code != 0) {
        report.push_back("git: в " + repo + " нет ветки " + main);
        return;
    }

    State st = replay(cfg, log);
    int started = 0, finished = 0, links = 0;

    auto finish = [&](const std::string& branch, const char* how) {
        Event e;
        e.type = "quest.done";
        e.set("key", "done:" + branch).set("branch", branch).set("how", how);
        log.append(std::move(e));
        ++finished;
    };

    std::set<std::string> existing;
    auto refs = git({"for-each-ref", "--format=%(refname:short)%1f%(objectname)", "refs/heads"});
    for (auto& line : split(refs.out, '\n')) {
        auto parts = split(trim(line), '\x1f');
        if (parts.size() != 2 || parts[0] == main) continue;
        const std::string& branch = parts[0];
        const std::string& tip = parts[1];
        existing.insert(branch);

        if (!st.quests.count(branch)) {
            BranchInfo info = classify_branch(branch);
            Event e;
            e.type = "quest.start";
            e.set("key", "quest:" + branch).set("branch", branch).set("kind", info.kind);
            e.set("campaign", info.campaign).set("tip", tip);
            log.append(std::move(e));
            ++started;
        }

        Quest q = st.quests.count(branch) ? st.quests[branch] : Quest{};
        if (q.done) continue;
        if (!q.work) {
            // Ветка без собственных коммитов ещё не квест в работе, а просто указатель на main.
            // Если её успели влить между синхронизациями, коммитов впереди main уже нет,
            // но reflog ветки помнит что-то кроме создания.
            auto ahead = git({"rev-list", "--count", main + ".." + branch});
            auto reflog = git({"reflog", "show", "--format=%H", "refs/heads/" + branch});
            bool ahead_of_main = std::atoi(trim(ahead.out).c_str()) > 0;
            bool has_history = split(trim(reflog.out), '\n').size() > 1;
            if (!ahead_of_main && !has_history) continue;
            Event e;
            e.type = "quest.work";
            e.set("key", "work:" + branch).set("branch", branch).set("tip", tip);
            log.append(std::move(e));
        }

        if (git({"merge-base", "--is-ancestor", branch, main}).code == 0) {
            finish(branch, "merged");
            continue;
        }
        // Rebase или cherry-pick: все коммиты ветки уже есть в main как эквивалентные патчи.
        auto cherry = git({"cherry", main, branch});
        auto lines = split(trim(cherry.out), '\n');
        bool all_upstream = cherry.code == 0 && !trim(cherry.out).empty();
        for (auto& l : lines) all_upstream &= starts_with(trim(l), "-");
        if (all_upstream) finish(branch, "rebased");
    }

    for (auto& [branch, q] : st.quests) {
        if (q.done || !q.work || existing.count(branch)) continue;
        if (!q.tip.empty() && git({"merge-base", "--is-ancestor", q.tip, main}).code == 0) {
            finish(branch, "merged");
        } else {
            report.push_back("git: ветка " + branch +
                             " удалена, но её коммитов нет в main. Если она влита через squash: sq done " + branch);
        }
    }

    // Трейлеры коммитов в main связывают код с угрозами и точками интеграции.
    static const std::set<std::string> kinds = {"threat", "threat-test", "integration", "integration-test"};
    auto history = git({"log", main, "--format=%H%x1f%cI%x1f%(trailers:only,unfold)%x1e"});
    for (auto& record : split(history.out, '\x1e')) {
        auto parts = split(trim(record), '\x1f');
        if (parts.size() < 3) continue;
        const std::string& sha = parts[0];
        for (auto& trailer : split(parts[2], '\n')) {
            auto colon = trailer.find(':');
            if (colon == std::string::npos) continue;
            std::string kind = trim(trailer.substr(0, colon));
            for (auto& c : kind) c = char(std::tolower(static_cast<unsigned char>(c)));
            if (!kinds.count(kind)) continue;
            for (auto& raw : split(trailer.substr(colon + 1), ',')) {
                std::string target = trim(raw);
                if (target.find('/') == std::string::npos) continue;
                std::string key = "link:" + sha + ":" + kind + ":" + target;
                if (log.has_key(key)) continue;
                Event e;
                e.type = "link";
                e.set("key", key).set("kind", kind).set("target", target);
                e.set("sha", sha.substr(0, 12)).set("commit_time", parts[1]);
                log.append(std::move(e));
                ++links;
            }
        }
    }

    report.push_back("git: новых квестов " + std::to_string(started) + ", выполнено " + std::to_string(finished) +
                     ", новых связей из трейлеров " + std::to_string(links));
}

}  // namespace sq
