#include "actions.h"
#include "config.h"
#include "cwe.h"
#include "events.h"
#include "game.h"
#include "platform.h"
#include "quest.h"
#include "sync.h"
#include "util.h"

#include <algorithm>
#include <cstdlib>
#include <map>
#include <print>
#include <set>

using namespace sq;

namespace {

constexpr const char* kHelp = R"(Security Quest — геймификация работы над механизмами безопасности.

  sq                         сводка: уровень, кампании, квесты, контракты
  sq init [--repo P] [--main B]
                             создать настройки (или поменять репозиторий)
  sq sync                    прочитать дизайн-документы и git, записать новые события

  sq side                    доска побочных квестов
  sq side done <id> [заметка]
  sq side done "свой текст"  разовый побочный квест

  sq find <CWE-N> <low|medium|high|critical> [описание]
         [--stage design|impl|integ|patrol] [--campaign КОД] [--threat КОД/T-NN] [--lesson "урок"]
                             записать находку
  sq lesson <F-id> "урок"    урок к находке-слепому пятну

  sq campaign add <КОД> <путь к docx> [название]
  sq campaign                список кампаний
  sq point add <КОД> <точка> [название]
                             запланировать точку интеграции
  sq threats [КОД]           угрозы и их статус
  sq done <ветка>            закрыть квест вручную (например, после squash)
  sq bestiary                бестиарий CWE
  sq log [N]                 последние события и очки
  sq game [start | hire <отряд> <n> | upgrade <отряд> <n> | scroll <школа> | fight <узел> | raids]
                             поход: армия, карта, бои

Связь коммитов с угрозами и интеграцией — трейлеры в сообщении коммита в main:
  Threat: AUTHZ/T-03          Threat-Test: AUTHZ/T-03
  Integration: AUTHZ/ipc      Integration-Test: AUTHZ/ipc

Данные: папка data рядом с программой, если она есть (портативный режим),
иначе %LOCALAPPDATA%\SecurityQuest. Переопределяется переменной SQ_HOME.)";

struct Args {
    std::vector<std::string> pos;
    std::map<std::string, std::string> opt;

    std::string rest(size_t from) const {
        std::string r;
        for (size_t i = from; i < pos.size(); ++i) r += (r.empty() ? "" : " ") + pos[i];
        return r;
    }
};

Args parse_args(const std::vector<std::string>& argv, size_t from) {
    Args a;
    for (size_t i = from; i < argv.size(); ++i) {
        if (starts_with(argv[i], "--") && argv[i].size() > 2) {
            std::string name = argv[i].substr(2);
            if (i + 1 < argv.size() && !starts_with(argv[i + 1], "--")) a.opt[name] = argv[++i];
            else a.opt[name] = "1";
        } else {
            a.pos.push_back(argv[i]);
        }
    }
    return a;
}

std::string skill_line(const State& st, size_t limit) {
    std::vector<std::pair<std::string, int>> skills(st.skills.begin(), st.skills.end());
    std::ranges::sort(skills, [](auto& a, auto& b) { return a.second > b.second; });
    std::string r;
    for (size_t i = 0; i < skills.size() && i < limit; ++i)
        r += (r.empty() ? "" : " · ") + skills[i].first + " " + std::to_string(skills[i].second);
    return r;
}

// Печатает награды за только что записанное событие и сообщает о новом уровне.
void report_new_event(const Config& cfg, const EventLog& log, int total_before) {
    State st = replay(cfg, log);
    size_t last = log.all().size() - 1;
    bool any = false;
    for (auto& a : st.awards)
        if (a.event == last) {
            std::println("  +{} XP  {}  [{}]", a.xp, a.reason, a.skill);
            any = true;
        }
    if (!any) std::println("  Записано. Очков за это не начислено (лимит или повтор).");
    int before = level_of(total_before).level, after = level_of(st.total).level;
    if (after > before) std::println("\n  ★ Новый уровень: {}!", after);
}

// ---------------------------------------------------------------------------

int fail(const ActionResult& r) {
    std::println(stderr, "{}", r.message);
    return 1;
}

int cmd_init(Config& cfg, const Args& a) {
    std::error_code ec;
    bool existed = fs::exists(cfg.config_file(), ec);
    auto r = init_config(cfg, a.opt.count("repo") ? a.opt.at("repo") : "", a.opt.count("main") ? a.opt.at("main") : "");
    if (!r.ok) return fail(r);

    std::println("{} {}", existed ? "Настройки:" : "Созданы настройки:", from_path(cfg.config_file()));
    std::println("Журнал событий: {}", from_path(cfg.events_file()));
    if (!existed)
        std::println("\nДальше: sq init --repo <путь к репозиторию>, sq campaign add <КОД> <docx>, sq sync");
    return 0;
}

int cmd_status(const Config& cfg, const EventLog& log) {
    State st = replay(cfg, log);
    Date now = today();
    Level lv = level_of(st.total);
    int week = st.weeks.count(week_start(now)) ? st.weeks.at(week_start(now)) : 0;

    std::println("Security Quest · уровень {}", lv.level);
    std::println("  {}  {}/{} XP до уровня {} · всего {} XP · за неделю +{}", progress_bar(double(lv.into) / lv.need, 20),
                 lv.into, lv.need, lv.level + 1, st.total, week);

    if (!st.campaigns.empty()) {
        std::println("\nКампании");
        for (auto& [code, c] : st.campaigns) {
            int threats = 0, na = 0, mitigated = 0, tested = 0, chained = 0;
            for (auto& [_, t] : c.threats) {
                if (!t.active) continue;
                if (t.na) {
                    ++na;
                    continue;
                }
                ++threats;
                mitigated += t.mitigated;
                tested += t.tested;
                chained += t.chained;
            }
            std::string missing;
            for (char l : std::string("STRIDE"))
                if (c.stride_covered().find(l) == std::string::npos) missing += l;
            std::println("  {}{} · {}", code, c.title.empty() ? "" : " — " + c.title, act_name(c.act()));
            std::println("    угрозы {}: митигировано {}, проверено {}, цепочек замкнуто {}{} · STRIDE {}/6{}", threats,
                         mitigated, tested, chained, na ? " (неприменимых " + std::to_string(na) + ")" : "",
                         6 - missing.size(), missing.empty() ? " ✓" : " (нет " + missing + ")");
            if (!c.points.empty()) {
                int embedded = 0, covered = 0;
                for (auto& [_, p] : c.points) {
                    embedded += p.stage >= 1;
                    covered += p.stage >= 2;
                }
                std::println("    интеграция: точек {}, встроено {}, покрыто тестами {}", c.points.size(), embedded,
                             covered);
            }
        }
    }

    std::vector<const Quest*> active;
    for (auto& [_, q] : st.quests)
        if (!q.done && q.work) active.push_back(&q);
    if (!active.empty()) {
        std::println("\nКвесты в работе");
        for (auto* q : active) std::println("  {} — с {}", q->branch, q->started);
    }

    std::vector<std::string> contracts;
    for (auto& t : side_templates(cfg)) {
        if (!t.monthly) continue;
        ContractPeriod p = contract_period(t, now);
        bool done = st.contracts_done.count(t.id) && st.contracts_done.at(t.id).count(month_key(p.month));
        std::string what = t.title + " (" + month_nominative(p.month.m) + ")";
        if (!done && p.on_time)
            contracts.push_back(std::format("{} — срок {} {}, в срок +{}%", what, p.due.d, month_genitive(p.due.m),
                                            int(t.early_bonus * 100)));
        else if (!done)
            contracts.push_back(std::format("{} — срок был {} {}, закрыть всё ещё можно", what, p.due.d,
                                            month_genitive(p.due.m)));
        else if (now.d < t.open_day)
            contracts.push_back(std::format("{}: следующий откроется {} {}", t.title, t.open_day, month_genitive(now.m)));
    }
    if (!contracts.empty()) {
        std::println("\nКонтракты");
        for (auto& c : contracts) std::println("  {}", c);
    }

    if (!st.skills.empty()) std::println("\nНавыки\n  {}", skill_line(st, 6));

    if (!st.awards.empty()) {
        std::println("\nПоследние награды");
        size_t from = st.awards.size() > 6 ? st.awards.size() - 6 : 0;
        for (size_t i = from; i < st.awards.size(); ++i) {
            auto& a = st.awards[i];
            std::println("  {}  +{:<4} {}", log.all()[a.event].time.substr(0, 10), a.xp, a.reason);
        }
    }

    if (!st.warnings.empty()) {
        std::println("\nВнимание");
        for (auto& w : st.warnings) std::println("  {}", w);
    }
    if (st.awards.empty() && st.campaigns.empty())
        std::println("\nПусто. Начните с sq side, sq campaign add или sq find. Справка: sq help");
    return 0;
}

int cmd_sync(const Config& cfg, EventLog& log) {
    int before = replay(cfg, log).total;
    size_t first_new = log.all().size();
    std::vector<std::string> report;
    sync_documents(cfg, log, report);
    sync_git(cfg, log, report);
    for (auto& line : report) std::println("{}", line);

    State st = replay(cfg, log);
    int gained = 0;
    for (auto& a : st.awards)
        if (a.event >= first_new) {
            std::println("  +{} XP  {}", a.xp, a.reason);
            gained += a.xp;
        }
    if (gained) std::println("Итого +{} XP", gained);
    if (level_of(st.total).level > level_of(before).level) std::println("\n  ★ Новый уровень: {}!", level_of(st.total).level);
    return 0;
}

int cmd_side(const Config& cfg, EventLog& log, const Args& a) {
    auto templates = side_templates(cfg);
    if (a.pos.empty()) {
        State st = replay(cfg, log);
        Date now = today();
        std::string week = week_start(now);
        std::println("Побочные квесты (неделя с {})", week);
        for (auto& t : templates) {
            int n = st.side_counts.count(week) && st.side_counts.at(week).count(t.id) ? st.side_counts.at(week).at(t.id) : 0;
            std::string extra;
            if (t.monthly) {
                ContractPeriod p = contract_period(t, now);
                bool done = st.contracts_done.count(t.id) && st.contracts_done.at(t.id).count(month_key(p.month));
                extra = std::format("ежемесячно: {} {}", month_nominative(p.month.m), done ? "сдан ✓" : "не сдан");
            } else if (t.weekly_cap > 0) {
                extra = std::format("{}/{} за неделю", n, t.weekly_cap);
            }
            std::println("  {:<11} {:<28} {:>3} XP   {}", t.id, t.title, int(t.xp), extra);
        }
        std::println("\nЗаписать: sq side done <id> [заметка]   или   sq side done \"свой текст\"");
        std::println("Ветки fix/* засчитываются как bugfix при sq sync.");
        return 0;
    }
    if (a.pos[0] != "done" || a.pos.size() < 2) {
        std::println(stderr, "Использование: sq side done <id|\"текст\"> [заметка]");
        return 1;
    }

    int before = replay(cfg, log).total;
    bool known = std::ranges::any_of(templates, [&](auto& t) { return t.id == a.pos[1]; });
    auto r = known ? record_side(cfg, log, a.pos[1], a.rest(2)) : record_side(cfg, log, a.rest(1), "");
    if (!r.ok) return fail(r);
    report_new_event(cfg, log, before);
    return 0;
}

int cmd_find(const Config& cfg, EventLog& log, const Args& a) {
    if (a.pos.size() < 2) {
        std::println(stderr, "Использование: sq find <CWE-N> <low|medium|high|critical> [описание] [--stage …] "
                             "[--campaign КОД] [--threat КОД/T-NN] [--lesson \"урок\"]");
        return 1;
    }
    auto opt = [&](const char* name) { return a.opt.count(name) ? a.opt.at(name) : std::string(); };
    FindingInput in{a.pos[0], a.pos[1], opt("stage"), opt("campaign"), opt("threat"), opt("lesson"), a.rest(2)};

    int before = replay(cfg, log).total;
    auto r = record_finding(log, in);
    if (!r.ok) return fail(r);
    std::println("Находка {} записана.", r.message);
    report_new_event(cfg, log, before);
    if (is_blind_spot(log, r.message))
        std::println("  Это слепое пятно модели угроз. Добавьте урок: sq lesson {} \"…\"", r.message);
    return 0;
}

int cmd_lesson(const Config& cfg, EventLog& log, const Args& a) {
    if (a.pos.size() < 2) {
        std::println(stderr, "Использование: sq lesson <F-id> \"урок\"");
        return 1;
    }
    int before = replay(cfg, log).total;
    auto r = record_lesson(log, a.pos[0], a.rest(1));
    if (!r.ok) return fail(r);
    report_new_event(cfg, log, before);
    return 0;
}

int cmd_campaign(Config& cfg, const EventLog& log, const Args& a) {
    if (a.pos.empty()) {
        State st = replay(cfg, log);
        if (st.campaigns.empty()) std::println("Кампаний нет. sq campaign add <КОД> <путь к docx> [название]");
        for (auto& [code, c] : st.campaigns)
            std::println("  {:<8} {} · {}\n           {}", code, c.title.empty() ? "(без названия)" : c.title,
                         act_name(c.act()), c.doc.empty() ? "документ не задан" : c.doc);
        return 0;
    }
    if (a.pos[0] != "add" || a.pos.size() < 3) {
        std::println(stderr, "Использование: sq campaign add <КОД> <путь к docx> [название]");
        return 1;
    }
    auto r = add_campaign(cfg, a.pos[1], a.pos[2], a.rest(3));
    if (!r.ok) return fail(r);
    if (!r.message.empty()) std::println("Внимание: {}", r.message);
    std::println("Кампания {} добавлена. Угрозы подтянутся при sq sync.", upper_ascii(a.pos[1]));
    return 0;
}

int cmd_point(EventLog& log, const Args& a) {
    if (a.pos.size() < 3 || a.pos[0] != "add") {
        std::println(stderr, "Использование: sq point add <КОД> <точка> [название]");
        return 1;
    }
    auto r = plan_point(log, a.pos[1], a.pos[2], a.rest(3));
    if (!r.ok) return fail(r);
    std::string target = upper_ascii(a.pos[1]) + "/" + a.pos[2];
    std::println("Точка интеграции {} запланирована. Трейлеры: Integration: {} и Integration-Test: {}", target, target,
                 target);
    return 0;
}

int cmd_threats(const Config& cfg, const EventLog& log, const Args& a) {
    State st = replay(cfg, log);
    std::string only = a.pos.empty() ? "" : upper_ascii(a.pos[0]);
    for (auto& [code, c] : st.campaigns) {
        if (!only.empty() && code != only) continue;
        std::println("{}{} · {}", code, c.title.empty() ? "" : " — " + c.title, act_name(c.act()));
        if (c.threats.empty()) std::println("  угроз пока нет");
        for (auto& [id, t] : c.threats) {
            if (!t.active) continue;
            std::string status = t.na ? "неприменимо     "
                                      : std::format("митиг. {}  тест {}", t.mitigated ? "✓" : "·", t.tested ? "✓" : "·");
            std::println("  {:<6} {}  {:<6} {}", id, status, t.stride.empty() ? "—" : t.stride, t.desc);
        }
        for (auto& [id, p] : c.points)
            std::println("  точка {:<14} {}{}", id, stage_name(p.stage), p.title.empty() ? "" : " — " + p.title);
    }
    return 0;
}

int cmd_done(const Config& cfg, EventLog& log, const Args& a) {
    if (a.pos.empty()) {
        std::println(stderr, "Использование: sq done <ветка>");
        return 1;
    }
    int before = replay(cfg, log).total;
    auto r = close_quest(cfg, log, a.pos[0]);
    if (!r.ok) return fail(r);
    report_new_event(cfg, log, before);
    return 0;
}

int cmd_bestiary(const Config& cfg, const EventLog& log) {
    State st = replay(cfg, log);
    std::vector<std::string> groups;
    for (auto& c : cwe_catalog())
        if (std::ranges::find(groups, c.skill) == groups.end()) groups.push_back(c.skill);

    std::set<int> listed;
    for (auto& g : groups) {
        int total = 0, caught = 0;
        for (auto& c : cwe_catalog())
            if (c.skill == g) {
                ++total;
                caught += st.bestiary.count(c.id) != 0;
            }
        std::println("\n{}  {}/{}", g, caught, total);
        for (auto& c : cwe_catalog()) {
            if (c.skill != g) continue;
            listed.insert(c.id);
            auto n = st.bestiary.count(c.id) ? st.bestiary.at(c.id) : 0;
            if (n) std::println("  ✓ CWE-{:<5} {} ×{}", c.id, c.name, n);
            else std::println("  · CWE-{:<5} {}", c.id, c.name);
        }
    }
    bool header = false;
    for (auto& [id, n] : st.bestiary) {
        if (listed.count(id)) continue;
        if (!header) std::println("\nВне справочника");
        header = true;
        std::println("  ✓ CWE-{:<5} ×{}", id, n);
    }
    return 0;
}

std::string describe(const Event& e) {
    const std::string& t = e.type;
    if (t == "side") {
        std::string what = e.get("id") == "adhoc" ? e.get("title") : e.get("id");
        return "побочный квест: " + what + (e.get("note").empty() ? "" : " — " + e.get("note"));
    }
    if (t == "finding")
        return "находка " + e.get("id") + ": CWE-" + e.get("cwe") + " " + e.get("sev") + ", " + e.get("stage") +
               (e.get("note").empty() ? "" : " — " + e.get("note"));
    if (t == "lesson") return "урок к " + e.get("ref");
    if (starts_with(t, "threat.")) return t + " " + e.get("campaign") + "/" + e.get("id");
    if (starts_with(t, "quest.")) return t + " " + e.get("branch");
    if (t == "link") return "трейлер " + e.get("kind") + ": " + e.get("target") + " (" + e.get("sha") + ")";
    if (t == "point.plan") return "точка интеграции " + e.get("campaign") + "/" + e.get("point");
    return t;
}

int cmd_log(const Config& cfg, const EventLog& log, const Args& a) {
    State st = replay(cfg, log);
    size_t n = a.pos.empty() ? 20 : size_t(std::max(1, std::atoi(a.pos[0].c_str())));
    std::map<size_t, int> xp;
    for (auto& aw : st.awards) xp[aw.event] += aw.xp;
    const auto& all = log.all();
    for (size_t i = all.size() > n ? all.size() - n : 0; i < all.size(); ++i) {
        std::string gained = xp.count(i) ? "+" + std::to_string(xp[i]) : "";
        std::println("{}  {:>5}  {}", all[i].time.substr(0, 16), gained, describe(all[i]));
    }
    return 0;
}

// Поход из консоли: удобно для проверки баланса и для тех, кто не открывает окно.
int cmd_game(const Config& cfg, const EventLog& log, const Args& a) {
    using namespace quest;
    EventLog game(cfg.home / "game.log");
    if (game.load() < 0) return fail(ActionResult::fail("Не удалось прочитать game.log"));
    State st = replay(cfg, log);
    World w = build_world(cfg, st, log, game);
    std::string sub = a.pos.empty() ? "" : a.pos[0];
    auto arg = [&](size_t i) { return i < a.pos.size() ? a.pos[i] : std::string(); };
    auto done = [&](const std::string& err) {
        if (!err.empty()) return fail(ActionResult::fail(err));
        std::println("Готово.");
        return 0;
    };

    if (sub == "start") return done(start_game(game));
    if (sub == "hire") return done(hire(w, game, unit_index(arg(1)), std::atoi(arg(2).c_str())));
    if (sub == "upgrade") return done(upgrade(w, game, unit_index(arg(1)), std::atoi(arg(2).c_str())));
    if (sub == "scroll") return done(buy_scroll(w, game, std::atoi(arg(1).c_str())));
    if (sub == "fight" || sub == "raids") {
        auto report = [&](const BattleResult& r, const std::string& title) {
            std::println("{}: {} за {} раундов", title, r.won ? "победа" : "поражение", r.rounds);
            for (size_t i = 0; i < r.ours.size(); ++i)
                if (r.our_losses[i]) std::println("  потери: {} −{}", r.ours[i].name, r.our_losses[i]);
        };
        if (sub == "raids") {
            if (w.raids.empty()) std::println("Набегов нет.");
            // Каждый набег — против армии после предыдущего, поэтому мир пересобирается между ними.
            for (int i = 0; i < 10 && !w.raids.empty(); ++i) {
                Raid raid = w.raids.front();
                report(defend(w, game, raid), raid.enemy.name);
                w = build_world(cfg, st, log, game);
            }
            return 0;
        }
        const Node* n = w.node(arg(1));
        if (!n) return fail(ActionResult::fail("Нет такого узла. Список: sq game"));
        if (n->sealed) return fail(ActionResult::fail("Логово запечатано: задача не сдана"));
        if (auto b = battle_blocker(w.army, n->enemy); !b.empty()) return fail(ActionResult::fail(b));
        report(fight(w, game, n->id), n->enemy.name);
        return 0;
    }
    if (!sub.empty()) return fail(ActionResult::fail("sq game [start | hire <отряд> <n> | upgrade <отряд> <n> | scroll <школа 0-5> | fight <узел> | raids]"));

    if (!w.started) std::println("Поход не начат: sq game start");
    std::println("Золото {} · уровень героя {} · атака +{} защита +{} магия {}", w.gold, w.level, w.army.hero_atk, w.army.hero_def, w.army.hero_power);
    std::string armor, spells;
    for (int f = 0; f < kFactions; ++f) armor += std::format("{}{} ", faction(f).letter, w.army.armor[size_t(f)]);
    for (int s = 0; s < kSchools; ++s) spells += std::format("{}:{}/{} ", s, w.army.spells[size_t(s)], w.army.scrolls[size_t(s)]);
    std::println("Броня {}· школы (уровень/свитки) {}", armor, spells);
    std::println("Армия (сила {}):", power_of(w.army.stacks));
    for (auto& s : w.army.stacks) std::println("  {} × {}", s.name, s.count);
    std::println("Отряды для найма:");
    for (auto& u : unit_types()) std::println("  {:<8} {} — {} золота, с {} уровня", u.id, u.name, u.cost, u.level_req);
    std::println("Узлы карты:");
    for (auto& n : w.nodes) {
        if (n.kind == Node::Capital || n.kind == Node::Fort) continue;
        std::string state = n.cleared ? "повержен" : n.sealed ? "запечатан" : battle_blocker(w.army, n.enemy);
        if (state.empty()) state = std::format("можно в бой, сила {}", power_of(n.enemy.stacks));
        std::println("  {:<36} {}", n.id, state);
    }
    if (!w.raids.empty()) std::println("Ждут набеги: {} (sq game raids)", w.raids.size());
    return 0;
}

}  // namespace

int main() {
    console_init();
    auto argv = utf8_args();
    std::string cmd = argv.size() > 1 ? argv[1] : "status";
    Args args = parse_args(argv, 2);

    if (cmd == "help" || cmd == "--help" || cmd == "-h") {
        std::println("{}", kHelp);
        return 0;
    }

    Config cfg;
    cfg.home = data_home();
    if (cmd == "init") return cmd_init(cfg, args);
    if (!cfg.ini.load(cfg.config_file())) {
        std::println(stderr, "Нет настроек ({}). Начните с: sq init", from_path(cfg.config_file()));
        return 1;
    }

    EventLog log(cfg.events_file());
    int broken = log.load();
    if (broken < 0) {
        std::println(stderr, "Не удалось прочитать {}", from_path(cfg.events_file()));
        return 1;
    }
    if (broken > 0) std::println(stderr, "Пропущено повреждённых строк в журнале: {}", broken);

    if (cmd == "status") return cmd_status(cfg, log);
    if (cmd == "sync") return cmd_sync(cfg, log);
    if (cmd == "side") return cmd_side(cfg, log, args);
    if (cmd == "find") return cmd_find(cfg, log, args);
    if (cmd == "lesson") return cmd_lesson(cfg, log, args);
    if (cmd == "campaign") return cmd_campaign(cfg, log, args);
    if (cmd == "point") return cmd_point(log, args);
    if (cmd == "threats") return cmd_threats(cfg, log, args);
    if (cmd == "done") return cmd_done(cfg, log, args);
    if (cmd == "bestiary") return cmd_bestiary(cfg, log);
    if (cmd == "log") return cmd_log(cfg, log, args);
    if (cmd == "game") return cmd_game(cfg, log, args);

    std::println(stderr, "Неизвестная команда «{}». Справка: sq help", cmd);
    return 1;
}
