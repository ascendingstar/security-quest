#pragma once

// «Поход» — фэнтези-слой поверх рабочего прогресса.
//
// Мир не хранится: он каждый раз строится из рабочего журнала (events.log) и
// игрового журнала (game.log), как и очки. Связь с работой:
//   угрозы STRIDE из дизайн-документа  → лагеря шести вражеских фракций;
//   митигации и тесты угроз            → броня против фракции (без неё лагерь не взять);
//   пойманные классы CWE               → школы магии (без нужной школы босс неуязвим);
//   побочные квесты                    → золото на войска и свитки;
//   ветка в работе                     → логово босса, которое открывается, когда задача сдана;
//   находка                            → монстр, которого можно добить ради добычи;
//   неразобранные классы STRIDE        → туман неизведанного на карте кампании;
//   точки интеграции                   → крепости, которые помогают отбивать набеги;
//   угрозы без митигации               → еженедельные набеги на земли кампании.
// Поражения стоят только игровых ресурсов: очки и уровни за работу не сгорают.

#include "config.h"
#include "events.h"
#include "game.h"

#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace sq::quest {

constexpr int kFactions = 6;  // S T R I D E
constexpr int kSchools = 6;   // по веткам бестиария

struct FactionInfo {
    char letter;
    const char* name;       // «Подменыши»
    const char* genitive;   // «Подменышей»
    const char* unit;       // рядовой
    const char* elite;      // элита
    const char* boss;       // предводитель
};
const FactionInfo& faction(int f);
int faction_of_letter(char letter);

struct SchoolInfo {
    const char* skill;  // ветка бестиария, которая открывает школу
    const char* name;   // «Магия Памяти»
    const char* spell;  // «Упокоение»
};
const SchoolInfo& school(int s);

struct UnitType {
    const char* id;
    const char* name;
    const char* elite_name;
    int cost, level_req;
    int hp, atk, def, dmg_min, dmg_max, speed;
    bool ranged;
};
const std::vector<UnitType>& unit_types();
int unit_index(const std::string& id);
int upgrade_cost(int unit);  // за одного бойца

// Отряд в бою.
struct Stack {
    std::string name;
    std::string icon;  // guard archer knight mage griffin | faction | beast | boss
    int count = 0, hp = 1;
    int atk = 0, def = 0, dmg_min = 1, dmg_max = 1, speed = 1;
    bool ranged = false;
    int unit = -1;  // для своих отрядов: индекс в unit_types()
    bool elite = false;
    bool shielded = false;
};

struct Enemy {
    std::string name, title;
    int faction = -1;          // -1 — звери без фракции
    int tier = 1;
    std::vector<Stack> stacks;
    int shield_school = -1;    // без этой школы предводитель неуязвим
    bool needs_armor = false;  // без брони против фракции не пройти
    int reward = 0;
};

struct Army {
    std::vector<Stack> stacks;
    int hero_atk = 0, hero_def = 0, hero_power = 1;
    std::array<int, kFactions> armor{};
    std::array<int, kSchools> spells{};
    std::array<int, kSchools> scrolls{};
    int towers = 0;  // только при защите от набегов
};

struct BattleAction {
    enum Kind { Melee, Ranged, Spell, ShieldBreak, Tower };
    Kind kind;
    int side, actor;         // side 0 — мы, 1 — противник; actor -1 — герой или башни
    int target;              // индекс отряда на другой стороне
    int damage, kills;
    int school = -1;
    int round;
};

struct BattleResult {
    bool won = false;
    std::vector<Stack> ours, theirs;  // составы на начало боя
    std::vector<BattleAction> actions;
    std::vector<int> our_losses;      // по отрядам ours
    std::vector<int> scrolls_used;
    int rounds = 0;
};

BattleResult simulate(const Army& army, const Enemy& enemy, uint32_t seed);

// Почему бой нельзя начать; пустая строка — можно.
std::string battle_blocker(const Army& army, const Enemy& enemy);
int power_of(const std::vector<Stack>& stacks);

// ---------------------------------------------------------------------------
// Мир

struct Node {
    enum Kind { Capital, Camp, Fort, Lair, Monster };
    std::string id;
    Kind kind;
    std::string region;
    int sector = -1;      // для лагерей — фракция
    std::string label, detail;
    bool cleared = false;
    bool sealed = false;  // логово: задача ещё не сдана
    int stage = 0;        // крепость: 0 план, 1 стоит, 2 укреплена
    Enemy enemy;
    float x = 0, y = 0;   // координаты на карте
};

struct Region {
    std::string id, name;
    bool explored = false;
    bool campaign = false;
    std::array<bool, kFactions> sectors{};  // раскрытые секторы STRIDE
    float x = 0, y = 0, radius = 0;
    int color_seed = 0;
};

struct Chronicle {
    std::string time, text;
    enum Tone { Story, Good, Bad, Gold, Chapter } tone;
};

struct Raid {
    std::string key, region, threat;
    Enemy enemy;
};

struct World {
    int gold = 0, gold_earned = 0;
    int level = 1;
    int bosses_defeated = 0;
    Army army;  // герой, броня, заклинания, свитки и отряды в строю
    std::vector<Region> regions;
    std::vector<Node> nodes;
    std::vector<Chronicle> chronicle;
    std::vector<Raid> raids;  // набеги, которые пора разыграть
    bool started = false;

    const Node* node(const std::string& id) const;
    int army_count(int unit, bool elite) const;
};

World build_world(const Config& cfg, const State& st, const EventLog& work, const EventLog& game);

// Игровые действия: пишут событие в game.log. Пустая строка — успех, иначе причина отказа.
std::string start_game(EventLog& game);
std::string hire(const World& w, EventLog& game, int unit, int count);
std::string upgrade(const World& w, EventLog& game, int unit, int count);
std::string buy_scroll(const World& w, EventLog& game, int school);
constexpr int kScrollCost = 150;

// Разыгрывает бой с узлом карты, записывает итог и возвращает его для анимации.
BattleResult fight(const World& w, EventLog& game, const std::string& node_id);
BattleResult defend(const World& w, EventLog& game, const Raid& raid);

}  // namespace sq::quest
