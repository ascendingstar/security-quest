#pragma once

// Синхронизация наблюдений из внешних источников в журнал событий:
// таблицы угроз из Word-документов кампаний и ветки/трейлеры из git.
// Источники только читаются; запись идёт исключительно в events.log.

#include "config.h"
#include "events.h"

#include <string>
#include <vector>

namespace sq {

struct BranchInfo {
    std::string kind, campaign;
};

BranchInfo classify_branch(const std::string& branch);

void sync_documents(const Config& cfg, EventLog& log, std::vector<std::string>& report);
void sync_git(const Config& cfg, EventLog& log, std::vector<std::string>& report);

}  // namespace sq
